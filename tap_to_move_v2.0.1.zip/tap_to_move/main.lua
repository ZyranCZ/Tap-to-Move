-- Tap to Move v2.0.1
-- Mobile-first collision-aware shortest-path navigation for Gen1Recomp.
--
-- Design rule: this mod never writes player coordinates or invents warp
-- destinations. It plans routes and drives the real Game Boy D-pad through
-- mod.input. A narrowly validated directional-exit fallback may ask the live
-- overworld to take its own exact warp record after input activation fails;
-- Gen1Recomp still owns destination resolution, transition, scripts and state.

local mod = ...

local VERSION = "2.0.1"
local TILE_SIZE = 16
local FIXED_TICKS_PER_SECOND = 60
local DEFAULT_HOLD_STEER_DELAY_MS = 150 -- 1X base; scaled by live overworld logic speed
local DEFAULT_PERFORMANCE_INPUT_FREQUENCY = "balance"

-- Hold retarget preset = how often the expensive held-pointer retarget work
-- is allowed to run. Voxel Path Preview reprojection is independently fixed
-- at the deliberately conservative 0.25/s rate.
local PERFORMANCE_INPUT_PROFILES = {
  low =     { label = "LOW",     holdMs = 200 }, -- 5 Hz
  medium =  { label = "MEDIUM",  holdMs = 300 }, -- 3.3 Hz
  balance = { label = "BALANCE", holdMs = 400 }, -- 2.5 Hz
  high =    { label = "HIGH",    holdMs = 600 }, -- 1.7 Hz
  ultra =   { label = "ULTRA",   holdMs = 800 }, -- 1.25 Hz
}

-- Optional two-finger shortcuts. Gen1Recomp/LÖVE can surface pinch/spread
-- as zoom input independently of the gameplay pointer stream, so the mod
-- recognizes the two contacts itself and also guards Game:zoomStep while a
-- gesture is reserved. A direction must move far enough from its initial
-- separation to avoid firing when the second finger merely lands.
local TWO_FINGER_TRIGGER_UNITS = 36
local TWO_FINGER_TRIGGER_RATIO = 0.18
local PINCH_ZOOM_GRACE_TICKS = 36 -- keep blocking delayed native zoom callbacks for ~0.6 s

-- Controls-free one-finger gestures. Holding directly on the player for one
-- second is an alternate START gesture. DIALOG TOUCH CONTROL is the catch-all
-- classifier for non-overworld, non-battle UI: a short stationary release
-- becomes A, a nearly stationary one-second hold becomes B, while a deliberate
-- swipe becomes one D-pad tap. Exactly one semantic action owns each contact.
local PLAYER_HOLD_START_TICKS = FIXED_TICKS_PER_SECOND -- exactly 1.0 s
local PLAYER_HOLD_MOVE_SLOP_UNITS = 22
local DIALOG_SWIPE_TRIGGER_UNITS = 30

-- Controls-free dialogue / mobile shake input. A shake is deliberately
-- recognized as an oscillation (two strong opposite impulses) rather than a
-- single jolt, so putting the phone down or rotating it once does not normally
-- press B. Accelerometer data is gravity-compensated; gyroscope data is used
-- directly. Android Gen1Recomp currently runs LÖVE 11.5 with the legacy
-- accelerometer-as-joystick disabled, so the mod talks to SDL2's independent
-- sensor subsystem through FFI instead. iOS/LÖVE 12 can use love.sensor.
local ControlsFree = {
  -- Performance/search tuning lives on this namespace table instead of as
  -- extra chunk locals. FULL exactly preserves the pre-budget search scope.
  pathBudgetProfiles = {
    very_low = {
      label = "VERY LOW", nodes = 128, seams = 2, exits = 2, crossTargets = 4,
    },
    medium = {
      label = "MEDIUM", nodes = 256, seams = 4, exits = 4, crossTargets = 8,
    },
    full = {
      label = "FULL", nodes = nil, seams = nil, exits = nil, crossTargets = nil,
    },
  },
  DEFAULT_PATH_BUDGET = "full",
  -- Voxel Path Preview live reprojection is intentionally fixed at 0.25/s.
  VOXEL_PATH_REFRESH_TICKS = 240,
  engineWarpModule = false,
  occupancyCache = nil,
  warpCellsCache = setmetatable({}, { __mode = "k" }),
  neighborLookupCache = nil,

  -- Renderer-agnostic direct steering constants. Kept on this table rather
  -- than as extra chunk locals because this very large mod deliberately stays
  -- below Lua 5.1's 200-local limit for one compiled function.
  SIMPLE_TOUCH_DEADZONE = 0.10, -- default; runtime-tunable in Simple Mode
  SIMPLE_TOUCH_AXIS_DEADZONE = 0.06, -- default; runtime-tunable in Simple Mode
  -- If one screen-axis component is at least four times stronger than the
  -- other, treat the gesture as intentionally cardinal. This prevents tiny
  -- thumb drift from leaking an occasional sideways step into a long hold.
  SIMPLE_TOUCH_DOMINANCE_RATIO = 4.0, -- default; runtime-tunable in Simple Mode
  SIMPLE_TOUCH_PRESS_FAIL_TICKS = 4,
  SIMPLE_TOUCH_RETRY_BLOCK_TICKS = 10,
  SIMPLE_TOUCH_LONG_PRESS_SECONDS = 1.0,
  SIMPLE_TOUCH_LONG_PRESS_MOVE_SLOP_UNITS = 22,
  NATIVE_CONTROLS_TOGGLE_MIN_SIZE = 34,
  NATIVE_CONTROLS_TOGGLE_MAX_SIZE = 48,
  NATIVE_CONTROLS_TOGGLE_MARGIN = 10,
  NATIVE_CONTROLS_TOGGLE_SLOP = 8,
  SIMPLE_DIR_COMPASS = { up="north", down="south", left="west", right="east" },
  TOUCH_HOLD_B_TICKS = FIXED_TICKS_PER_SECOND, -- exactly 1.0 s
  TOUCH_HOLD_B_MOVE_SLOP_UNITS = 22,
  -- When PINCH OR SPREAD is selected, the first world touch is reserved for a
  -- brief pairing window before Tap to Move sees it. Human two-finger gestures
  -- rarely land on the exact same frame; without this grace the first finger
  -- can start one walking step before the second finger turns the pair into
  -- START/SELECT. Short ordinary taps are replayed immediately on release.
  PINCH_FIRST_TOUCH_GRACE_TICKS = 12, -- 0.20 s at 60 Hz
  -- Mobile OS navigation gestures commonly begin at the bottom edge. Reserve
  -- that narrow strip only for bare-overworld WORLD touches until intent is
  -- clear, so a Home/app-switch swipe cannot start a Tap-to-Move route. Native
  -- virtual controls and UI/battle touch handling are never reserved here.
  SYSTEM_EDGE_START_BAND_RATIO = 0.12,
  SYSTEM_EDGE_START_BAND_MIN_UNITS = 32,
  SYSTEM_EDGE_START_BAND_MAX_UNITS = 96,
  SYSTEM_EDGE_UP_TRIGGER_UNITS = 30,
  SYSTEM_EDGE_AXIS_RATIO = 1.15,
  SYSTEM_EDGE_SIDE_ESCAPE_UNITS = 34,
  SDL_INIT_SENSOR = 0x00008000,
  SDL_SENSOR_ACCEL = 1,
  SDL_SENSOR_GYRO = 2,
}
local VOXEL_COLUMN_HEIGHT = 48           -- semantic prism height in world px
local VOXEL_COLUMN_MID_HEIGHT = 24
local VOXEL_COLUMN_SNAP_UNITS = 24       -- touch-space tolerance in LOVE units
local VOXEL_COLUMN_SEARCH_Y_UNITS = 176  -- bound fallback work on mobile
local VOXEL_COLUMN_MAX_CANDIDATES = 64     -- cap extra height projections
local ENTITY_BLOCK_TICKS = 20
local DYNAMIC_RETRY_TICKS = 12
local MAX_DYNAMIC_WAIT_TICKS = 240     -- ~4 s total wait for wandering NPCs
local NO_PROGRESS_TICKS = 180            -- ~3 s safety watchdog while WALKING
local MAX_INTERACTION_REPLANS = 120     -- safety fuse; legitimate NPC chase does not consume it
local MAX_INTERACTION_AGE_TICKS = 1800   -- ~30 s following a wandering target
local MAX_BATTLE_RESUME_AGE_TICKS = 1800  -- ~30 s to return to free overworld

-- Deterministic order for equal-cost A* routes.  Keeping this stable avoids
-- route jitter when repeated replans have several equally short answers.
local DIRS = {
  { name = "up",    dx =  0, dy = -1, rank = 1 },
  { name = "left",  dx = -1, dy =  0, rank = 2 },
  { name = "right", dx =  1, dy =  0, rank = 3 },
  { name = "down",  dx =  0, dy =  1, rank = 4 },
}

local DIR_BY_NAME = {}
for _, d in ipairs(DIRS) do DIR_BY_NAME[d.name] = d end

mod.options:define({
  { key = "enabled", label = "TAP TO MOVE", type = "toggle", default = true },
  { key = "interact", label = "TAP TO INTERACT", type = "toggle", default = true },
  { key = "hold_steer", label = "HOLD TO STEER", type = "toggle", default = true },
  { key = "hold_steer_delay_ms", label = "HOLD STEER DELAY", type = "number",
    default = DEFAULT_HOLD_STEER_DELAY_MS, min = 150, max = 500, step = 50 },
  -- Keep the legacy key so existing option values survive the rename.
  -- This setting only throttles Hold-to-Steer retarget/path recalculation.
  { key = "performance_input_frequency", label = "HOLD RETARGET RATE",
    type = "choice", default = DEFAULT_PERFORMANCE_INPUT_FREQUENCY,
    choices = {
      { "5/S", "low" }, { "3.3/S", "medium" }, { "2.5/S", "balance" },
      { "1.7/S", "high" }, { "1.25/S", "ultra" },
    } },
  { key = "pathfinding_budget", label = "PERFORMANCE BUDGET",
    type = "choice", default = ControlsFree.DEFAULT_PATH_BUDGET,
    choices = {
      { "VERY LOW", "very_low" },
      { "MEDIUM", "medium" },
      { "FULL", "full" },
    } },  { key = "dialog_touch_control", label = "DIALOG TOUCH CONTROL",
    type = "toggle", default = false },
  { key = "battle_touch_control", label = "BATTLE TOUCH CONTROL",
    type = "toggle", default = false },
  { key = "start_select_touch_control", label = "START/SELECT TOUCH CONTROL",
    type = "choice", default = "off",
    choices = {
      { "OFF", "off" },
      { "HOLD PLAYER SPRITE", "hold_player_sprite" },
      { "PINCH OR SPREAD", "pinch_or_spread" },
    } },
  { key = "feedback", label = "TAP FEEDBACK", type = "toggle", default = true },
  { key = "path_preview", label = "PATH PREVIEW", type = "choice", default = "off",
    choices = { { "OFF", "off" }, { "SHORT", "short" }, { "FULL", "full" } } },
  { key = "battle_resume", label = "RESUME AFTER WILD", type = "toggle", default = false },
  { key = "debug", label = "DEBUG OVERLAY", type = "toggle", default = false },

  -- Mouse options stay grouped together: all are opt-in.
  { key = "mouse", label = "MOUSE WALK CONTROL",
    type = "toggle", default = false },
  { key = "desktop_mouse_ab", label = "MOUSE LMB/RMB=A/B",
    type = "toggle", default = false },
  { key = "mouse_wheel_control", label = "MOUSE WHEEL ▲/▼",
    type = "choice", default = "off",
    choices = {
      { "OFF", "off" }, { "ON", "on" }, { "ON FLIPPED", "on_flipped" },
    } },
  { key = "mouse_wheel_tilt", label = "MOUSE WH.TILT L/R",
    type = "choice", default = "off",
    choices = {
      { "OFF", "off" }, { "ON", "on" }, { "ON FLIPPED", "on_flipped" },
    } },
  { key = "mouse_side_buttons", label = "MOUSE SIDE ST/SEL",
    type = "choice", default = "off",
    choices = {
      { "OFF", "off" }, { "ON", "on" }, { "ON FLIPPED", "on_flipped" },
    } },

  -- Renderer-agnostic fallback mode is intentionally the final options block:
  -- it is experimental and its tuning rows belong together for iteration.
  { key = "simple_touch_movement", label = "EXPERIMENTAL: Simple Mode",
    type = "toggle", default = false },
  { key = "simple_center_deadzone_pct", label = "SIMPLE CENTER DEADZONE",
    type = "choice", default = "10",
    choices = {
      { "OFF", "0" }, { "5%", "5" }, { "10%", "10" }, { "15%", "15" },
      { "20%", "20" }, { "25%", "25" }, { "30%", "30" },
    } },
  { key = "simple_axis_deadzone_pct", label = "SIMPLE AXIS DEADZONE",
    type = "choice", default = "6",
    choices = {
      { "OFF", "0" }, { "2%", "2" }, { "4%", "4" }, { "6%", "6" },
      { "8%", "8" }, { "10%", "10" }, { "12%", "12" },
      { "15%", "15" }, { "20%", "20" },
    } },
  { key = "simple_dominance_ratio", label = "SIMPLE DOMINANCE RATIO",
    type = "choice", default = "4",
    choices = {
      { "OFF", "off" }, { "1.5X", "1.5" }, { "2X", "2" },
      { "2.5X", "2.5" }, { "3X", "3" }, { "3.5X", "3.5" },
      { "4X", "4" }, { "5X", "5" }, { "6X", "6" }, { "8X", "8" },
    } },
})

local state = {
  tick = 0,
  view = nil,
  frame = nil,
  pointers = {},
  tapOwner = nil,
  nav = nil,
  pulse = nil,
  simpleHold = nil,
  simpleInteraction = nil,
  simpleModeLast = false,
  nativeControlsVisibleOverride = nil,
  nativeControlsToggleTouches = {},
  nativeControlsToggleInstalled = false,
  nativeControlsToggleOriginalDraw = nil,
  game = nil,
  lastStop = nil,
  pendingInteraction = nil,
  battleResume = nil,
  exitJourney = nil,
  pendingRemoteGoal = nil,
  previewCache = nil,
  mapTransition = nil,
  gestureTouches = {},
  twoFingerGesture = nil,
  zoomGuardInstalled = false,
  zoomGuardOriginal = nil,
  zoomModule = nil,
  rawZoomTouches = {},
  rawZoomGuardInstalled = false,
  rawZoomGuardOriginal = nil,
  nativeZoomSuppression = nil,
  dialogTouches = {},
  battleTouches = {},
  battleCameraOwnedTouches = {},
  playerHoldTouches = {},
  systemEdgeTouches = {},
  pinchGraceTouches = {},
  rawTouchDispatchPress = nil,
  rawTouchDispatchMove = nil,
  rawTouchDispatchRelease = nil,
  rawDispatchedTouches = {},
  nativeControlOwnedTouches = {},
  stats = {
    routesStarted = 0,
    routesArrived = 0,
    replans = 0,
    pathSearches = 0,
    pathExpanded = 0,
    pathBudgetHits = 0,
    pathMaxExpanded = 0,
    seamCandidatesConsidered = 0,
    seamCandidatesSkipped = 0,
    occupancyCacheHits = 0,
    occupancyCacheMisses = 0,
    warpCacheHits = 0,
    warpCacheMisses = 0,
    occupancyCopiesAvoided = 0,
    occupancyCopiesRequired = 0,
    neighborLookupHits = 0,
    neighborLookupMisses = 0,
    mapTransitionFlushes = 0,
    mapTransitionWaitTicks = 0,
    mapTransitionReady = 0,
    crossFallbackCellsTested = 0,
    crossFallbackBudgetStops = 0,
    crossFallbackBudgetExhaustedSkips = 0,
    crossLocalFallbackAttempts = 0,
    crossLocalFallbackAccepted = 0,
    crossLocalFallbackRejected = 0,
    crossLocalDirectPath = 0,
    crossLocalNearestPath = 0,
    remoteConnectionTargets = 0,
    remoteConnectionLegs = 0,
    remoteConnectionReplans = 0,
    remoteConnectionRejects = 0,
    remoteConnectionStaticChecks = 0,
    exitCandidatesCheap = 0,
    exitCandidatesPathScored = 0,
    exitCandidatesDeferred = 0,
    dynamicWaits = 0,
    collisions = 0,
    invalidTaps = 0,
    interactionsTriggered = 0,
    interactionsConfirmed = 0,
    interactionMisses = 0,
    interactionReleaseWaits = 0,
    interactionHoldDisarms = 0,
    interactionFaceNeutralTicks = 0,
    interactionFaceTurns = 0,
    interactionFaceVerified = 0,
    interactionFaceRetries = 0,
    immediatePressRoutes = 0,
    holdRetargets = 0,
    simpleTouchDecisions = 0,
    simpleTouchSteps = 0,
    simpleTouchFallbacks = 0,
    simpleTouchBlocked = 0,
    simpleTouchDeadzone = 0,
    simpleTouchUp = 0,
    simpleTouchDown = 0,
    simpleTouchLeft = 0,
    simpleTouchRight = 0,
    simpleTouchAvatarInteractions = 0,
    simpleTouchDominantCardinals = 0,
    simpleTouchBlockedTurns = 0,
    simpleTouchStartHolds = 0,
    simpleTouchBHolds = 0,
    nativeControlsTogglePresses = 0,
    nativeControlsShown = 0,
    nativeControlsHidden = 0,
    seamNeutralTicks = 0,
    seamHeldFastStarts = 0,
    entryGestureSuppressions = 0,
    exitJourneyLegs = 0,
    exitJourneyTransitions = 0,
    topologyCacheHits = 0,
    topologyCacheMisses = 0,
    overviewCacheHits = 0,
    overviewCacheMisses = 0,
    exitFallbacks = 0,
    carpetDownIntents = 0,
    directionalWarpIntents = 0,
    edgeWarpIntents = 0,
    holeStepIntents = 0,
    exitClickBiasedSelections = 0,
    exitDirectionalAccepts = 0,
    exitDirectionalRejects = 0,
    exitContinuousSuppressions = 0,
    exitPrelandingCarries = 0,
    exitWarpForcedCommits = 0,
    exitGoalCollisionOverrides = 0,
    retainedTargets = 0,
    nearestFallbacks = 0,
    stickySemanticRetains = 0,
    npcHoldTargets = 0,
    feedbackPulses = 0,
    previewProjectionRefreshes = 0,
    previewProjectionCacheHits = 0,
    flatPreviewContextBuilds = 0,
    flatPreviewPointTransforms = 0,
    holdRetargetSkips = 0,
    voxelTargets = 0,
    voxelColumnTargets = 0,
    voxelRayTargets = 0,
    voxelRayOutside = 0,
    voxelSemanticRecoveries = 0,
    voxelNativeHiddenPathTargets = 0,
    hiddenTreasureTargets = 0,
    hiddenTreasureTriggers = 0,
    seamlessSurfPlans = 0,
    seamlessSurfMounts = 0,
    seamlessSurfFaceTurns = 0,
    seamlessSurfDenied = 0,
    cutTargets = 0,
    cutDirectTriggers = 0,
    cutDenied = 0,
    battleResumes = 0,
    battleResumeDrops = 0,
    twoFingerGestures = 0,
    gestureStartTriggers = 0,
    gestureSelectTriggers = 0,
    pinchZoomSuppressed = 0,
    dialogATaps = 0,
    dialogBHoldTriggers = 0,
    dialogSwipes = 0,
    dialogSwipeUp = 0,
    dialogSwipeDown = 0,
    dialogSwipeLeft = 0,
    dialogSwipeRight = 0,
    battleATaps = 0,
    battleBHoldTriggers = 0,
    battleSwipes = 0,
    battleSwipeUp = 0,
    battleSwipeDown = 0,
    battleSwipeLeft = 0,
    battleSwipeRight = 0,
    battleCameraTouchesSuppressed = 0,
    playerHoldStartTriggers = 0,
    playerAvatarInteractionProxies = 0,
    playerAvatarHitDetections = 0,
    systemEdgeCandidates = 0,
    systemEdgeSwipesSuppressed = 0,
    systemEdgeTouchesPromoted = 0,
    nativeControlTouchesBypassed = 0,
    startMenuOutsideBTaps = 0,
    startMenuInsideATaps = 0,
    desktopATaps = 0,
    desktopBTaps = 0,
    cancellations = 0,
  },
}

-- Forward declaration: interaction arrival is defined before the pointer hook
-- that supplies the concrete gesture lookup implementation.
local gestureIsDown
local pointerForGesture
local anyDirectionDown
local restoreNativeZoomSuppression

local function option(key, fallback)
  local value = mod.options:get(key)
  if value == nil then return fallback end
  return value
end

local function msToTicks(ms, fallback)
  local value = tonumber(ms)
  if not value then value = fallback end
  value = math.max(1, value)
  return math.max(1, math.floor(value * FIXED_TICKS_PER_SECOND / 1000 + 0.5))
end

function ControlsFree.pathBudgetProfile()
  local name = tostring(option("pathfinding_budget",
    ControlsFree.DEFAULT_PATH_BUDGET) or ControlsFree.DEFAULT_PATH_BUDGET):lower()

  -- v1.4.5-v1.4.7 exposed LOW and HIGH. Keep old saves deterministic after
  -- simplifying the public ladder to VERY LOW / MEDIUM / FULL.
  if name == "low" then
    name = "very_low"
  elseif name == "high" then
    name = "medium"
  end

  local profile = ControlsFree.pathBudgetProfiles[name]
  if not profile then
    name = ControlsFree.DEFAULT_PATH_BUDGET
    profile = ControlsFree.pathBudgetProfiles[name]
  end
  return profile, name
end

function ControlsFree.pathExpansionLimit(overview)
  local full = math.max(1, (tonumber(overview and overview.width) or 0)
                           * (tonumber(overview and overview.height) or 0) * 2)
  local profile = ControlsFree.pathBudgetProfile()
  local nodes = profile and tonumber(profile.nodes) or nil
  return nodes and math.min(full, math.max(1, nodes)) or full
end

function ControlsFree.recordPathSearch(expanded, maxExpanded, budgetHit)
  expanded = tonumber(expanded) or 0
  state.stats.pathSearches = (state.stats.pathSearches or 0) + 1
  state.stats.pathExpanded = (state.stats.pathExpanded or 0) + expanded
  state.stats.pathMaxExpanded = math.max(state.stats.pathMaxExpanded or 0, expanded)
  if budgetHit then
    state.stats.pathBudgetHits = (state.stats.pathBudgetHits or 0) + 1
  end
end

function ControlsFree.holdSteerBaseDelayMs()
  local value = tonumber(option("hold_steer_delay_ms", DEFAULT_HOLD_STEER_DELAY_MS))
                or DEFAULT_HOLD_STEER_DELAY_MS
  -- Keep legacy/hand-edited option files inside the supported ladder.
  value = math.max(150, math.min(500, value))
  return math.floor((value - 150) / 50 + 0.5) * 50 + 150
end

function ControlsFree.overworldSpeedMultiplier(game)
  -- Game:logicSpeed() is the engine's live authority. In a bare overworld it
  -- resolves speedOverworld, while also respecting --speed/POKEPORT_SPEED and
  -- core.logic_speed overrides. The saved option is only a compatibility
  -- fallback for a future/older host that does not expose logicSpeed here.
  if game and type(game.logicSpeed) == "function" then
    local ok, value = pcall(game.logicSpeed, game)
    value = ok and tonumber(value) or nil
    if value and value >= 1 then return value end
  end
  local opts = game and game.save and game.save.options
  local value = opts and tonumber(opts.speedOverworld) or nil
  return (value and value >= 1) and value or 1
end

function ControlsFree.holdSteerDelayMs(game)
  return ControlsFree.holdSteerBaseDelayMs() * ControlsFree.overworldSpeedMultiplier(game)
end

local function holdSteerDelayTicks(game)
  return msToTicks(ControlsFree.holdSteerDelayMs(game), DEFAULT_HOLD_STEER_DELAY_MS)
end

local function performanceInputProfile()
  local name = tostring(option("performance_input_frequency",
                               DEFAULT_PERFORMANCE_INPUT_FREQUENCY) or ""):lower()
  local profile = PERFORMANCE_INPUT_PROFILES[name]
  if not profile then
    name = DEFAULT_PERFORMANCE_INPUT_FREQUENCY
    profile = PERFORMANCE_INPUT_PROFILES[name]
  end
  return profile, name
end

local function holdRefreshTicks()
  local profile = performanceInputProfile()
  return msToTicks(profile.holdMs, profile.holdMs)
end

local function previewRefreshTicks()
  return ControlsFree.VOXEL_PATH_REFRESH_TICKS
end

local function key(x, y)
  return tostring(x) .. "," .. tostring(y)
end

local function edgeKey(x, y, nx, ny)
  return key(x, y) .. ">" .. key(nx, ny)
end

local function copyFlat(src)
  local out = {}
  for k, v in pairs(src or {}) do out[k] = v end
  return out
end

local function cellChar(overview, x, y)
  if not overview or x < 0 or y < 0
      or x >= overview.width or y >= overview.height then
    return nil
  end
  local row = overview.rows and overview.rows[y + 1]
  if not row then return nil end
  return row:sub(x + 1, x + 1)
end

local function evenCeil(n)
  local v = math.ceil(n)
  if v % 2 ~= 0 then v = v + 1 end
  return v
end

-- Renderer.worldViewSize() is intentionally inferred from the public
-- render.compose context instead of requiring Renderer/Zoom internals.
-- In the normal flat renderer the world canvas is even-sized ceil(P/s).
-- Tilt grows that canvas and a custom world pipeline exposes worldOverride,
-- so both fail closed instead of mapping a tap to the wrong cell.
local function inferFlatWorldScale(ctx, worldW, worldH)
  if not ctx or not worldW or not worldH then return nil end
  local fit = tonumber(ctx.scale) or 1
  local maxScale = math.max(16, math.ceil(fit * 2 + 8))

  local bases = {
    { tonumber(ctx.pw), tonumber(ctx.ph) },
  }

  -- Faithful Ratio on mobile sizes the world from the locked viewport rather
  -- than the entire drawable.  render.compose exposes enough information to
  -- recognize that case without requiring private renderer state.
  if ctx.uiw and ctx.uih then
    bases[#bases + 1] = { tonumber(ctx.uiw) * fit, tonumber(ctx.uih) * fit }
  end

  for _, base in ipairs(bases) do
    local bw, bh = base[1], base[2]
    if bw and bh and bw > 0 and bh > 0 then
      for s = 1, maxScale do
        if evenCeil(bw / s) == worldW and evenCeil(bh / s) == worldH then
          return s
        end
      end
    end
  end

  return nil
end

local function captureView(ctx)
  -- Keep framebuffer metadata even when a third-party render pipeline owns
  -- the world.  Voxel picking needs LOVE-units -> framebuffer conversion,
  -- while the normal flat path additionally needs the world-canvas geometry.
  if not ctx then
    state.frame = nil
    state.view = nil
    return
  end

  local dpiX, dpiY = tonumber(ctx.dpiX) or 1, tonumber(ctx.dpiY) or 1
  local pw, ph = tonumber(ctx.pw), tonumber(ctx.ph)
  if (not pw or not ph) and love and love.graphics
      and type(love.graphics.getPixelDimensions) == "function" then
    local ok, fw, fh = pcall(love.graphics.getPixelDimensions)
    if ok then pw, ph = tonumber(fw), tonumber(fh) end
  end
  if (not pw or not ph) and love and love.graphics
      and type(love.graphics.getDimensions) == "function" then
    local ok, uw, uh = pcall(love.graphics.getDimensions)
    if ok and uw and uh then
      pw, ph = tonumber(uw) * dpiX, tonumber(uh) * dpiY
    end
  end
  if dpiX <= 0 then dpiX = 1 end
  if dpiY <= 0 then dpiY = 1 end

  state.frame = {
    dpiX = dpiX, dpiY = dpiY,
    pw = pw, ph = ph,
    -- render.compose exposes ww/wh in LOVE units and pw/ph in framebuffer
    -- pixels.  A Voxel pipeline renders its canvas in framebuffer pixels, so
    -- keeping both lets the picker map a touch to the ACTUAL 3D canvas rather
    -- than assuming dpiX/dpiY happened to describe a third-party surface.
    ww = tonumber(ctx.ww) or (pw and pw / dpiX) or nil,
    wh = tonumber(ctx.wh) or (ph and ph / dpiY) or nil,
    worldActive = ctx.worldActive == true,
    worldOverride = ctx.worldOverride and true or false,
    generation = tonumber(ctx.generation),
  }

  -- Gold's camera is advanced inside World:draw(), before render.compose is
  -- raised.  Snapshot the exact camera/zoom/perspective geometry that produced
  -- THIS visible frame instead of re-reading mutable presentation state later
  -- from input.pointer.  This fixes two alignment hazards at once:
  --   * flat Gold floors the rendered map origin to an integer screen pixel;
  --   * TILT grows the ground capture beyond the window, projects inside that
  --     larger canvas, then crops it back with a negative centred translation.
  -- A pointer should invert the frame the player actually saw, not a close
  -- approximation of the next frame's camera.
  if state.frame.generation == 2 and state.frame.worldActive
      and not state.frame.worldOverride then
    local game = state.game
    local world = game and game.world
    if world and world.map and world.camera and type(world.zoomScale) == "function" then
      local okScale, goldScale = pcall(world.zoomScale, world)
      goldScale = okScale and tonumber(goldScale) or nil
      local ww, wh = tonumber(state.frame.ww), tonumber(state.frame.wh)
      if goldScale and goldScale > 0 and ww and wh and ww > 0 and wh > 0 then
        local captureW, captureH = ww, wh
        local cropX, cropY = 0, 0
        local tiltActive, tiltAngle, tiltFocal = false, 0, 1
        local okTilt, Tilt = pcall(require, "src.render.Tilt")
        if okTilt and type(Tilt) == "table"
            and type(Tilt.active) == "function" and Tilt.active() == true then
          tiltActive = true
          tiltAngle = tonumber(Tilt.angle) or 0
          tiltFocal = tonumber(Tilt.FOCAL) or 1
          if type(Tilt.viewGrowth) == "function" then
            local okGrowth, growth = pcall(Tilt.viewGrowth)
            growth = okGrowth and tonumber(growth) or nil
            if growth and growth > 0 then
              captureW, captureH = math.ceil(ww * growth), math.ceil(wh * growth)
              cropX, cropY = (ww - captureW) / 2, (wh - captureH) / 2
            end
          end
        end
        local cameraX = tonumber(world.camera.x) or 0
        local cameraY = tonumber(world.camera.y) or 0
        state.frame.gold = {
          mapId = world.map.id,
          scale = goldScale,
          cameraX = cameraX, cameraY = cameraY,
          -- World:drawGround uses these exact integer origins.
          originX = math.floor(-cameraX * goldScale),
          originY = math.floor(-cameraY * goldScale),
          windowW = ww, windowH = wh,
          captureW = captureW, captureH = captureH,
          cropX = cropX, cropY = cropY,
          tiltActive = tiltActive, tiltAngle = tiltAngle, tiltFocal = tiltFocal,
        }
      end
    end
  end

  if not ctx.worldActive or not ctx.worldCanvas or ctx.worldOverride then
    state.view = nil
    return
  end

  local okW, worldW = pcall(ctx.worldCanvas.getWidth, ctx.worldCanvas)
  local okH, worldH = pcall(ctx.worldCanvas.getHeight, ctx.worldCanvas)
  if not okW or not okH or not worldW or not worldH then
    state.view = nil
    return
  end

  local scale = inferFlatWorldScale(ctx, worldW, worldH)
  if not scale or not pw or not ph then
    state.view = nil
    return
  end

  state.view = {
    worldW = worldW,
    worldH = worldH,
    scale = scale,
    pw = pw,
    ph = ph,
    dpiX = dpiX,
    dpiY = dpiY,
    ox = math.floor((pw - worldW * scale) / 2),
    oy = math.floor((ph - worldH * scale) / 2),
  }
end

-- Generation boundary ---------------------------------------------------------
-- Gold is a separate overworld engine. Keep every generation-specific read
-- behind this narrow adapter so the shared planner never has to know whether
-- its grid came from Gen I tiles or Gen II COLL_* permissions.
local WorldBackend = { gen1 = {}, gold = {} }

function WorldBackend.isGold(game)
  return game ~= nil and game.world ~= nil and game.overworld == nil
end

function WorldBackend.forGame(game)
  return WorldBackend.isGold(game) and WorldBackend.gold or WorldBackend.gen1
end

function WorldBackend.gen1.owner(game) return game and game.overworld or nil end
function WorldBackend.gen1.player(game)
  local ow = WorldBackend.gen1.owner(game)
  return ow and ow.player or nil
end
function WorldBackend.gen1.map(game)
  local ow = WorldBackend.gen1.owner(game)
  return ow and ow.map or nil
end
function WorldBackend.gen1.overview(game)
  return mod.world and mod.world.mapOverview and mod.world:mapOverview() or nil
end
function WorldBackend.gen1.mapDefinitions(game)
  return game and game.data and game.data.maps or {}
end
function WorldBackend.gen1.defLooksOutdoor(_, def)
  if not def then return false end
  if def.outdoor ~= nil then return def.outdoor == true end
  local env = def.environment
  if env then return env == "TOWN" or env == "ROUTE" or env == "OUTDOOR" end
  return false
end

function WorldBackend.gold.owner(game) return game and game.world or nil end
function WorldBackend.gold.player(game)
  local world = WorldBackend.gold.owner(game)
  return world and world.player or nil
end
function WorldBackend.gold.map(game)
  local world = WorldBackend.gold.owner(game)
  return world and world.map or nil
end
function WorldBackend.gold.permissionsModule()
  if ControlsFree.goldPermissions ~= nil then
    return ControlsFree.goldPermissions or nil
  end
  local ok, module = pcall(require, "src.world.gen2.Permissions")
  ControlsFree.goldPermissions = ok and module or false
  return ok and module or nil
end
function WorldBackend.gold.fieldMovesModule()
  if ControlsFree.goldFieldMoves ~= nil then
    return ControlsFree.goldFieldMoves or nil
  end
  local ok, module = pcall(require, "src.world.gen2.FieldMoves")
  ControlsFree.goldFieldMoves = ok and module or false
  return ok and module or nil
end
function WorldBackend.gold.hiddenItemsModule()
  if ControlsFree.goldHiddenItems ~= nil then
    return ControlsFree.goldHiddenItems or nil
  end
  local ok, module = pcall(require, "src.world.gen2.HiddenItems")
  ControlsFree.goldHiddenItems = ok and module or false
  return ok and module or nil
end
function WorldBackend.gold.mapModule()
  if ControlsFree.goldMapModule ~= nil then
    return ControlsFree.goldMapModule or nil
  end
  local ok, module = pcall(require, "src.world.gen2.Map")
  ControlsFree.goldMapModule = ok and module or false
  return ok and module or nil
end
function WorldBackend.gold.mapDefinitions(game)
  local world = WorldBackend.gold.owner(game)
  return world and world.maps or {}
end
function WorldBackend.gold.defLooksOutdoor(_, def)
  local env = def and def.environment
  return env == "TOWN" or env == "ROUTE"
end
function WorldBackend.gold.isSurfing(game)
  local world = WorldBackend.gold.owner(game)
  local field = WorldBackend.gold.fieldMovesModule()
  if not (world and field and type(field.isSurfing) == "function") then return false end
  return field.isSurfing(world.playerState) == true
end
function ControlsFree.goldNativeForcedDirection(game)
  if not WorldBackend.isGold(game) then return nil end
  local world = WorldBackend.gold.owner(game)
  local player = WorldBackend.gold.player(game)
  local map = WorldBackend.gold.map(game)
  local P = WorldBackend.gold.permissionsModule()
  if not (world and player and map and P and type(map.cellCollision) == "function") then
    return nil
  end
  local ok, coll = pcall(map.cellCollision, map, player.cellX, player.cellY)
  if not ok then return nil end
  local dir
  if type(P.currentDirection) == "function" then dir = P.currentDirection(coll) end
  if not dir and type(P.doorForcedDirection) == "function" then
    dir = P.doorForcedDirection(coll)
  end
  if not dir and type(P.isIce) == "function" and P.isIce(coll) then
    dir = world.turningDirection
  end
  return dir
end
function WorldBackend.gold.warpFiresAt(game, map, x, y)
  local P = WorldBackend.gold.permissionsModule()
  if not (P and map and type(map.cellCollision) == "function") then return false end
  local ok, coll = pcall(map.cellCollision, map, x, y)
  if not ok then return false end
  return (type(P.isWarpCollision) == "function" and P.isWarpCollision(coll) == true)
      or (type(P.carpetDirection) == "function" and P.carpetDirection(coll) ~= nil)
end
function WorldBackend.gold.overview(game)
  local map = WorldBackend.gold.map(game)
  local P = WorldBackend.gold.permissionsModule()
  if not (map and P) then return nil end
  local width = tonumber(map.widthCells) or (tonumber(map.width) and map.width * 2)
  local height = tonumber(map.heightCells) or (tonumber(map.height) and map.height * 2)
  if not width or not height or width <= 0 or height <= 0 then return nil end
  -- Gold's collision grid is integral. Canonicalising avoids textual A* keys
  -- such as `5` versus `5.0` if a custom/test map supplied float dimensions.
  width, height = math.floor(width), math.floor(height)
  local rows = {}
  for y = 0, height - 1 do
    local chars = {}
    for x = 0, width - 1 do
      local ch = " "
      local ok, coll = pcall(map.cellCollision, map, x, y)
      if ok and coll ~= nil then
        if WorldBackend.gold.warpFiresAt(game, map, x, y)
            and type(map.warpAt) == "function" and map:warpAt(x, y) then
          ch = "+"
        elseif type(P.isWhirlpool) == "function" and P.isWhirlpool(coll) then
          -- HM06 is deliberately outside the first Gold automation scope.
          -- Its COLL_* byte has WATER permission, so a plain water test would
          -- incorrectly route straight through the obstacle.
          ch = " "
        elseif type(P.currentDirection) == "function" and P.currentDirection(coll) ~= nil then
          -- $3x currents (including waterfall/down-current cells) are owned by
          -- the native forced-movement model below.  Keeping them out of the
          -- ordinary water grid prevents A* from walking against the current;
          -- a validated special FORCED edge is the only way through.
          ch = " "
        elseif type(P.isWater) == "function" and P.isWater(coll) then
          ch = "~"
        elseif type(P.isWalkable) == "function" and P.isWalkable(coll) then
          ch = "."
        end
      end
      chars[#chars + 1] = ch
    end
    rows[#rows + 1] = table.concat(chars)
  end
  return { mapId = map.id, width = width, height = height, rows = rows }
end

function WorldBackend.owner(game) return WorldBackend.forGame(game).owner(game) end
function WorldBackend.player(game) return WorldBackend.forGame(game).player(game) end
function WorldBackend.map(game) return WorldBackend.forGame(game).map(game) end
function WorldBackend.overview(game) return WorldBackend.forGame(game).overview(game) end
function WorldBackend.mapDefinitions(game)
  return WorldBackend.forGame(game).mapDefinitions(game)
end
function WorldBackend.defLooksOutdoor(game, def)
  return WorldBackend.forGame(game).defLooksOutdoor(game, def)
end

function WorldBackend.gen1.isControllable(game)
  if not game or not game.overworld or not game.stack
      or type(game.stack.top) ~= "function" then
    return false, "no_overworld"
  end
  local ow = game.overworld
  if game.stack:top() ~= ow then return false, "overlay_or_battle" end
  if ow.transitioning then return false, "transition" end
  local fm = game.data and game.data.field and game.data.field.forcedMovement
  if game.save and game.save.onBike and fm and fm.slopeMaps and ow.map then
    for _, mapId in ipairs(fm.slopeMaps) do
      if mapId == ow.map.id then return false, "forced_bike_slope" end
    end
  end
  if ow.engaging then return false, "trainer_engagement" end
  if ow.emote then return false, "emote" end
  if ow.runner and ow.runner.isRunning and ow.runner:isRunning() then
    return false, "script"
  end
  local player = ow.player
  if player and player.inputLocked then return false, "input_locked" end
  if player and player.spinning then return false, "forced_movement" end
  if player and player.fishing then return false, "fishing" end
  return true
end

function WorldBackend.gold.isControllable(game)
  local world = WorldBackend.gold.owner(game)
  local player = WorldBackend.gold.player(game)
  if not (game and world and world.map and player) then return false, "no_gold_world" end
  if game.phase ~= nil and game.phase ~= "play" then return false, "not_play_phase" end
  if game.stack and type(game.stack.top) == "function" and game.stack:top() ~= nil then
    return false, "overlay_or_battle"
  end
  if type(world.busy) == "function" then
    local ok, busy = pcall(world.busy, world)
    if not ok then return false, "busy_unknown" end
    if busy then return false, "world_busy" end
  end
  if world.mapSetup or world.pendingWarp or world.pendingSceneScript then
    return false, "transition"
  end
  if world.fishing or world.headbutt or world.fieldMove or world.queuedFieldMove
      or world.queuedScript or world.moveState then
    return false, "native_action"
  end
  return true
end

local function overworldGate(game)
  local backend = WorldBackend.forGame(game)
  return backend.isControllable(game)
end

local function releaseHold(nav)
  if nav and nav.hold then
    mod.input:release(nav.hold)
    nav.hold = nil
    nav.holdDir = nil
    nav.expectedX = nil
    nav.expectedY = nil
  end
end

local function markStop(reason, nav)
  state.lastStop = {
    reason = reason or "unknown",
    tick = state.tick,
    mapId = nav and nav.mapId or nil,
    targetX = nav and (nav.requestedX or nav.targetX) or nil,
    targetY = nav and (nav.requestedY or nav.targetY) or nil,
  }
end

local function cancelRoute(reason)
  local nav = state.nav
  if not nav then return false end
  releaseHold(nav)
  markStop(reason or "cancelled", nav)
  if reason ~= "arrived" and reason ~= "retargeted"
      and reason ~= "hold_retargeted" then
    state.stats.cancellations = state.stats.cancellations + 1
  end
  if reason == "manual_override" and state.tapOwner then
    local pointer = state.pointers[state.tapOwner]
    if pointer then
      pointer.manualSuppressed = true
      pointer.gestureSuppressed = "manual_override"
    end
  end
  if nav.exitJourney then state.exitJourney = nil end
  state.nav = nil
  return true
end

local function finishRoute()
  local nav = state.nav
  if not nav then return end
  releaseHold(nav)

  -- Gold endpoint interaction is deliberately a SECOND-STAGE decision.  The
  -- proven test7 movement core first reaches its ordinary destination.  Only
  -- after the player is genuinely stationary do we ask whether the original
  -- tap was probably aimed at an adjacent native interaction surface (PC, NPC,
  -- sign/fixture/counter, item ball or hidden treasure).  Keeping this out of
  -- initial route classification means a missed semantic hit can never break
  -- ordinary Tap to Move or Smart Exit.
  if ControlsFree.goldPromoteEndpointInteraction and state.game and WorldBackend.isGold(state.game) then
    local cur = mod.world and mod.world:current()
    if cur and cur.mapId == nav.mapId
        and ControlsFree.goldPromoteEndpointInteraction(state.game, nav, cur) then
      return
    end
  end

  state.stats.routesArrived = state.stats.routesArrived + 1
  markStop("arrived", nav)
  state.nav = nil
end

local function setPhase(nav, phase, reason)
  if not nav then return end
  nav.phase = phase
  nav.phaseReason = reason
end

local function setPulse(kind, x, y)
  if option("feedback", true) == false then return end
  state.stats.feedbackPulses = state.stats.feedbackPulses + 1
  state.pulse = {
    kind = kind or "accepted",
    x = x,
    y = y,
    untilTick = state.tick + 15,
  }
end

-- WorldAPI does not yet expose an iterator over all live collision entities.
-- Keep this single, read-only fallback centralized: the route is still
-- validated by the engine's final movement.collision verdict before a step can
-- happen, so stale or changed runtime details can only trigger a replan.
--
-- Returns three sets: all occupied cells, cells occupied by actors that can
-- move away (wandering or currently moving), and static blocking entities.
local function liveOccupancy(game)
  local backend = WorldBackend.forGame(game)
  local owner = backend.owner(game)
  local entities = owner and (owner.npcs or owner.entities) or nil
  local cache = ControlsFree.occupancyCache
  if cache and cache.tick == state.tick and cache.ow == owner
      and cache.npcs == entities then
    state.stats.occupancyCacheHits = (state.stats.occupancyCacheHits or 0) + 1
    return cache.all, cache.dynamic, cache.static
  end

  local all, dynamic, static = {}, {}, {}
  for _, entity in ipairs(entities or {}) do
    if entity ~= WorldBackend.player(game) and not entity.passable then
      local isDynamic = entity.wanders == true or entity.moving == true
          or entity.pattern == "walk"
      local dst = isDynamic and dynamic or static
      local function add(x, y)
        if type(x) == "number" and type(y) == "number" then
          local function put(px, py)
            local k = key(px, py)
            all[k] = true; dst[k] = true
          end
          put(x, y)
          if WorldBackend.isGold(game) and entity.bigObject then
            put(x + 1, y); put(x, y + 1); put(x + 1, y + 1)
          end
        end
      end
      add(entity.cellX, entity.cellY)
      add(entity.targetX, entity.targetY)
    end
  end
  ControlsFree.occupancyCache = {
    tick = state.tick, ow = owner, npcs = entities,
    all = all, dynamic = dynamic, static = static,
  }
  state.stats.occupancyCacheMisses = (state.stats.occupancyCacheMisses or 0) + 1
  return all, dynamic, static
end

local function entityById(game, id)
  local owner = WorldBackend.owner(game)
  for _, entity in ipairs((owner and (owner.npcs or owner.entities)) or {}) do
    if entity.id == id or (entity.def and entity.def.index == id) then return entity end
  end
  return nil
end

local function entityIsInteractable(entity)
  if not entity or entity.passable then return false end
  if entity.pikachuFollower then return true end
  local def = entity.def or {}
  if def.pushable == true or def.sprite == "SPRITE_BOULDER" then return false end
  return def.text ~= nil or def.item ~= nil or def.pokemon ~= nil
      or def.trainer ~= nil or def.trainerClass ~= nil or def.script ~= nil
end

function WorldBackend.gold.entityIsInteractable(entity)
  if not entity or entity.passable then return false end
  local def = entity.def or {}
  if def.pushable == true or def.movement == 0x19 then return false end
  return def.trainer ~= nil or def.itemball ~= nil or def.scriptKey ~= nil
      or def.script ~= nil or def.std ~= nil
end

local function counterAt(game, x, y)
  local map = WorldBackend.map(game)
  if not map or type(map.isCounterCell) ~= "function" then return false end
  local ok, yes = pcall(map.isCounterCell, map, x, y)
  return ok and yes == true
end

local function fieldRows(game, keyName, mapId)
  local field = game and game.data and game.data.field or {}
  local extras = field.hiddenExtras or {}
  local bucket = extras[keyName]
  if bucket == nil then bucket = field[keyName] end
  if type(bucket) ~= "table" then return {} end
  local perMap = bucket[mapId]
  if type(perMap) == "table" then return perMap end
  -- Some one-map extras (notably the Vermilion Gym trash puzzle) carry the
  -- map id on the record rather than nesting the rows by map.
  if bucket.map == mapId then
    if type(bucket.rows) == "table" then return bucket.rows end
    if type(bucket.cans) == "table" then return bucket.cans end
    if type(bucket.entries) == "table" then return bucket.entries end
  end
  return {}
end

local function staticInteractionAt(game, mapId, map, x, y)
  if WorldBackend.isGold(game) then return nil end
  local function hit(kind, rows, facingFn)
    for _, row in ipairs(rows or {}) do
      if tonumber(row.x) == x and tonumber(row.y) == y then
        local facing = facingFn and facingFn(row) or row.facing
        return {
          kind = kind, x = x, y = y, mapId = mapId,
          requiredFacing = facing,
          clickedX = x, clickedY = y,
        }
      end
    end
  end

  -- These are the same extracted hidden-event surfaces the engine's own
  -- OverworldState:interact dispatches.  "Hidden" here means they are not NPC
  -- object_events, not that the mod should reveal hidden items: item/coin
  -- treasure tables are intentionally absent from this list.
  local out =
    hit("pc", fieldRows(game, "pcTiles", mapId))
    or hit("bench", fieldRows(game, "benchGuys", mapId),
           function(row) return row.textFacing or row.facing end)
    or hit("gym_statue", fieldRows(game, "gymStatues", mapId))
    or hit("trash", fieldRows(game, "printTrash", mapId),
           function() return nil end)
    or hit("slot", fieldRows(game, "slotMachines", mapId))
    or hit("trash_can", fieldRows(game, "trashCans", mapId))
  if out then return out end

  -- Bill's cell-separator PC is a hand-ported hidden-event special rather
  -- than one of the generic PC rows in older/newer caches.
  if mapId == "BILLS_HOUSE" and x == 1 and y == 4 then
    return { kind = "bill_pc", x = x, y = y, mapId = mapId,
             requiredFacing = "up", clickedX = x, clickedY = y }
  end

  -- Bookshelves, town maps, elevator panels and "stuff" furniture are
  -- data-driven by tileset + collision tile.  Vanilla only activates these
  -- while facing up, so model that exact affordance rather than treating the
  -- whole wall as walkable.
  local shelves = game and game.data and game.data.field
      and game.data.field.bookshelves
  local byTileset = shelves and map and map.def and shelves[map.def.tileset]
  if byTileset and type(map.cellTile) == "function" then
    local ok, tile = pcall(map.cellTile, map, x, y)
    if ok and byTileset[tile] then
      return { kind = "bookshelf", x = x, y = y, mapId = mapId,
               requiredFacing = "up", clickedX = x, clickedY = y }
    end
  end

  local signs = map and map.def and map.def.signs or {}
  for _, sign in ipairs(signs) do
    if sign.x == x and sign.y == y then
      return { kind = "sign", x = x, y = y, mapId = mapId,
               clickedX = x, clickedY = y }
    end
  end
  return nil
end

local function entityInteraction(entity, x, y)
  return {
    kind = "entity", entityId = entity.id,
    clickedX = x, clickedY = y,
    chase = entity.wanders == true or entity.moving == true,
  }
end

-- Secret treasure remains invisible to generic semantic scans. It becomes an
-- interaction only when the player explicitly taps ITS exact world cell.
-- This mirrors OverworldState:tryHiddenObject without calling it remotely:
-- normal A at arrival is still what actually awards the item/coins and marks
-- save.hiddenTaken.
function WorldBackend.gold.bgInteractionAt(game, x, y)
  local world = WorldBackend.gold.owner(game)
  local map = world and world.map
  local required = { [1] = "up", [2] = "down", [3] = "right", [4] = "left" }
  for _, ev in ipairs((map and map.def and map.def.bgEvents) or {}) do
    if tonumber(ev.x) == x and tonumber(ev.y) == y then
      local kind = tonumber(ev.kind or 0) or 0
      -- Item bg events are secret treasure and are intentionally handled only
      -- by the exact-tap hidden-item path below.
      if kind == 7 or kind == 8 or not (ev.scriptKey or ev.script) then return nil end
      if kind == 5 or kind == 6 then
        if not ev.event then return nil end
        local set = false
        if world.events and type(world.events.get) == "function" then
          local ok, value = pcall(world.events.get, world.events, ev.event)
          set = ok and value == true
        end
        if (kind == 5) ~= set then return nil end
      elseif kind ~= 0 and not required[kind] then
        return nil
      end
      return { kind = "gold_bg", x = x, y = y, mapId = map.id,
               requiredFacing = required[kind], clickedX = x, clickedY = y,
               goldBgEvent = true }
    end
  end
  return nil
end

-- Gold TileCollisionStdScripts (data/collision/collision_stdscripts.asm).
-- These are NOT bgEvents.  Pokecenter PCs in particular exist only through
-- COLL_PC -> PCScript, so a semantic picker that scans objects/bgEvents alone
-- can never recognize the computer the player is visibly tapping.
WorldBackend.gold.stdCollisionSemantics = {
  [0x91] = "bookshelf",       -- COLL_BOOKSHELF
  [0x93] = "pc",              -- COLL_PC
  [0x94] = "radio",           -- COLL_RADIO
  [0x95] = "town_map",        -- COLL_TOWN_MAP
  [0x96] = "mart_shelf",      -- COLL_MART_SHELF
  [0x97] = "tv",              -- COLL_TV
  [0x9d] = "window",          -- COLL_WINDOW
  [0x9f] = "incense_burner",  -- COLL_INCENSE_BURNER
}

function WorldBackend.gold.stdCollisionInteractionAt(game, x, y)
  local world = WorldBackend.gold.owner(game)
  local map = world and world.map
  if not (map and type(map.cellCollision) == "function") then return nil end
  local ok, coll = pcall(map.cellCollision, map, x, y)
  if not ok then return nil end
  coll = tonumber(coll)
  local semantic = coll and WorldBackend.gold.stdCollisionSemantics[coll % 256] or nil
  if not semantic then return nil end
  return { kind = "gold_std_collision", semantic = semantic,
           collision = coll % 256, x = x, y = y, mapId = map.id,
           clickedX = x, clickedY = y, goldStdCollision = true }
end

function WorldBackend.gold.interactionAt(game, x, y)
  local world = WorldBackend.gold.owner(game)
  local map = world and world.map
  if not (world and map) then return nil end
  local entity
  if type(world.npcAt) == "function" then
    local ok, found = pcall(world.npcAt, world, x, y)
    if ok then entity = found end
  end
  if entity and WorldBackend.gold.entityIsInteractable(entity) then
    return entityInteraction(entity, x, y)
  end
  local std = WorldBackend.gold.stdCollisionInteractionAt(game, x, y)
  if std then return std end
  local fixed = WorldBackend.gold.bgInteractionAt(game, x, y)
  if fixed then return fixed end
  if counterAt(game, x, y) and type(world.npcAt) == "function" then
    for _, d in ipairs(DIRS) do
      local ok, found = pcall(world.npcAt, world, x + d.dx, y + d.dy)
      if ok and found and WorldBackend.gold.entityIsInteractable(found) then
        local out = entityInteraction(found, x, y)
        out.counterProxy = true
        out.preferredFacing = d.name
        return out
      end
    end
  end
  return nil
end

local function hiddenTreasureInteractionAt(game, mapId, x, y)
  if WorldBackend.isGold(game) then
    local world = WorldBackend.gold.owner(game)
    local map = world and world.map
    if not (map and map.id == mapId) then return nil end
    local Hidden = WorldBackend.gold.hiddenItemsModule()
    if not (Hidden and type(Hidden.at) == "function") then return nil end
    local ok, row = pcall(Hidden.at, map.def, x, y, world.events)
    if not ok or not row then return nil end
    return { kind = "hidden_item", x = x, y = y, mapId = mapId,
             clickedX = x, clickedY = y, hiddenTreasure = true,
             goldHiddenItem = true }
  end

  local field = game and game.data and game.data.field
  local save = game and game.save
  if not (field and save and mapId and type(x) == "number" and type(y) == "number") then
    return nil
  end
  local takenKey = mapId .. "_" .. x .. "_" .. y
  if save.hiddenTaken and save.hiddenTaken[takenKey] then return nil end
  local function exact(bucket, kind)
    local rows = type(bucket) == "table" and bucket[mapId] or nil
    if type(rows) ~= "table" then return nil end
    for _, row in ipairs(rows) do
      if tonumber(row.x) == x and tonumber(row.y) == y then
        return { kind = kind, x = x, y = y, mapId = mapId,
                 clickedX = x, clickedY = y, hiddenTreasure = true }
      end
    end
  end
  return exact(field.hiddenItems, "hidden_item")
      or exact(field.hiddenCoins, "hidden_coins")
end

local function interactionAt(game, x, y)
  if WorldBackend.isGold(game) then
    return WorldBackend.gold.interactionAt(game, x, y)
  end
  local ow = game and game.overworld
  if not ow then return nil end
  for _, entity in ipairs(ow.npcs or {}) do
    if entityIsInteractable(entity)
        and ((entity.cellX == x and entity.cellY == y)
          or (entity.targetX == x and entity.targetY == y)) then
      return entityInteraction(entity, x, y)
    end
  end
  local fixed = staticInteractionAt(game, ow.map and ow.map.id, ow.map, x, y)
  if fixed then return fixed end
  if counterAt(game, x, y) then
    for _, d in ipairs(DIRS) do
      local bx, by = x + d.dx, y + d.dy
      for _, entity in ipairs(ow.npcs or {}) do
        if entityIsInteractable(entity)
            and ((entity.cellX == bx and entity.cellY == by)
              or (entity.targetX == bx and entity.targetY == by)) then
          local out = entityInteraction(entity, x, y)
          out.counterProxy = true; out.preferredFacing = d.name
          return out
        end
      end
    end
  end
  return nil
end

-- Fixed hidden-event surfaces that are safe to expose as explicit tap targets.
-- Fixed hidden-event surfaces that are safe to expose as explicit tap targets.
-- These are hidden in the Gen I data model (they are not object_event NPCs),
-- but they are ordinary visible furniture/fixtures: PCs, benches, gym statues,
-- trash cans and slot machines. Secret floor items/coins are deliberately NOT
-- listed here, so Tap to Move never reveals treasure the player has not found.
function ControlsFree.fixedHiddenInteractionCandidates(game, mapId, map)
  if WorldBackend.isGold(game) then return {} end
  local out, seen = {}, {}
  local function add(x, y)
    x, y = tonumber(x), tonumber(y)
    if not x or not y then return end
    local k = key(x, y)
    if seen[k] then return end
    local interaction = staticInteractionAt(game, mapId, map, x, y)
    if not interaction then return end
    seen[k] = true
    out[#out + 1] = interaction
  end

  for _, keyName in ipairs({
      "pcTiles", "benchGuys", "gymStatues", "printTrash",
      "slotMachines", "trashCans",
    }) do
    for _, row in ipairs(fieldRows(game, keyName, mapId)) do
      add(row.x, row.y)
    end
  end

  -- Bill's cell-separator PC is hand-ported rather than generic pcTiles.
  if mapId == "BILLS_HOUSE" then add(1, 4) end
  return out
end

local function interactionTarget(game, interaction)
  if not interaction then return nil end
  if interaction.kind ~= "entity" then
    return interaction.x, interaction.y, nil
  end
  local entity = entityById(game, interaction.entityId)
  if not entity then return nil, nil, nil, "gone" end
  -- Follow identity, not the coordinate originally tapped.  While an NPC is
  -- mid-step, targetX/targetY is its reserved landing cell; as soon as it
  -- chooses another wander step the route is rebuilt toward the new one.
  local x = entity.moving and entity.targetX or entity.cellX
  local y = entity.moving and entity.targetY or entity.cellY
  x = type(x) == "number" and x or entity.cellX
  y = type(y) == "number" and y or entity.cellY
  return x, y, entity
end

local function cleanupTempBlocks(nav, dynamicNow)
  if not nav then return end
  for k, expires in pairs(nav.tempBlocked or {}) do
    -- A temporary entity block can be forgotten early once no dynamic actor
    -- currently occupies/reserves that cell.  Otherwise keep it until expiry
    -- to avoid immediately retrying the same moving collision on the next tick.
    if expires <= state.tick or (dynamicNow and not dynamicNow[k]) then
      nav.tempBlocked[k] = nil
    end
  end
end

-- CUT route support -----------------------------------------------------------
-- Cache only geometry, never eligibility. partyKnows("CUT") remains the live
-- authority for Cascade Badge + party move + fieldmove.eligibility hooks.
ControlsFree.cutGeometryCache = ControlsFree.cutGeometryCache
  or setmetatable({}, { __mode = "k" })

function ControlsFree.cutEligible(game)
  if WorldBackend.isGold(game) then return false end
  local ow = game and game.overworld
  return ow and type(ow.partyKnows) == "function"
      and ow:partyKnows("CUT") ~= nil
end

function ControlsFree.cuttableCells(game, map, overview)
  if WorldBackend.isGold(game) then return nil end
  if not (ControlsFree.cutEligible(game) and map and overview
      and map.def and type(map.cellTile) == "function"
      and type(map.blockAt) == "function"
      and type(map.isWalkableCell) == "function") then
    return nil
  end
  local ts = map.def.tileset
  if ts ~= "OVERWORLD" and ts ~= "GYM" then return nil end

  local ow = game and game.overworld
  local cuts = ow and ow.cutBlocks and ow.cutBlocks[map.id] or nil
  local cutCount = type(cuts) == "table" and #cuts or 0
  local swaps = game and game.data and game.data.field
      and game.data.field.cutTreeSwaps
  if type(swaps) ~= "table" then return nil end

  local cached = ControlsFree.cutGeometryCache[map]
  if cached and cached.cutCount == cutCount and cached.swaps == swaps
      and cached.width == overview.width and cached.height == overview.height then
    return cached.cells
  end

  local before = {}
  for _, sw in ipairs(swaps) do
    if sw.before ~= nil then before[sw.before] = true end
  end

  local cells = {}
  local wantedTile = ts == "OVERWORLD" and 0x3d or 0x50
  for y = 0, overview.height - 1 do
    for x = 0, overview.width - 1 do
      local okTile, tile = pcall(map.cellTile, map, x, y)
      if okTile and tile == wantedTile then
        local okWalk, walkable = pcall(map.isWalkableCell, map, x, y)
        local okBlock, block = pcall(map.blockAt, map,
          math.floor(x / 2), math.floor(y / 2))
        if okWalk and okBlock and not walkable and before[block] then
          cells[key(x, y)] = true
        end
      end
    end
  end

  ControlsFree.cutGeometryCache[map] = {
    cutCount = cutCount, swaps = swaps,
    width = overview.width, height = overview.height, cells = cells,
  }
  return cells
end

function ControlsFree.cuttableAt(game, map, overview, x, y)
  local cells = ControlsFree.cuttableCells(game, map, overview)
  return cells and cells[key(x, y)] == true or false
end

function WorldBackend.gold.cutTargetAt(game, map, x, y)
  local P = WorldBackend.gold.permissionsModule()
  if not (P and map and type(map.cellCollision) == "function"
      and type(P.isCutTree) == "function") then return false end
  local ok, coll = pcall(map.cellCollision, map, x, y)
  return ok and P.isCutTree(coll) == true
end

function ControlsFree.cutInteractionAt(game, map, overview, x, y)
  if WorldBackend.isGold(game) then
    if not WorldBackend.gold.cutTargetAt(game, map, x, y) then return nil end
    return { kind = "cut_tree", x = x, y = y, mapId = map and map.id,
             clickedX = x, clickedY = y, cutTarget = true, goldNativeCut = true }
  end
  if not ControlsFree.cuttableAt(game, map, overview, x, y) then return nil end
  return { kind = "cut_tree", x = x, y = y, mapId = map and map.id,
           clickedX = x, clickedY = y, cutTarget = true }
end

local function passable(overview, x, y, goalX, goalY, waterMode,
                        occupied, tempBlocked, blockedEdges, blockedCells,
                        fromX, fromY, allowBlockedGoal)
  local ch = cellChar(overview, x, y)
  if not ch then return false end

  local k = key(x, y)
  if occupied and occupied[k] then return false end
  if blockedCells and blockedCells[k] then return false end
  local expires = tempBlocked and tempBlocked[k]
  if expires and expires > state.tick then return false end

  if fromX ~= nil and blockedEdges
      and blockedEdges[edgeKey(fromX, fromY, x, y)] then
    return false
  end

  -- Exit carpets are a special graph endpoint. Gen I can attach a warp
  -- record to a collision cell that is NOT ordinary walkable terrain and
  -- not reported as '+' by mapOverview. Such a cell must remain forbidden
  -- as an intermediate A* node (otherwise routing could accidentally warp),
  -- but an already-validated exit intent may explicitly allow that exact
  -- cell as the final destination.
  if allowBlockedGoal and x == goalX and y == goalY then return true end

  if ch == "." then return true end
  if ch == "~" then return waterMode end
  -- Warp cells are legal only as the requested destination.  Treating a
  -- random door/stair as an intermediate node could silently change maps.
  if ch == "+" then return x == goalX and y == goalY end
  return false
end

local function nodeLess(a, b)
  if a.f ~= b.f then return a.f < b.f end
  if a.h ~= b.h then return a.h < b.h end
  if a.g ~= b.g then return a.g < b.g end
  return a.seq < b.seq
end

local function heapPush(heap, node)
  local i = #heap + 1
  heap[i] = node
  while i > 1 do
    local p = math.floor(i / 2)
    if not nodeLess(heap[i], heap[p]) then break end
    heap[i], heap[p] = heap[p], heap[i]
    i = p
  end
end

local function heapPop(heap)
  if #heap == 0 then return nil end
  local root = heap[1]
  local tail = table.remove(heap)
  if #heap == 0 then return root end
  heap[1] = tail
  local i = 1
  while true do
    local l, r = i * 2, i * 2 + 1
    local best = i
    if l <= #heap and nodeLess(heap[l], heap[best]) then best = l end
    if r <= #heap and nodeLess(heap[r], heap[best]) then best = r end
    if best == i then break end
    heap[i], heap[best] = heap[best], heap[i]
    i = best
  end
  return root
end

local function parseKey(k)
  local sx, sy = k:match("^(-?%d+),(-?%d+)$")
  return tonumber(sx), tonumber(sy)
end

local function reconstruct(cameFrom, cameVia, goalKey)
  -- A* graph nodes are standable cells.  A ledge is a directed two-cell edge
  -- from the standing cell to its landing cell; the engine animates the ledge
  -- tile in between.  Re-insert that midpoint into the executable path so the
  -- existing route follower can observe either the intermediate scripted cell
  -- or a direct two-cell landing without treating faithful movement as an
  -- override.
  local rev = {}
  local k = goalKey
  while k do
    local x, y = parseKey(k)
    rev[#rev + 1] = { x = x, y = y, via = cameVia and cameVia[k] or nil }
    k = cameFrom[k]
  end
  local out = {}
  for i = #rev - 1, 1, -1 do
    local node = rev[i]
    local via = node.via
    if via and via.kind == "ledge" then
      out[#out + 1] = { x = via.midX, y = via.midY, forced = "ledge", dir = via.dir }
    elseif via and via.kind == "forced" and via.entryX ~= nil then
      out[#out + 1] = { x = via.entryX, y = via.entryY,
                        forced = "forced_entry", dir = via.dir }
    end
    out[#out + 1] = { x = node.x, y = node.y, forced = via and via.kind or nil,
                      dir = via and via.dir or nil }
  end
  return out
end

local function findPath(overview, sx, sy, gx, gy, waterMode,
                        occupied, tempBlocked, blockedEdges, blockedCells, specialEdges,
                        allowBlockedGoal)
  if not overview then return nil end
  if sx == gx and sy == gy then return {} end

  -- liveOccupancy normally contains NPCs only, so the player's start cell
  -- is almost never present. Older builds cloned the whole occupancy table for
  -- every search solely to delete that one key. Copy only in the exceptional
  -- case where something actually claims the start cell.
  local startOccupiedKey = key(sx, sy)
  if occupied and occupied[startOccupiedKey] then
    occupied = copyFlat(occupied)
    occupied[startOccupiedKey] = nil
    state.stats.occupancyCopiesRequired =
      (state.stats.occupancyCopiesRequired or 0) + 1
  else
    state.stats.occupancyCopiesAvoided =
      (state.stats.occupancyCopiesAvoided or 0) + 1
  end

  if not passable(overview, gx, gy, gx, gy, waterMode,
                  occupied, tempBlocked, blockedEdges, blockedCells,
                  nil, nil, allowBlockedGoal) then
    return nil
  end

  local startKey = startOccupiedKey
  local goalKey = key(gx, gy)
  local open = {}
  local gScore = { [startKey] = 0 }
  local cameFrom = {}
  local cameVia = {}
  local seq = 0
  local startH = math.abs(gx - sx) + math.abs(gy - sy)
  seq = seq + 1
  heapPush(open, { x = sx, y = sy, g = 0, h = startH, f = startH,
                   k = startKey, seq = seq })

  -- A map overview is finite, but a conservative expansion cap protects a
  -- malformed custom map from turning one tap into an unbounded search.
  local maxExpanded = ControlsFree.pathExpansionLimit(overview)
  local expanded = 0

  while #open > 0 and expanded < maxExpanded do
    local cur = heapPop(open)
    if cur.g == gScore[cur.k] then
      expanded = expanded + 1
      if cur.k == goalKey then
        local path = reconstruct(cameFrom, cameVia, goalKey)
        ControlsFree.recordPathSearch(expanded, maxExpanded, false)
        return path
      end

      for _, d in ipairs(DIRS) do
        local nx, ny = cur.x + d.dx, cur.y + d.dy
        if passable(overview, nx, ny, gx, gy, waterMode,
                    occupied, tempBlocked, blockedEdges, blockedCells,
                    cur.x, cur.y, allowBlockedGoal) then
          local nk = key(nx, ny)
          local ng = cur.g + 1
          if gScore[nk] == nil or ng < gScore[nk] then
            gScore[nk] = ng
            cameFrom[nk] = cur.k
            cameVia[nk] = nil
            local h = math.abs(gx - nx) + math.abs(gy - ny)
            seq = seq + 1
            heapPush(open, { x = nx, y = ny, g = ng, h = h,
                             f = ng + h, k = nk, seq = seq })
          end
        end
      end

      -- Ledges are directed graph edges, not ordinary walkable cells.  The
      -- source/mid/landing geometry is derived from the same generated ledge
      -- table the vanilla overworld uses.  Only the landing cell participates
      -- in A*: the midpoint is injected later by reconstruct().
      for _, jump in ipairs((specialEdges and specialEdges[cur.k]) or {}) do
        local nx, ny = jump.x, jump.y
        local nk = key(nx, ny)
        local ch = cellChar(overview, nx, ny)
        local terrainOK = ch == "." or (ch == "~" and waterMode)
        local targetBlocked = not terrainOK
          or (jump.requiresWater and not waterMode)
          or (occupied and occupied[nk])
          or (blockedCells and blockedCells[nk])
          or (tempBlocked and tempBlocked[nk] and tempBlocked[nk] > state.tick)
          or (blockedEdges and blockedEdges[edgeKey(cur.x, cur.y, nx, ny)])
        if not targetBlocked then
          local ng = cur.g + (jump.cost or 2)
          if gScore[nk] == nil or ng < gScore[nk] then
            gScore[nk] = ng
            cameFrom[nk] = cur.k
            cameVia[nk] = jump
            local h = math.abs(gx - nx) + math.abs(gy - ny)
            seq = seq + 1
            heapPush(open, { x = nx, y = ny, g = ng, h = h,
                             f = ng + h, k = nk, seq = seq })
          end
        end
      end
    end
  end

  ControlsFree.recordPathSearch(
    expanded, maxExpanded, expanded >= maxExpanded and #open > 0)
  return nil
end

-- Find the reachable legal movement cell that gets as close as possible to an
-- arbitrary requested cell. This is the Hold-to-Steer "never ignore the
-- finger" fallback: a wall/building/solid prop is not a destination, but the
-- closest reachable floor beside it is. One Dijkstra pass replaces the old
-- no-op/retain behavior and keeps ledges + runtime blocked edges faithful.
local function findClosestReachablePath(overview, sx, sy, desiredX, desiredY,
                                        waterMode, occupied, tempBlocked,
                                        blockedEdges, blockedCells, specialEdges)
  if not overview then return nil end
  local startOccupiedKey = key(sx, sy)
  if occupied and occupied[startOccupiedKey] then
    occupied = copyFlat(occupied)
    occupied[startOccupiedKey] = nil
    state.stats.occupancyCopiesRequired =
      (state.stats.occupancyCopiesRequired or 0) + 1
  else
    state.stats.occupancyCopiesAvoided =
      (state.stats.occupancyCopiesAvoided or 0) + 1
  end

  local function terrainOK(x, y)
    local ch = cellChar(overview, x, y)
    return ch == "." or (ch == "~" and waterMode)
  end

  local function stepOK(fromX, fromY, x, y)
    if not terrainOK(x, y) then return false end
    local k = key(x, y)
    if occupied and occupied[k] then return false end
    if blockedCells and blockedCells[k] then return false end
    local expires = tempBlocked and tempBlocked[k]
    if expires and expires > state.tick then return false end
    if blockedEdges and blockedEdges[edgeKey(fromX, fromY, x, y)] then return false end
    return true
  end

  local startKey = startOccupiedKey
  local open, cameFrom, cameVia = {}, {}, {}
  local gScore = { [startKey] = 0 }
  local seq = 0
  seq = seq + 1
  heapPush(open, { x=sx, y=sy, g=0, h=0, f=0, k=startKey, seq=seq })

  local bestKey, bestDist, bestCost, bestSeq
  local maxExpanded = ControlsFree.pathExpansionLimit(overview)
  local expanded = 0

  while #open > 0 and expanded < maxExpanded do
    local cur = heapPop(open)
    if cur.g == gScore[cur.k] then
      expanded = expanded + 1
      if terrainOK(cur.x, cur.y) then
        local dist = math.abs(desiredX - cur.x) + math.abs(desiredY - cur.y)
        if bestDist == nil or dist < bestDist
            or (dist == bestDist and cur.g < bestCost)
            or (dist == bestDist and cur.g == bestCost and cur.seq < bestSeq) then
          bestKey, bestDist, bestCost, bestSeq = cur.k, dist, cur.g, cur.seq
        end
      end

      for _, d in ipairs(DIRS) do
        local nx, ny = cur.x + d.dx, cur.y + d.dy
        if stepOK(cur.x, cur.y, nx, ny) then
          local nk, ng = key(nx, ny), cur.g + 1
          if gScore[nk] == nil or ng < gScore[nk] then
            gScore[nk] = ng
            cameFrom[nk] = cur.k
            cameVia[nk] = nil
            seq = seq + 1
            heapPush(open, { x=nx, y=ny, g=ng, h=0, f=ng, k=nk, seq=seq })
          end
        end
      end

      for _, jump in ipairs((specialEdges and specialEdges[cur.k]) or {}) do
        local nx, ny = jump.x, jump.y
        if terrainOK(nx, ny) and not (jump.requiresWater and not waterMode) then
          local nk = key(nx, ny)
          local blocked = (occupied and occupied[nk])
            or (blockedCells and blockedCells[nk])
            or (tempBlocked and tempBlocked[nk] and tempBlocked[nk] > state.tick)
            or (blockedEdges and blockedEdges[edgeKey(cur.x, cur.y, nx, ny)])
          if not blocked then
            local ng = cur.g + (jump.cost or 2)
            if gScore[nk] == nil or ng < gScore[nk] then
              gScore[nk] = ng
              cameFrom[nk] = cur.k
              cameVia[nk] = jump
              seq = seq + 1
              heapPush(open, { x=nx, y=ny, g=ng, h=0, f=ng, k=nk, seq=seq })
            end
          end
        end
      end
    end
  end

  ControlsFree.recordPathSearch(
    expanded, maxExpanded, expanded >= maxExpanded and #open > 0)
  if not bestKey then return nil end
  local bx, by = parseKey(bestKey)
  return reconstruct(cameFrom, cameVia, bestKey), bx, by, bestDist
end

local function directionTo(x, y, nx, ny)
  local dx, dy = nx - x, ny - y
  if dx == 1 and dy == 0 then return "right" end
  if dx == -1 and dy == 0 then return "left" end
  if dx == 0 and dy == 1 then return "down" end
  if dx == 0 and dy == -1 then return "up" end
  return nil
end

local function mergeBlockedEdges(runtimeEdges, topologyEdges)
  local out = copyFlat(topologyEdges)
  for k, v in pairs(runtimeEdges or {}) do out[k] = v end
  return out
end

-- Ledge topology is generated from static map/tileset data, but before test8
-- every route rebuild rescanned every cell on the map. Hold-to-Steer can ask
-- for a new path several times per second, so that repeated O(map area) scan
-- was pure overhead. Cache by the loaded map object (weak keys avoid keeping
-- evicted maps alive), and include the generated ledge table + overview size
-- in the cache identity. A genuine map reload naturally gets a new map object.
local ledgeTopologyCache = setmetatable({}, { __mode = "k" })

local function invalidateLedgeTopologyCache()
  ledgeTopologyCache = setmetatable({}, { __mode = "k" })
end

-- Build one-way ledge topology from the live/generated map data used by
-- OverworldState:checkLedgeHop.  A ledge jump is legal only in the declared
-- direction and lands two cells away.  The reverse landing->ledge edge is
-- explicitly blocked so the planner understands the one-way topology before
-- runtime collision has to teach it.  Cross-map ledge landings remain owned
-- by the seam planner; this helper intentionally handles in-map jumps only.
function WorldBackend.gold.topology(game, map, overview)
  local topology = { jumps = {}, blockedEdges = {}, seamJumps = {} }
  local P = WorldBackend.gold.permissionsModule()
  if not (map and overview and P and type(map.cellCollision) == "function") then
    return topology
  end

  local function addJump(x, y, jump)
    local k = key(x, y)
    topology.jumps[k] = topology.jumps[k] or {}
    topology.jumps[k][#topology.jumps[k] + 1] = jump
  end
  local function terrain(x, y)
    local ok, coll = pcall(map.cellCollision, map, x, y)
    if not ok or coll == nil then return nil end
    if type(P.isWalkable) == "function" and P.isWalkable(coll) then return "land", coll end
    if type(P.isWater) == "function" and P.isWater(coll) then return "water", coll end
    return nil, coll
  end
  local function permitted(x, y, dir)
    if type(map.stepPermitted) ~= "function" then return false end
    local ok, yes = pcall(map.stepPermitted, map, x, y, dir)
    return ok and yes == true
  end

  -- Directed side-wall permissions and native two-cell ledges.
  for y = 0, overview.height - 1 do
    for x = 0, overview.width - 1 do
      local _, coll = terrain(x, y)
      local ledge = type(P.ledgeFacings) == "function" and P.ledgeFacings(coll) or nil
      for _, d in ipairs(DIRS) do
        local nx, ny = x + d.dx, y + d.dy
        if not permitted(x, y, d.name) then
          topology.blockedEdges[edgeKey(x, y, nx, ny)] = true
        end
        if ledge and ledge[d.name] then
          local lx, ly = x + d.dx * 2, y + d.dy * 2
          local kind = terrain(lx, ly)
          if kind == "land" then
            addJump(x, y, { kind = "ledge", dir = d.name,
              x = lx, y = ly, midX = nx, midY = ny, cost = 2 })
            topology.blockedEdges[edgeKey(lx, ly, nx, ny)] = true
          end
        end
      end
    end
  end

  -- A current owns the d-pad. Compress the native forced run into one planner
  -- edge; the executable path still contains its entry cell, so the mod only
  -- presses the direction that enters the mechanic and then releases control.
  local function traceForced(sx, sy, firstDir, fromLand)
    local d = DIR_BY_NAME[firstDir]
    if not d then return nil end
    local x, y = sx, sy
    local entryX, entryY = sx + d.dx, sy + d.dy
    local tx, ty = entryX, entryY
    local steps, requiresWater = 0, false
    while steps < 128 do
      local kind, coll = terrain(tx, ty)
      if not kind then break end
      if kind == "water" then requiresWater = true end
      x, y = tx, ty; steps = steps + 1
      local current = type(P.currentDirection) == "function" and P.currentDirection(coll) or nil
      if current then
        local cd = DIR_BY_NAME[current]
        if not cd or not permitted(x, y, current) then break end
        tx, ty = x + cd.dx, y + cd.dy
      elseif type(P.isIce) == "function" and P.isIce(coll) then
        if not permitted(x, y, firstDir) then break end
        tx, ty = x + d.dx, y + d.dy
      else
        break
      end
    end
    if steps <= 1 then return nil end
    return { kind = "forced", dir = firstDir, x = x, y = y,
             entryX = entryX, entryY = entryY, cost = steps,
             requiresWater = requiresWater }
  end

  for y = 0, overview.height - 1 do
    for x = 0, overview.width - 1 do
      local _, coll = terrain(x, y)
      local current = type(P.currentDirection) == "function" and P.currentDirection(coll) or nil
      if current then
        local jump = traceForced(x - (DIR_BY_NAME[current] and DIR_BY_NAME[current].dx or 0),
                                 y - (DIR_BY_NAME[current] and DIR_BY_NAME[current].dy or 0),
                                 current, false)
        -- The source computed above is only meaningful when it is in-bounds;
        -- ordinary entry-side construction below handles the general case.
      end
      for _, d in ipairs(DIRS) do
        local ex, ey = x + d.dx, y + d.dy
        local _, ecoll = terrain(ex, ey)
        local isIce = type(P.isIce) == "function" and P.isIce(ecoll) or false
        local forcedDir = type(P.currentDirection) == "function" and P.currentDirection(ecoll) or nil
        if permitted(x, y, d.name) and (isIce or forcedDir) then
          -- Current direction overrides entry direction; if they disagree the
          -- first landing immediately bends. Conservative planner support only
          -- claims the straight/native direction case; the rest fail closed.
          local dir = forcedDir or d.name
          if dir == d.name then
            local jump = traceForced(x, y, dir, true)
            if jump then
              topology.blockedEdges[edgeKey(x, y, ex, ey)] = true
              addJump(x, y, jump)
            end
          end
        end
      end
    end
  end

  -- If a route is recomputed while the player is already on ice, preserve the
  -- native latched direction instead of inventing a turn on the ice tile.
  local world = WorldBackend.gold.owner(game)
  local player = world and world.player
  if player and world and world.turningDirection then
    local _, coll = terrain(player.cellX, player.cellY)
    if type(P.isIce) == "function" and P.isIce(coll) then
      local d = DIR_BY_NAME[world.turningDirection]
      if d then
        local pseudoX, pseudoY = player.cellX - d.dx, player.cellY - d.dy
        local jump = traceForced(pseudoX, pseudoY, world.turningDirection, false)
        if jump then
          jump.entryX, jump.entryY = player.cellX, player.cellY
          addJump(player.cellX, player.cellY, jump)
          for _, od in ipairs(DIRS) do
            if od.name ~= world.turningDirection then
              topology.blockedEdges[edgeKey(player.cellX, player.cellY,
                player.cellX + od.dx, player.cellY + od.dy)] = true
            end
          end
        end
      end
    end
  end
  return topology
end

local function ledgeTopology(game, map, overview)
  if WorldBackend.isGold(game) then
    return WorldBackend.gold.topology(game, map, overview)
  end
  local ledges = game and game.data and game.data.field and game.data.field.ledges
  if map and overview then
    local cached = ledgeTopologyCache[map]
    if cached and cached.ledges == ledges
        and cached.width == overview.width and cached.height == overview.height
        and cached.tileset == (map.def and map.def.tileset) then
      state.stats.topologyCacheHits = state.stats.topologyCacheHits + 1
      return cached.topology
    end
  end

  local topology = { jumps = {}, blockedEdges = {}, seamJumps = {} }
  if not map or not overview or type(ledges) ~= "table"
      or type(map.cellTile) ~= "function" or type(map.isWalkableCell) ~= "function" then
    return topology
  end
  state.stats.topologyCacheMisses = state.stats.topologyCacheMisses + 1
  local tileset = map.def and map.def.tileset
  for y = 0, overview.height - 1 do
    for x = 0, overview.width - 1 do
      local okStanding, standing = pcall(map.cellTile, map, x, y)
      if okStanding then
        for _, ledge in ipairs(ledges) do
          local dirName = ledge.input or ledge.facing
          local d = DIR_BY_NAME[dirName]
          if d and ledge.facing == dirName
              and (ledge.tileset or "OVERWORLD") == tileset
              and ledge.standingTile == standing then
            local mx, my = x + d.dx, y + d.dy
            local lx, ly = x + d.dx * 2, y + d.dy * 2
            if mx >= 0 and my >= 0 and mx < overview.width and my < overview.height then
              local okFront, front = pcall(map.cellTile, map, mx, my)
              if okFront and front == ledge.ledgeTile then
                if lx >= 0 and ly >= 0 and lx < overview.width and ly < overview.height then
                  local okLand, landOK = pcall(map.isWalkableCell, map, lx, ly)
                  if okLand and landOK == true then
                    local sk = key(x, y)
                    topology.jumps[sk] = topology.jumps[sk] or {}
                    topology.jumps[sk][#topology.jumps[sk] + 1] = {
                      kind = "ledge", dir = dirName, x = lx, y = ly,
                      midX = mx, midY = my, cost = 2,
                    }
                    -- The faithful hop is one-way.  In particular, the landing
                    -- cell may never path back "up" through the ledge tile.
                    topology.blockedEdges[edgeKey(lx, ly, mx, my)] = true
                  end
                else
                  -- Vanilla also supports a ledge whose SECOND half crosses a
                  -- connected-map seam (Route 4 is the canonical case).  Keep
                  -- the source+edge midpoint so the cross-map planner can use
                  -- the normal engine ledge callback instead of pretending the
                  -- player can stand on the ledge tile and walk off normally.
                  topology.seamJumps[#topology.seamJumps + 1] = {
                    kind = "ledge_seam", dir = dirName,
                    sourceX = x, sourceY = y, midX = mx, midY = my, cost = 2,
                  }
                end
              end
            end
          end
        end
      end
    end
  end
  ledgeTopologyCache[map] = {
    ledges = ledges, width = overview.width, height = overview.height,
    tileset = tileset, topology = topology,
  }
  return topology
end

local function currentWaterMode(game, overview, cur)
  if WorldBackend.isGold(game) and WorldBackend.gold.isSurfing(game) then return true end
  local player = game and game.overworld and game.overworld.player
  if player and player.surfing then return true end
  return cellChar(overview, cur.x, cur.y) == "~"
end

-- Whether a NEW water leg may be planned from the player's current live state.
-- Delegate eligibility to Gen1Recomp: partyKnows("SURF") owns the badge +
-- learned-move check (and fieldmove.eligibility hooks), while the overworld
-- owns forced-bike and Seafoam-current restrictions.
function WorldBackend.gold.surfResult(game)
  local world = WorldBackend.gold.owner(game)
  local Field = WorldBackend.gold.fieldMovesModule()
  if not (world and Field and type(world.fieldContext) == "function"
      and type(Field.trySurfOW) == "function") then return nil end
  local okCtx, ctx = pcall(world.fieldContext, world)
  if not okCtx or type(ctx) ~= "table" then return nil end
  local ok, result = pcall(Field.trySurfOW, ctx)
  if not ok or type(result) ~= "table" then return nil end
  if result.ok == true and result.action == "surf" then return result end
  return nil
end

function WorldBackend.gold.startNativeSurf(game)
  local world = WorldBackend.gold.owner(game)
  local result = WorldBackend.gold.surfResult(game)
  if not (world and result and type(world.runFieldMove) == "function") then
    return false, "ineligible"
  end
  local ok, ran = pcall(world.runFieldMove, world, result)
  if not ok or ran == false then return false, "native_rejected" end
  return true, "native_wait"
end

function ControlsFree.playerIsSurfing(game)
  if WorldBackend.isGold(game) then return WorldBackend.gold.isSurfing(game) end
  local p = game and game.overworld and game.overworld.player
  return p and p.surfing == true or false
end

function ControlsFree.seamlessSurfEligible(game)
  if WorldBackend.isGold(game) then
    if WorldBackend.gold.isSurfing(game) then return true end
    return WorldBackend.gold.surfResult(game) ~= nil
  end
  local ow = game and game.overworld
  local p = ow and ow.player
  if not (ow and p) then return false end
  if p.surfing then return true end
  if type(ow.partyKnows) ~= "function" or not ow:partyKnows("SURF") then
    return false
  end
  if game.save and game.save.forcedBike then return false end
  if type(ow.surfBlockedHere) == "function" and ow:surfBlockedHere() then
    return false
  end
  return true
end

function ControlsFree.routeWaterMode(game, overview, cur)
  return currentWaterMode(game, overview, cur)
      or ControlsFree.seamlessSurfEligible(game)
end

function ControlsFree.mountSurfSeamlessly(game)
  if WorldBackend.isGold(game) then
    if WorldBackend.gold.isSurfing(game) then return true end
    local ok, why = WorldBackend.gold.startNativeSurf(game)
    if ok then
      state.stats.seamlessSurfMounts = (state.stats.seamlessSurfMounts or 0) + 1
    end
    return ok, why
  end
  local ow = game and game.overworld
  local p = ow and ow.player
  if not (ow and p) then return false, "no_overworld" end
  if p.surfing then return true end
  if not ControlsFree.seamlessSurfEligible(game) then return false, "ineligible" end
  if type(ow.useSurfFieldMove) == "function" then
    local ok, status = pcall(ow.useSurfFieldMove, ow)
    if not ok then return false, "check_error" end
    if status ~= "ok" then return false, tostring(status or "rejected") end
  end
  p.surfing = true
  if game.save then game.save.onBike = false end
  if type(ow.syncSurfingPikachu) == "function" then pcall(ow.syncSurfingPikachu, ow) end
  local okMusic, Music = pcall(require, "src.core.Music")
  if okMusic and Music then
    if ow.map and type(Music.playMap) == "function" then
      pcall(Music.playMap, game.data, ow.map.id, false, true)
    elseif type(Music.setSurfing) == "function" then
      pcall(Music.setSurfing, game.data, true)
    end
  end
  state.stats.seamlessSurfMounts = (state.stats.seamlessSurfMounts or 0) + 1
  return true
end

function ControlsFree.prepareSeamlessSurfStep(game, nav, dir)
  local ow = WorldBackend.owner(game)
  local p = WorldBackend.player(game)
  if not (p and nav and dir) then return "failed", "no_player" end
  if ControlsFree.playerIsSurfing(game) then
    nav.surfFaceNeutralTick, nav.surfFacePressTick = nil, nil
    return "ready"
  end
  if not ControlsFree.seamlessSurfEligible(game) then
    state.stats.seamlessSurfDenied =
      (state.stats.seamlessSurfDenied or 0) + 1
    return "failed", "ineligible"
  end

  if p.facing ~= dir then
    if nav.phase == "FACING_SURF" and nav.surfFacePressTick then
      if state.tick - nav.surfFacePressTick <= 2 then return "waiting" end
      releaseHold(nav)
      nav.surfFacePressTick = nil
      nav.surfFaceNeutralTick = state.tick
      nav.surfFaceRetries = (nav.surfFaceRetries or 0) + 1
      if nav.surfFaceRetries > 2 then return "failed", "face_failed" end
      setPhase(nav, "WAITING_SURF_FACE_NEUTRAL", "retry_surf_face")
      return "waiting"
    end

    if nav.phase == "WAITING_SURF_FACE_NEUTRAL"
        and nav.surfFaceNeutralTick
        and nav.surfFaceNeutralTick < state.tick then
      releaseHold(nav)
      nav.holdDir = dir
      nav.hold = mod.input:press(game, dir)
      nav.surfFacePressTick = state.tick
      state.stats.seamlessSurfFaceTurns =
        (state.stats.seamlessSurfFaceTurns or 0) + 1
      setPhase(nav, "FACING_SURF", "turn_to_surf_" .. dir)
      return "waiting"
    end

    releaseHold(nav)
    nav.surfFaceNeutralTick = state.tick
    nav.surfFacePressTick = nil
    nav.surfFaceRetries = nav.surfFaceRetries or 0
    setPhase(nav, "WAITING_SURF_FACE_NEUTRAL", "neutral_before_surf_" .. dir)
    return "waiting"
  end

  if nav.phase == "FACING_SURF" then
    releaseHold(nav)
    nav.surfFacePressTick = nil
    nav.surfFaceVerifiedTick = state.tick
    setPhase(nav, "WAITING_SURF_FACE_SETTLE", "surf_facing_verified")
    return "waiting"
  end

  if nav.phase == "WAITING_SURF_FACE_SETTLE" then
    releaseHold(nav)
    if p.facing ~= dir then
      nav.surfFaceNeutralTick = state.tick
      setPhase(nav, "WAITING_SURF_FACE_NEUTRAL", "surf_facing_changed")
      return "waiting"
    end
    if tonumber(p.turnTimer or 0) > 0 then return "waiting" end
    if nav.surfFaceVerifiedTick and nav.surfFaceVerifiedTick >= state.tick then
      return "waiting"
    end
  elseif tonumber(p.turnTimer or 0) > 0 then
    releaseHold(nav)
    nav.surfFaceVerifiedTick = state.tick
    setPhase(nav, "WAITING_SURF_FACE_SETTLE", "settle_before_surf")
    return "waiting"
  end

  releaseHold(nav)
  local ok, why = ControlsFree.mountSurfSeamlessly(game)
  if not ok then
    state.stats.seamlessSurfDenied = (state.stats.seamlessSurfDenied or 0) + 1
    return "failed", why
  end
  nav.surfFaceNeutralTick, nav.surfFacePressTick = nil, nil
  nav.surfFaceVerifiedTick, nav.surfFaceRetries = nil, nil
  if WorldBackend.isGold(game) and why == "native_wait" then
    nav.goldSurfStartedTick = state.tick
    setPhase(nav, "WAITING_GOLD_SURF", "gold_native_surf")
    return "waiting"
  end
  setPhase(nav, "WALKING", "surf_mounted")
  return "ready"
end

local function scheduleDynamicWait(nav, reason)
  releaseHold(nav)
  if not nav.dynamicWaitStarted then
    nav.dynamicWaitStarted = state.tick
    state.stats.dynamicWaits = state.stats.dynamicWaits + 1
  end
  nav.waitUntil = state.tick + DYNAMIC_RETRY_TICKS
  setPhase(nav, "WAITING_DYNAMIC", reason or "dynamic_obstacle")
end

-- Directional edge/carpet warps are most faithful when the activation
-- direction is ALREADY HELD while the final step lands on the warp source.
-- Gen1Recomp's onStepComplete mirrors CheckWarpsNoCollision and can consume
-- ExtraWarpCheck on that landing frame.  Routing to the source first and only
-- then pressing UP/DOWN/LEFT/RIGHT misses that window on some wall openings.
-- Build a terminal path whose predecessor is exactly opposite exitDir, then
-- append the source as the final step.  The existing route follower keeps the
-- same synthetic direction held across that landing frame.
function ControlsFree.directionalExitTerminalPath(game, nav, cur, overview,
    occupied, tempBlocked, blockedEdges, blockedCells, topology, waterMode)
  if not (nav and nav.goalKind == "exit" and nav.exitIntent
      and nav.exitDir and nav.targetX ~= nil and nav.targetY ~= nil) then
    return nil
  end
  if cur.x == nav.targetX and cur.y == nav.targetY then return nil end
  local d = DIR_BY_NAME[nav.exitDir]
  if not d then return nil end
  local ax, ay = nav.targetX - d.dx, nav.targetY - d.dy
  if ax < 0 or ay < 0 or ax >= overview.width or ay >= overview.height then
    return nil
  end

  -- Never let the path-to-approach accidentally walk through the warp source
  -- when that source looks like ordinary '.' terrain in mapOverview.
  local approachBlocked = copyFlat(blockedCells)
  approachBlocked[key(nav.targetX, nav.targetY)] = true
  local path = findPath(overview, cur.x, cur.y, ax, ay, waterMode,
    occupied, tempBlocked, blockedEdges, approachBlocked,
    topology.jumps, false)
  if not path then return nil end

  -- Validate the one final graph edge separately.  allowBlockedGoal is safe
  -- here because the endpoint has already been validated as an actual exit
  -- warp source; it remains forbidden as every intermediate node.
  if not passable(overview, nav.targetX, nav.targetY,
      nav.targetX, nav.targetY, waterMode,
      occupied, tempBlocked, blockedEdges, blockedCells,
      ax, ay, true) then
    return nil
  end
  path[#path + 1] = {
    x = nav.targetX, y = nav.targetY,
    forced = "exit_terminal", dir = nav.exitDir,
  }
  return path
end

local function buildPath(game, nav, cur)
  local overview = WorldBackend.overview(game)
  if not overview or overview.mapId ~= nav.mapId then return nil, "map" end

  local occupied, dynamic, static = liveOccupancy(game)
  cleanupTempBlocks(nav, dynamic)
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local activeMap = WorldBackend.map(game)
  local topology = ledgeTopology(game, activeMap, overview)
  local blockedEdges = mergeBlockedEdges(nav.blockedEdges, topology.blockedEdges)
  local allowExitGoal = nav.goalKind == "exit" and nav.exitIntent ~= nil
    and nav.exitDir ~= nil
  local path = ControlsFree.directionalExitTerminalPath(game, nav, cur, overview,
    occupied, nav.tempBlocked, blockedEdges, nav.blockedCells,
    topology, waterMode)
  if path then
    nav.exitPrelandingCarry = true
    state.stats.exitPrelandingCarries =
      (state.stats.exitPrelandingCarries or 0) + 1
  else
    nav.exitPrelandingCarry = nil
    path = findPath(overview, cur.x, cur.y,
                          nav.targetX, nav.targetY, waterMode,
                          occupied, nav.tempBlocked, blockedEdges, nav.blockedCells,
                          topology.jumps, allowExitGoal)
  end
  if not path then
    -- Only wait when removing CURRENTLY-MOVABLE actors makes a path possible.
    -- A wall or a stationary NPC therefore fails immediately rather than
    -- pretending it might disappear just because some unrelated NPC wanders
    -- elsewhere on the map.
    local withoutDynamic = ControlsFree.directionalExitTerminalPath(game, nav, cur, overview,
      static, nil, blockedEdges, nav.blockedCells, topology, waterMode)
      or findPath(overview, cur.x, cur.y,
                  nav.targetX, nav.targetY, waterMode,
                  static, nil, blockedEdges, nav.blockedCells,
                  topology.jumps, allowExitGoal)
    if withoutDynamic then return nil, "dynamic" end
    return nil, "blocked"
  end

  nav.path = path
  if not ControlsFree.playerIsSurfing(game) then
    for _, node in ipairs(path or {}) do
      if cellChar(overview, node.x, node.y) == "~" then
        state.stats.seamlessSurfPlans =
          (state.stats.seamlessSurfPlans or 0) + 1
        break
      end
    end
  end
  nav.index = 1
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.needsReplan = false
  nav.waitUntil = nil
  nav.dynamicWaitStarted = nil
  nav.previewUntil = state.tick + 18
  setPhase(nav, "WALKING")
  return true
end

local function buildNearestLegalPath(game, nav, cur, desiredX, desiredY)
  local overview = WorldBackend.overview(game)
  if not overview or overview.mapId ~= nav.mapId then return nil, "map" end

  local occupied, dynamic, static = liveOccupancy(game)
  cleanupTempBlocks(nav, dynamic)
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local activeMap = WorldBackend.map(game)
  local topology = ledgeTopology(game, activeMap, overview)
  local blockedEdges = mergeBlockedEdges(nav.blockedEdges, topology.blockedEdges)

  local path, tx, ty = findClosestReachablePath(
    overview, cur.x, cur.y, desiredX, desiredY, waterMode,
    occupied, nav.tempBlocked, blockedEdges, nav.blockedCells, topology.jumps)

  if not path then
    path, tx, ty = findClosestReachablePath(
      overview, cur.x, cur.y, desiredX, desiredY, waterMode,
      static, nil, blockedEdges, nav.blockedCells, topology.jumps)
    if path then return nil, "dynamic" end
    return nil, "blocked"
  end

  nav.targetX, nav.targetY = tx, ty
  nav.path = path
  nav.index = 1
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.needsReplan = false
  nav.waitUntil = nil
  nav.dynamicWaitStarted = nil
  nav.previewUntil = state.tick + 18
  setPhase(nav, "WALKING", "nearest_legal")
  return true
end

local function candidateTerrainOK(overview, x, y, waterMode)
  local ch = cellChar(overview, x, y)
  if ch == "." then return true end
  if ch == "~" and waterMode then return true end
  return false -- never stand on a warp just to interact
end

local function bestInteractionApproach(game, nav, cur, overview, occupied, topology)
  local interaction = nav.interaction
  local ix, iy, entity, err = interactionTarget(game, interaction)
  if not ix then return nil, err or "gone" end
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local best

  -- The player-avatar rescue is intentionally NOT a navigation request.  The
  -- user is already exactly one tile from the selected semantic surface, so
  -- stay on the current cell, turn toward it and let interactionAtDestination
  -- press A.  This also works while the player happens to be standing on a
  -- warp/mat cell, which generic interaction approach terrain filtering would
  -- otherwise reject.  A direct NPC must still be on the cell that was seen;
  -- a moving NPC falls back to the ordinary chase/replan path instead.
  if interaction.avatarAdjacentProxy and interaction.avatarAdjacentDir then
    local directDir = interaction.avatarAdjacentDir
    local d = DIR_BY_NAME[directDir]
    local clickedX, clickedY = tonumber(interaction.clickedX), tonumber(interaction.clickedY)
    local oneTileAway = d and clickedX == cur.x + d.dx and clickedY == cur.y + d.dy
    local directEntityStillThere = interaction.kind ~= "entity"
        or interaction.counterProxy == true
        or (ix == clickedX and iy == clickedY and not (entity and entity.moving))
    if oneTileAway and directEntityStillThere then
      return {
        x = cur.x, y = cur.y, faceDir = directDir,
        counter = interaction.counterProxy == true, path = {}, cost = 0, rank = -1000,
        targetX = ix, targetY = iy, entity = entity,
      }
    end
  end

  local function consider(cx, cy, faceDir, counter, rank)
    if interaction.requiredFacing and faceDir ~= interaction.requiredFacing then return end
    if interaction.preferredFacing and faceDir ~= interaction.preferredFacing then
      rank = rank + 100
    end
    if not candidateTerrainOK(overview, cx, cy, waterMode) then return end
    local blockedEdges = mergeBlockedEdges(nav.blockedEdges, topology and topology.blockedEdges)
    local approachBlocked = nav.blockedCells
    if interaction.cutTarget then
      approachBlocked = copyFlat(nav.blockedCells)
      approachBlocked[key(ix, iy)] = true
    end
    local path = findPath(overview, cur.x, cur.y, cx, cy, waterMode,
                          occupied, nav.tempBlocked, blockedEdges, approachBlocked,
                          topology and topology.jumps)
    state.stats.exitCandidatesPathScored =
      (state.stats.exitCandidatesPathScored or 0) + 1
    if not path then return false end
    local cand = { x = cx, y = cy, faceDir = faceDir, counter = counter,
                   path = path, cost = #path, rank = rank }
    if not best or cand.cost < best.cost
        or (cand.cost == best.cost and cand.rank < best.rank) then
      best = cand
    end
  end

  for _, d in ipairs(DIRS) do
    -- Normal adjacent interaction.  Fixed field surfaces such as a Pokémon
    -- Center PC may specify the only facing accepted by the engine.
    local cx, cy = ix - d.dx, iy - d.dy
    consider(cx, cy, d.name, false, d.rank * 2)

    -- Gen I counters: the player stands two cells from the clerk/nurse and
    -- faces across the counter tile.  This covers both tapping the actor and
    -- tapping the counter proxy in front of it.
    local mx, my = ix - d.dx, iy - d.dy
    if interaction.kind == "entity" and counterAt(game, mx, my) then
      local ccx, ccy = ix - d.dx * 2, iy - d.dy * 2
      consider(ccx, ccy, d.name, true, d.rank * 2 + 1)
    end
  end

  if not best then return nil, "blocked" end
  best.targetX, best.targetY, best.entity = ix, iy, entity
  return best
end

local function buildInteractionPath(game, nav, cur)
  local overview = WorldBackend.overview(game)
  if not overview or overview.mapId ~= nav.mapId then return nil, "map" end

  local occupied, dynamic, static = liveOccupancy(game)
  cleanupTempBlocks(nav, dynamic)
  local topology = ledgeTopology(game, WorldBackend.map(game), overview)
  local best, why = bestInteractionApproach(game, nav, cur, overview, occupied, topology)
  if not best then
    if why == "gone" then return nil, "gone" end
    local withoutDynamic = bestInteractionApproach(game, nav, cur, overview, static, topology)
    if withoutDynamic then return nil, "dynamic" end
    return nil, "blocked"
  end

  nav.interaction.targetX = best.targetX
  nav.interaction.targetY = best.targetY
  nav.interaction.faceDir = best.faceDir
  nav.interaction.counter = best.counter
  -- Every freshly planned interaction approach gets a fresh facing finisher.
  -- Stale turn state from a previous NPC chase/replan must never skip the
  -- neutral -> turn -> verify sequence at the new approach cell.
  nav.faceNeutralTick = nil
  nav.facePressTick = nil
  nav.faceVerifiedTick = nil
  nav.faceRetryCount = 0
  nav.targetX, nav.targetY = best.x, best.y
  nav.path = best.path
  nav.index = 1
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.needsReplan = false
  nav.waitUntil = nil
  nav.dynamicWaitStarted = nil
  nav.previewUntil = state.tick + 18
  if not nav.interaction.chaseReplan then
    nav.interactionBuilds = (nav.interactionBuilds or 0) + 1
    if nav.interactionBuilds > MAX_INTERACTION_REPLANS then
      return nil, "interaction_replan_limit"
    end
  end
  nav.interaction.chaseReplan = nil
  setPhase(nav, "WALKING", "interaction_approach")
  return true
end

local function seamLanding(cross, sx, sy)
  local dest = cross.destOverview
  local off = (cross.conn and cross.conn.offset or 0) * 2
  if cross.dir == "up" then return sx - off, dest.height - 1 end
  if cross.dir == "down" then return sx - off, 0 end
  if cross.dir == "left" then return dest.width - 1, sy - off end
  return 0, sy - off
end

local function seamSourceCells(cross, overview)
  local out = {}
  if cross.dir == "up" or cross.dir == "down" then
    local y = cross.dir == "up" and 0 or overview.height - 1
    for x = 0, overview.width - 1 do out[#out + 1] = {x=x,y=y} end
  else
    local x = cross.dir == "left" and 0 or overview.width - 1
    for y = 0, overview.height - 1 do out[#out + 1] = {x=x,y=y} end
  end
  return out
end

function ControlsFree.budgetedSeamSourceCells(cross, overview, cur, targetX, targetY)
  local cells = seamSourceCells(cross, overview)
  local profile = ControlsFree.pathBudgetProfile()
  local limit = profile and tonumber(profile.seams) or nil
  if not limit or #cells <= limit then
    state.stats.seamCandidatesConsidered =
      (state.stats.seamCandidatesConsidered or 0) + #cells
    return cells
  end

  for i, cell in ipairs(cells) do
    local lx, ly = seamLanding(cross, cell.x, cell.y)
    local sourceDist = cur
      and (math.abs(cell.x - cur.x) + math.abs(cell.y - cur.y)) or 0
    local destDist = (type(targetX) == "number" and type(targetY) == "number")
      and (math.abs(lx - targetX) + math.abs(ly - targetY)) or 0
    cell._budgetScore = sourceDist + destDist
    cell._budgetOrder = i
  end
  table.sort(cells, function(a, b)
    if a._budgetScore ~= b._budgetScore then
      return a._budgetScore < b._budgetScore
    end
    return a._budgetOrder < b._budgetOrder
  end)

  local out = {}
  for i = 1, math.min(limit, #cells) do
    local cell = cells[i]
    cell._budgetScore, cell._budgetOrder = nil, nil
    out[#out + 1] = cell
  end
  state.stats.seamCandidatesConsidered =
    (state.stats.seamCandidatesConsidered or 0) + #out
  state.stats.seamCandidatesSkipped =
    (state.stats.seamCandidatesSkipped or 0) + (#cells - #out)
  return out
end

local function chooseCrossSeam(game, nav, cur, occupancy)
  local cross = nav.cross
  local overview = WorldBackend.overview(game)
  if not cross or not overview or overview.mapId ~= cross.sourceMapId then return nil end
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local sourceMap = WorldBackend.map(game)
  local sourceTopology = ledgeTopology(game, sourceMap, overview)
  local sourceBlockedEdges = mergeBlockedEdges(nav.blockedEdges, sourceTopology.blockedEdges)
  local destTopology = ledgeTopology(game, cross.destMap, cross.destOverview)
  local best
  local seamCells = ControlsFree.budgetedSeamSourceCells(
    cross, overview, cur, cross.targetX, cross.targetY)
  for _, src in ipairs(seamCells) do
    local sx, sy = src.x, src.y
    local sch = cellChar(overview, sx, sy)
    -- Standing on a warp square just to leave through a connection creates
    -- ambiguous warp-vs-seam semantics; pick another overlap cell.
    if sch and sch ~= "+" then
      local lx, ly = seamLanding(cross, sx, sy)
      local lch = cellChar(cross.destOverview, lx, ly)
      local landingOK = lch == "." or (lch == "~" and waterMode)
      local dx, dy = sx, sy
      if cross.dir == "up" then dy = sy - 1
      elseif cross.dir == "down" then dy = sy + 1
      elseif cross.dir == "left" then dx = sx - 1
      else dx = sx + 1 end
      if landingOK and not nav.blockedEdges[edgeKey(sx, sy, dx, dy)] then
        local pathHere = findPath(overview, cur.x, cur.y, sx, sy, waterMode,
          occupancy, nav.tempBlocked, sourceBlockedEdges, nav.blockedCells,
          sourceTopology.jumps)
        if pathHere then
          -- Static reachability inside the loaded neighbour keeps us from
          -- crossing through a seam that leads into a dead pocket. Runtime
          -- NPC occupancy is intentionally not baked in; it may move before
          -- the crossing and the active-map replan will handle it.
          local tailScore
          if nav.remoteGoal and ControlsFree.remoteConnectionTailScore then
            tailScore = ControlsFree.remoteConnectionTailScore(
              game, nav.remoteGoal, cross.destMapId, lx, ly,
              (nav.remoteGoal.routeIndex or 1) + 1, waterMode)
          else
            local pathThere = findPath(cross.destOverview, lx, ly,
              cross.targetX, cross.targetY, waterMode, {}, {},
              destTopology.blockedEdges, {}, destTopology.jumps)
            tailScore = pathThere and #pathThere or nil
          end
          if tailScore then
            local score = #pathHere + 1 + tailScore
            if not best or score < best.score then
              best = { score=score, path=pathHere, sourceX=sx, sourceY=sy,
                       entryX=lx, entryY=ly }
            end
          end
        end
      end
    end
  end

  -- A faithful ledge may consume the edge tile as the first half of the hop
  -- and cross the map connection on its second half.  Such a route cannot be
  -- represented by the normal "stand on border cell, then step out" seam
  -- candidates because the border cell itself is a ledge tile.
  for _, jump in ipairs(sourceTopology.seamJumps or {}) do
    if jump.dir == cross.dir then
      local lx, ly = seamLanding(cross, jump.midX, jump.midY)
      local lch = cellChar(cross.destOverview, lx, ly)
      local landingOK = lch == "." or (lch == "~" and waterMode)
      if landingOK then
        local pathHere = findPath(overview, cur.x, cur.y,
          jump.sourceX, jump.sourceY, waterMode, occupancy, nav.tempBlocked,
          sourceBlockedEdges, nav.blockedCells, sourceTopology.jumps)
        if pathHere then
          local tailScore
          if nav.remoteGoal and ControlsFree.remoteConnectionTailScore then
            tailScore = ControlsFree.remoteConnectionTailScore(
              game, nav.remoteGoal, cross.destMapId, lx, ly,
              (nav.remoteGoal.routeIndex or 1) + 1, waterMode)
          else
            local pathThere = findPath(cross.destOverview, lx, ly,
              cross.targetX, cross.targetY, waterMode, {}, {},
              destTopology.blockedEdges, {}, destTopology.jumps)
            tailScore = pathThere and #pathThere or nil
          end
          if tailScore then
            local score = #pathHere + (jump.cost or 2) + tailScore
            if not best or score < best.score then
              best = { score=score, path=pathHere,
                       sourceX=jump.sourceX, sourceY=jump.sourceY,
                       entryX=lx, entryY=ly, ledgeSeam=true,
                       ledgeMidX=jump.midX, ledgeMidY=jump.midY }
            end
          end
        end
      end
    end
  end
  return best
end

-- Neighbour-map equivalent of nearest-legal steering. A Voxel/survey view can
-- show a building/NPC/solid tile on the directly connected map; holding there
-- should not become a dead input merely because the requested neighbour cell
-- itself is not standable. Probe legal cells in increasing Manhattan rings and
-- keep the first one whose seam + destination route is actually reachable.
local function nearestReachableCrossTarget(game, cur, cross, desiredX, desiredY,
                                           excludeDesired)
  local dest = cross and cross.destOverview
  local source = WorldBackend.overview(game)
  if not dest or not source then return nil end
  local waterMode = ControlsFree.routeWaterMode(game, source, cur)
  local all, _, static = liveOccupancy(game)
  local maxR = (tonumber(dest.width) or 0) + (tonumber(dest.height) or 0)
  local candidateLimit = ControlsFree.crossTargetCandidateLimit()
  local candidatesTested = 0

  local function legal(cx, cy)
    if cx < 0 or cy < 0 or cx >= dest.width or cy >= dest.height then return false end
    if excludeDesired and cx == desiredX and cy == desiredY then return false end
    local ch = cellChar(dest, cx, cy)
    return ch == "." or (ch == "~" and waterMode)
  end

  local function seamReachable(cx, cy, occupancy)
    local probe = {
      mapId = cur.mapId,
      blockedEdges = {}, blockedCells = {}, tempBlocked = {},
      cross = copyFlat(cross),
    }
    probe.cross.targetX, probe.cross.targetY = cx, cy
    return chooseCrossSeam(game, probe, cur, occupancy) ~= nil
  end

  for r = 0, maxR do
    local seen = {}
    local dynamicCandidate
    local y0, y1 = desiredY - r, desiredY + r
    for cy = y0, y1 do
      local dy = math.abs(cy - desiredY)
      local dx = r - dy
      local xs = { desiredX - dx }
      if dx ~= 0 then xs[#xs + 1] = desiredX + dx end
      for _, cx in ipairs(xs) do
        local k = key(cx, cy)
        if not seen[k] then
          seen[k] = true
          if legal(cx, cy) then
            if candidateLimit and candidatesTested >= candidateLimit then
              state.stats.crossFallbackBudgetStops =
                (state.stats.crossFallbackBudgetStops or 0) + 1
              return nil
            end
            candidatesTested = candidatesTested + 1
            state.stats.crossFallbackCellsTested =
              (state.stats.crossFallbackCellsTested or 0) + 1

            if seamReachable(cx, cy, all) then
              return cx, cy, false
            end
            if not dynamicCandidate and seamReachable(cx, cy, static) then
              dynamicCandidate = { x=cx, y=cy }
            end
          end
        end
      end
    end
    -- "Closest to the object" beats taking a farther detour merely to avoid a
    -- moving actor. The normal cross planner will enter WAITING_DYNAMIC.
    if dynamicCandidate then
      return dynamicCandidate.x, dynamicCandidate.y, true
    end
  end
  return nil
end

-- Graceful bounded-preset fallback for a single click into a visible connected
-- map. If a full cross-map route is too expensive for VERY LOW/MEDIUM, keep
-- player control by walking toward the corresponding edge point on the CURRENT
-- map instead of rejecting the click. This performs exactly one bounded
-- nearest-reachable search and never attempts a map crossing.
function ControlsFree.currentMapTowardCrossFallback(game, cur, overview, cross,
                                                    desiredX, desiredY)
  if not (cur and overview and cross) then return nil end
  state.stats.crossLocalFallbackAttempts =
    (state.stats.crossLocalFallbackAttempts or 0) + 1

  local off = (cross.conn and cross.conn.offset or 0) * 2
  local edgeX, edgeY
  if cross.dir == "up" then
    edgeX = desiredX + off
    edgeY = 0
  elseif cross.dir == "down" then
    edgeX = desiredX + off
    edgeY = overview.height - 1
  elseif cross.dir == "left" then
    edgeX = 0
    edgeY = desiredY + off
  elseif cross.dir == "right" then
    edgeX = overview.width - 1
    edgeY = desiredY + off
  else
    state.stats.crossLocalFallbackRejected =
      (state.stats.crossLocalFallbackRejected or 0) + 1
    return nil
  end

  edgeX = math.max(0, math.min((overview.width or 1) - 1,
    math.floor(edgeX or cur.x)))
  edgeY = math.max(0, math.min((overview.height or 1) - 1,
    math.floor(edgeY or cur.y)))

  local map = WorldBackend.map(game)
  local topology = ledgeTopology(game, map, overview)
  local occupied = select(1, liveOccupancy(game))
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)

  -- First use normal heuristic A*. This is the crucial difference from
  -- v1.5.5: a 128-node VERY LOW budget is spent TOWARD the clicked edge rather
  -- than as an isotropic Dijkstra flood around the player.
  local path = findPath(
    overview, cur.x, cur.y, edgeX, edgeY, waterMode,
    occupied, nil, topology.blockedEdges, nil, topology.jumps)

  local bx, by = edgeX, edgeY
  if path then
    state.stats.crossLocalDirectPath =
      (state.stats.crossLocalDirectPath or 0) + 1
  else
    -- If the exact border cell is obstructed/disconnected, allow one bounded
    -- nearest-reachable search. This is the only secondary search and never
    -- crosses into the neighbour map.
    path, bx, by = findClosestReachablePath(
      overview, cur.x, cur.y, edgeX, edgeY, waterMode,
      occupied, nil, topology.blockedEdges, nil, topology.jumps)
    if path and bx and by then
      state.stats.crossLocalNearestPath =
        (state.stats.crossLocalNearestPath or 0) + 1
    end
  end

  if not path or not bx or not by or #path == 0
      or (bx == cur.x and by == cur.y) then
    state.stats.crossLocalFallbackRejected =
      (state.stats.crossLocalFallbackRejected or 0) + 1
    return nil
  end

  -- This helper appears before the normal local navigation constructor,
  -- so construct the equivalent record here instead of depending on local
  -- declaration order.
  local nav = {
    mapId = cur.mapId,
    targetX = nil,
    targetY = nil,
    path = nil,
    index = 1,
    blockedEdges = {},
    blockedCells = {},
    tempBlocked = {},
    lastX = cur.x,
    lastY = cur.y,
    lastProgressTick = state.tick,
    phase = "PLANNING",
    createdTick = state.tick,
  }
  nav.goalKind = "move_nearest"
  nav.targetX, nav.targetY = bx, by
  nav.requestedMapId = cross.destMapId
  nav.requestedX, nav.requestedY = desiredX, desiredY
  nav.path = path
  nav.index = 1
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.needsReplan = false
  nav.waitUntil = nil
  nav.dynamicWaitStarted = nil
  nav.previewUntil = state.tick + 18
  setPhase(nav, "WALKING", "cross_budget_local_fallback")

  state.stats.crossLocalFallbackAccepted =
    (state.stats.crossLocalFallbackAccepted or 0) + 1
  return nav
end

local function buildCrossPath(game, nav, cur)
  local all, dynamic, static = liveOccupancy(game)
  local simpleGold = WorldBackend.isGold(game) and nav and nav.goldSimpleRemote
  local chooser = simpleGold and ControlsFree.chooseGoldSimpleCrossSeam or chooseCrossSeam
  local best = chooser(game, nav, cur, all)
  if not best then
    local withoutDynamic = chooser(game, nav, cur, static)
    if withoutDynamic then return nil, "dynamic" end
    return nil, "no_route"
  end
  nav.path = best.path
  nav.index = 1
  nav.targetX, nav.targetY = best.sourceX, best.sourceY
  nav.cross.sourceX, nav.cross.sourceY = best.sourceX, best.sourceY
  nav.cross.entryX, nav.cross.entryY = best.entryX, best.entryY
  nav.cross.ledgeSeam = best.ledgeSeam and true or false
  nav.cross.ledgeMidX, nav.cross.ledgeMidY = best.ledgeMidX, best.ledgeMidY
  nav.needsReplan = false
  nav.replanReason = nil
  nav.lastProgressTick = state.tick
  nav.previewUntil = state.tick + 18
  state.stats.replans = state.stats.replans + 1
  setPhase(nav, "WALKING", "connection_approach")
  return true
end

local function rebuildNavigation(game, nav, cur)
  if nav and nav.cross and not nav.cross.crossed then
    return buildCrossPath(game, nav, cur)
  end
  if nav and nav.interaction then
    return buildInteractionPath(game, nav, cur)
  end
  return buildPath(game, nav, cur)
end

local function playerPixel(game, cur)
  local player = WorldBackend.player(game)
  local px = player and tonumber(player.px) or cur.x * TILE_SIZE
  local py = player and tonumber(player.py) or cur.y * TILE_SIZE
  return px, py
end

local COMPASS_TO_DIR = {
  north = "up", south = "down", west = "left", east = "right",
}

local function mapCellSize(def, loaded)
  if loaded and loaded.widthCells and loaded.heightCells then
    return loaded.widthCells, loaded.heightCells
  end
  if not def then return nil end
  return tonumber(def.width) and def.width * 2 or nil,
         tonumber(def.height) and def.height * 2 or nil
end

function WorldBackend.gold.neighborMap(game, mapId)
  local world = WorldBackend.gold.owner(game)
  if not (world and mapId) then return nil end
  if world.map and world.map.id == mapId then return world.map end
  ControlsFree.goldNeighborMaps = ControlsFree.goldNeighborMaps or {}
  local cached = ControlsFree.goldNeighborMaps[mapId]
  if cached and cached.def == (world.maps and world.maps[mapId]) then return cached end
  local def = world.maps and world.maps[mapId]
  local Map = WorldBackend.gold.mapModule()
  if not (def and Map and type(Map.new) == "function") then return nil end
  local tilesets = world.tilesets or (game and game.data and game.data.gen2Tilesets)
      or (game and game.data and game.data.tilesets)
  local ts = tilesets and (tilesets[def.tileset] or tilesets[def.tilesetId]
      or (tonumber(def.tilesetId) and tilesets[def.tilesetId + 1]))
  if not ts then return nil end
  local ok, map = pcall(Map.new, def, ts)
  if not ok then return nil end
  ControlsFree.goldNeighborMaps[mapId] = map
  return map
end

local function loadedNeighborMap(game, mapId)
  local owner = WorldBackend.owner(game)
  if not owner then return nil end
  if WorldBackend.isGold(game) then
    local map = WorldBackend.gold.neighborMap(game, mapId)
    local nbHit
    for _, nb in ipairs(owner.neighbors or {}) do
      local id = (nb.map and nb.map.id) or nb.id
      if id == mapId then nbHit = nb; break end
    end
    return map, nbHit
  end
  local neighbors = owner.neighbors
  local cache = ControlsFree.neighborLookupCache
  if not cache or cache.ow ~= owner or cache.neighbors ~= neighbors then
    local byId = {}
    for _, nb in ipairs(neighbors or {}) do
      if nb.map and nb.map.id ~= nil then byId[nb.map.id] = nb end
    end
    cache = { ow = owner, neighbors = neighbors, byId = byId }
    ControlsFree.neighborLookupCache = cache
    state.stats.neighborLookupMisses = (state.stats.neighborLookupMisses or 0) + 1
  else
    state.stats.neighborLookupHits = (state.stats.neighborLookupHits or 0) + 1
  end
  local nb = cache.byId[mapId]
  return nb and nb.map or nil, nb
end

-- Build the same compact terrain alphabet WorldAPI.mapOverview uses, but only
-- Build the same compact terrain alphabet WorldAPI.mapOverview uses, but only
-- for a neighbour map the engine has ALREADY loaded for survey rendering.
-- This is a read-only fallback used to reject impossible seam choices before
-- crossing; once the map becomes active, the public mapOverview is authority.
--
-- Survey neighbours are stable for the lifetime of one active map, yet test7
-- rebuilt every neighbour's entire compact grid on every Voxel ray/preview
-- lookup. Cache it by loaded map object and flush at map boundaries.
local loadedMapOverviewCache = setmetatable({}, { __mode = "k" })

local function invalidateLoadedMapOverviewCache()
  loadedMapOverviewCache = setmetatable({}, { __mode = "k" })
end

local function overviewFromLoadedMap(map)
  if not map or not map.widthCells or not map.heightCells then return nil end
  -- Grid coordinates are integers even if a test/custom map stores its
  -- dimensions as 3.0/6.0.  Canonicalise here because A* node keys use the
  -- textual cell coordinate; mixing `5` and `5.0` would make the same cell
  -- two different graph nodes and can falsely reject a remote connection leg.
  local width = math.floor(tonumber(map.widthCells) or 0)
  local height = math.floor(tonumber(map.heightCells) or 0)
  if width <= 0 or height <= 0 then return nil end
  local cached = loadedMapOverviewCache[map]
  if cached and cached.width == width and cached.height == height then
    state.stats.overviewCacheHits = state.stats.overviewCacheHits + 1
    return cached.overview
  end
  state.stats.overviewCacheMisses = state.stats.overviewCacheMisses + 1
  local rows = {}
  for y = 0, height - 1 do
    local row = {}
    for x = 0, width - 1 do
      row[#row + 1] = map:isWarpTileCell(x, y) and "+"
        or map:isWaterCell(x, y) and "~"
        or map:isWalkableCell(x, y) and "." or " "
    end
    rows[#rows + 1] = table.concat(row)
  end
  local overview = { mapId = map.id, width = width, height = height, rows = rows }
  loadedMapOverviewCache[map] = { width = width, height = height, overview = overview }
  return overview
end

-- Reconstruct the exact connection graph represented by Gold's rendered
-- neighbour placements.  World.computeNeighbors may place maps up to two hops
-- away in survey view.  A target on one of those maps is therefore legitimate
-- world intent even when it is not a direct neighbour of the active map.
--
-- We do NOT guess a route from map ids alone.  Every edge is accepted only when
-- applying the source connection's offset reproduces the destination map's
-- actual `ow.neighbors` render placement.  This mirrors the engine's own
-- seamless-world geometry and rejects alternate/loop connections that happen
-- to reach the same map id through a different placement.
function ControlsFree.goldConnectionPlacedOffset(sourceDef, destDef, compass, conn, ox, oy)
  if not (sourceDef and destDef and compass and conn) then return nil end
  local sw, sh = mapCellSize(sourceDef)
  local dw, dh = mapCellSize(destDef)
  if not (sw and sh and dw and dh) then return nil end
  local off = (tonumber(conn.offset) or 0) * 2 * TILE_SIZE
  ox, oy = tonumber(ox) or 0, tonumber(oy) or 0
  if compass == "north" then
    return ox + off, oy - dh * TILE_SIZE
  elseif compass == "south" then
    return ox + off, oy + sh * TILE_SIZE
  elseif compass == "west" then
    return ox - dw * TILE_SIZE, oy + off
  elseif compass == "east" then
    return ox + sw * TILE_SIZE, oy + off
  end
  return nil
end

function ControlsFree.visibleConnectionChain(game, targetMapId)
  if not WorldBackend.isGold(game) or not targetMapId then return nil end
  local world = WorldBackend.gold.owner(game)
  local current = WorldBackend.gold.map(game)
  local maps = WorldBackend.gold.mapDefinitions(game)
  if not (world and current and maps and maps[targetMapId]) then return nil end
  if targetMapId == current.id then return {} end

  local placed = {
    [current.id] = { id=current.id, ox=0, oy=0, map=current },
  }
  for _, nb in ipairs(world.neighbors or {}) do
    local id = (nb.map and nb.map.id) or nb.id
    local ox, oy = tonumber(nb.ox), tonumber(nb.oy)
    if id and ox and oy then
      placed[id] = { id=id, ox=ox, oy=oy, map=nb.map }
    end
  end
  if not placed[targetMapId] then return nil end

  local queue = { { id=current.id, path={} } }
  local head, seen = 1, { [current.id]=true }
  while head <= #queue do
    local node = queue[head]; head = head + 1
    if #node.path < 4 then
      local sourcePlaced = placed[node.id]
      local sourceDef = maps[node.id]
      for _, compass in ipairs({ "north", "south", "west", "east" }) do
        local conn = sourceDef and sourceDef.connections
          and sourceDef.connections[compass] or nil
        local destId = conn and (conn.map or conn.mapId) or nil
        local destPlaced = destId and placed[destId] or nil
        local destDef = destId and maps[destId] or nil
        if destPlaced and destDef and not seen[destId] then
          local ex, ey = ControlsFree.goldConnectionPlacedOffset(
            sourceDef, destDef, compass, conn, sourcePlaced.ox, sourcePlaced.oy)
          if ex and math.abs(ex - destPlaced.ox) < 0.01
              and math.abs(ey - destPlaced.oy) < 0.01 then
            local destMap = WorldBackend.gold.neighborMap(game, destId)
            local destOverview = overviewFromLoadedMap(destMap)
            if destMap and destOverview then
              local leg = {
                sourceMapId = node.id, destMapId = destId,
                dir = COMPASS_TO_DIR[compass], compass = compass, conn = conn,
                destOverview = destOverview, destMap = destMap,
                renderOx = destPlaced.ox, renderOy = destPlaced.oy,
              }
              local path = {}
              for i, oldLeg in ipairs(node.path) do path[i] = oldLeg end
              path[#path + 1] = leg
              if destId == targetMapId then return path end
              seen[destId] = true
              queue[#queue + 1] = { id=destId, path=path }
            end
          end
        end
      end
    end
  end
  return nil
end

-- Static tail validation for a remote visible target.  Only the CURRENT map
-- uses live NPC occupancy; future maps are evaluated from their loaded Gold
-- collision/ledge topology.  After each real map.entered the next leg is
-- replanned with the destination's now-live NPCs, so a moving trainer cannot
-- permanently poison a route planned one map earlier.
function ControlsFree.remoteConnectionTailScore(
    game, remote, mapId, startX, startY, nextLegIndex, waterMode, depth)
  if not (remote and mapId and startX ~= nil and startY ~= nil) then return nil end
  depth = (depth or 0) + 1
  if depth > 4 then return nil end
  state.stats.remoteConnectionStaticChecks =
    (state.stats.remoteConnectionStaticChecks or 0) + 1

  local map = WorldBackend.gold.neighborMap(game, mapId)
  local overview = overviewFromLoadedMap(map)
  if not (map and overview) then return nil end
  local topology = ledgeTopology(game, map, overview)

  if mapId == remote.mapId then
    local path = findPath(overview, startX, startY, remote.x, remote.y,
      waterMode, {}, {}, topology.blockedEdges, {}, topology.jumps)
    return path and #path or nil
  end

  local leg = remote.route and remote.route[nextLegIndex or 1] or nil
  if not (leg and leg.sourceMapId == mapId and leg.destOverview and leg.destMap) then
    return nil
  end

  local best
  local curHint = { x=startX, y=startY }
  local seamCells = ControlsFree.budgetedSeamSourceCells(
    leg, overview, curHint, remote.x, remote.y)

  local function consider(sourceX, sourceY, entryX, entryY, crossCost)
    local sch = cellChar(overview, sourceX, sourceY)
    if not sch or sch == "+" then return end
    local lch = cellChar(leg.destOverview, entryX, entryY)
    if lch ~= "." and not (lch == "~" and waterMode) then return end
    local pathHere = findPath(overview, startX, startY, sourceX, sourceY,
      waterMode, {}, {}, topology.blockedEdges, {}, topology.jumps)
    if not pathHere then return end
    local tail = ControlsFree.remoteConnectionTailScore(
      game, remote, leg.destMapId, entryX, entryY,
      (nextLegIndex or 1) + 1, waterMode, depth)
    if not tail then return end
    local score = #pathHere + (crossCost or 1) + tail
    if not best or score < best then best = score end
  end

  for _, src in ipairs(seamCells) do
    local lx, ly = seamLanding(leg, src.x, src.y)
    consider(src.x, src.y, lx, ly, 1)
  end
  for _, jump in ipairs(topology.seamJumps or {}) do
    if jump.dir == leg.dir then
      local lx, ly = seamLanding(leg, jump.midX, jump.midY)
      consider(jump.sourceX, jump.sourceY, lx, ly, jump.cost or 2)
    end
  end
  return best
end

function ControlsFree.advanceRemoteConnection(game, nav, cur)
  local remote = nav and nav.remoteGoal
  if not (remote and cur) then return nil, "missing_remote" end
  if cur.mapId == remote.mapId then return true end
  local nextIndex = (remote.routeIndex or 1) + 1
  local leg = remote.route and remote.route[nextIndex] or nil
  if not (leg and leg.sourceMapId == cur.mapId) then
    return nil, "remote_route_mismatch"
  end
  remote.routeIndex = nextIndex
  local cross = copyFlat(leg)
  if cross.destMapId == remote.mapId then
    cross.targetX, cross.targetY = remote.x, remote.y
  end
  nav.cross = cross
  nav.path, nav.index = nil, 1
  nav.targetX, nav.targetY = nil, nil
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.needsReplan = false
  nav.replanReason = nil
  state.stats.remoteConnectionLegs =
    (state.stats.remoteConnectionLegs or 0) + 1
  state.stats.remoteConnectionReplans =
    (state.stats.remoteConnectionReplans or 0) + 1
  return rebuildNavigation(game, nav, cur)
end


-- Gold cross-map controller (test10) -----------------------------------------
--
-- This is intentionally separate from the older remote-tail planner.  A tap on
-- a map that Gold itself has already rendered is accepted immediately.  We then
-- use the cartridge map headers only for MAP-ID connectivity and re-plan one
-- physical seam at a time from the LIVE map.  No future-map A* proof is needed
-- before the player is allowed to cross the first edge.
--
-- Why this is safer: World:tryConnection() is authoritative.  It validates the
-- destination landing, calls setMap(..., {seamless=true}), emits map.entered,
-- parks the player one cell before the landing and lets the real player step
-- finish.  Tap to Move therefore only has to reach a legal source seam and hold
-- the normal D-pad direction.  After the real landing we recompute from scratch.
function ControlsFree.goldSimpleMapRoute(game, startMapId, finalMapId)
  if not WorldBackend.isGold(game) or not startMapId or not finalMapId then
    return nil
  end
  if startMapId == finalMapId then return {} end
  local maps = WorldBackend.gold.mapDefinitions(game)
  if not (maps and maps[startMapId] and maps[finalMapId]) then return nil end

  local queue = { { id = startMapId, route = {} } }
  local head = 1
  local seen = { [startMapId] = true }
  local order = { "north", "south", "west", "east" }
  local maxDepth = 16 -- far above the two-hop renderer window; still bounded.
  while head <= #queue do
    local node = queue[head]
    head = head + 1
    if #node.route < maxDepth then
      local def = maps[node.id]
      for _, compass in ipairs(order) do
        local conn = def and def.connections and def.connections[compass] or nil
        local destId = conn and (conn.mapId or conn.map) or nil
        if destId and maps[destId] and not seen[destId] then
          local route = {}
          for i, leg in ipairs(node.route) do route[i] = leg end
          route[#route + 1] = {
            sourceMapId = node.id,
            destMapId = destId,
            compass = compass,
            dir = COMPASS_TO_DIR[compass],
            conn = conn,
          }
          if destId == finalMapId then return route end
          seen[destId] = true
          queue[#queue + 1] = { id = destId, route = route }
        end
      end
    end
  end
  return nil
end

function ControlsFree.goldSimpleCrossForLeg(game, leg, finalGoal)
  if not (leg and leg.sourceMapId and leg.destMapId and leg.dir) then return nil end
  local destMap = WorldBackend.gold.neighborMap(game, leg.destMapId)
  local destOverview = overviewFromLoadedMap(destMap)
  if not (destMap and destOverview) then return nil end
  return {
    sourceMapId = leg.sourceMapId,
    destMapId = leg.destMapId,
    compass = leg.compass,
    dir = leg.dir,
    conn = leg.conn,
    destMap = destMap,
    destOverview = destOverview,
    -- These are only a seam-selection hint.  Intermediate maps are never asked
    -- to prove a route to the final map's coordinates.
    targetX = finalGoal and finalGoal.x or nil,
    targetY = finalGoal and finalGoal.y or nil,
  }
end

function ControlsFree.goldSimpleRemoteTarget(game, targetMapId, x, y)
  local cur = mod.world and mod.world:current()
  if not (cur and targetMapId and x ~= nil and y ~= nil) then return nil end
  local route = ControlsFree.goldSimpleMapRoute(game, cur.mapId, targetMapId)
  if not route or #route == 0 then return nil end
  local goal = { mapId = targetMapId, x = math.floor(x), y = math.floor(y) }
  local cross = ControlsFree.goldSimpleCrossForLeg(game, route[1], goal)
  if not cross then return nil end
  cross.goldSimpleRemote = goal
  return cross
end

-- Pick a physically reachable source seam using ONLY the live source map and
-- the real destination landing cell.  Unlike chooseCrossSeam(), this never
-- requires a static path through future maps.  That is exactly the Gen1-style
-- lifecycle requested for Gold: walk -> cross -> observe -> re-plan.
function ControlsFree.chooseGoldSimpleCrossSeam(game, nav, cur, occupancy)
  local cross = nav and nav.cross
  local overview = WorldBackend.overview(game)
  if not (cross and overview and overview.mapId == cross.sourceMapId
      and cross.destOverview and cross.destMap) then return nil end

  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local sourceMap = WorldBackend.map(game)
  local topology = ledgeTopology(game, sourceMap, overview)
  local blockedEdges = mergeBlockedEdges(nav.blockedEdges, topology.blockedEdges)
  local goal = nav.goldSimpleRemote
  local best

  local seamCells = ControlsFree.budgetedSeamSourceCells(
    cross, overview, cur,
    (cross.destMapId == (goal and goal.mapId)) and goal.x or nil,
    (cross.destMapId == (goal and goal.mapId)) and goal.y or nil)

  local function scoreCandidate(sx, sy, pathHere, lx, ly, extra, ledge)
    local score = #pathHere + (extra or 1)
    -- On the final connection prefer the landing closest to the clicked cell,
    -- but never reject a valid seam just because the destination path has not
    -- been proven yet.  Once the map is live, normal A* owns that decision.
    if goal and cross.destMapId == goal.mapId then
      score = score + math.abs(lx - goal.x) + math.abs(ly - goal.y)
    end
    if not best or score < best.score then
      best = {
        score = score, path = pathHere,
        sourceX = sx, sourceY = sy, entryX = lx, entryY = ly,
      }
      if ledge then
        best.ledgeSeam = true
        best.ledgeMidX, best.ledgeMidY = ledge.midX, ledge.midY
      end
    end
  end

  for _, src in ipairs(seamCells) do
    local sx, sy = math.floor(src.x), math.floor(src.y)
    local sch = cellChar(overview, sx, sy)
    if sch and sch ~= "+" then
      local lx, ly = seamLanding(cross, sx, sy)
      lx, ly = math.floor(lx), math.floor(ly)
      local lch = cellChar(cross.destOverview, lx, ly)
      local landingOK = lch == "." or (lch == "~" and waterMode)
      local ox, oy = sx, sy
      if cross.dir == "up" then oy = sy - 1
      elseif cross.dir == "down" then oy = sy + 1
      elseif cross.dir == "left" then ox = sx - 1
      else ox = sx + 1 end
      if landingOK and not nav.blockedEdges[edgeKey(sx, sy, ox, oy)] then
        local pathHere = findPath(overview, cur.x, cur.y, sx, sy, waterMode,
          occupancy, nav.tempBlocked, blockedEdges, nav.blockedCells,
          topology.jumps)
        if pathHere then scoreCandidate(sx, sy, pathHere, lx, ly, 1) end
      end
    end
  end

  -- Preserve Gold ledge-at-seam support without future-map validation.
  for _, jump in ipairs(topology.seamJumps or {}) do
    if jump.dir == cross.dir then
      local lx, ly = seamLanding(cross, jump.midX, jump.midY)
      lx, ly = math.floor(lx), math.floor(ly)
      local lch = cellChar(cross.destOverview, lx, ly)
      if lch == "." or (lch == "~" and waterMode) then
        local pathHere = findPath(overview, cur.x, cur.y,
          jump.sourceX, jump.sourceY, waterMode, occupancy, nav.tempBlocked,
          blockedEdges, nav.blockedCells, topology.jumps)
        if pathHere then
          scoreCandidate(jump.sourceX, jump.sourceY, pathHere, lx, ly,
            jump.cost or 2, jump)
        end
      end
    end
  end
  return best
end

function ControlsFree.advanceGoldSimpleRemote(game, nav, cur)
  local goal = nav and nav.goldSimpleRemote
  if not (goal and cur) then return nil, "missing_goal" end

  nav.mapId = cur.mapId
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.lastProgressTick = state.tick
  nav.path, nav.index = nil, 1
  nav.needsReplan = false
  nav.replanReason = nil

  if cur.mapId == goal.mapId then
    nav.cross = nil
    nav.goalKind = "move"
    nav.targetX, nav.targetY = goal.x, goal.y
    nav.requestedMapId = goal.mapId
    nav.requestedX, nav.requestedY = goal.x, goal.y
    -- From this point all intent coordinates are in the live destination map.
    nav.intentX, nav.intentY = goal.x + 0.5, goal.y + 0.5
    local ok, why = buildPath(game, nav, cur)
    if ok then return true end
    if why ~= "dynamic" then
      -- Match ordinary local tap semantics: if the clicked remote cell is
      -- scenery, stop at the closest reachable floor and allow the endpoint
      -- interaction assist to interpret a nearby PC/NPC/fixture afterwards.
      local nearest, nwhy = buildNearestLegalPath(game, nav, cur, goal.x, goal.y)
      if nearest then return true end
      return nil, nwhy or why
    end
    return nil, why
  end

  local route = ControlsFree.goldSimpleMapRoute(game, cur.mapId, goal.mapId)
  if not route or #route == 0 then return nil, "no_map_route" end
  local cross = ControlsFree.goldSimpleCrossForLeg(game, route[1], goal)
  if not cross then return nil, "missing_next_map" end
  cross.goldSimpleRemote = goal
  nav.cross = cross
  nav.goalKind = "cross_move"
  return buildCrossPath(game, nav, cur)
end

-- Resolve a tap against the ACTUAL neighbour rectangles the overworld renderer
-- has already composed for survey view.  Using ow.neighbors[].ox/oy makes the
-- pointer hit-test share one source of truth with rendering instead of
-- re-deriving connection placement a second time from offsets. Gold may render
-- a second-hop neighbour in survey view; those targets are carried as one
-- persistent route whose connection legs are revalidated after each native
-- map transition. Gen 1 keeps its established direct-neighbour behavior.
local function visibleNeighborTarget(game, worldX, worldY, overview)
  local ow = WorldBackend.owner(game)
  local current = WorldBackend.map(game)
  local connections = current and current.def and current.def.connections
  if not ow or not connections then return nil end
  local directByMap = {}
  for _, compass in ipairs({ "north", "south", "west", "east" }) do
    local conn = connections[compass]
    local id = conn and (conn.map or conn.mapId)
    if id then
      directByMap[id] = { conn = conn, compass = compass,
                          dir = COMPASS_TO_DIR[compass] }
    end
  end
  local sawVisibleNeighbour = false
  for _, nb in ipairs(ow.neighbors or {}) do
    local mapId = (nb.map and nb.map.id) or nb.id
    local map = nb.map or (WorldBackend.isGold(game)
      and WorldBackend.gold.neighborMap(game, mapId)) or nil
    local dw, dh = mapCellSize(map and map.def, map)
    local ox, oy = tonumber(nb.ox), tonumber(nb.oy)
    if map and dw and dh and ox and oy
        and worldX >= ox and worldY >= oy
        and worldX < ox + dw * TILE_SIZE and worldY < oy + dh * TILE_SIZE then
      sawVisibleNeighbour = true
      local lx = math.floor((worldX - ox) / TILE_SIZE)
      local ly = math.floor((worldY - oy) / TILE_SIZE)
      local destOverview = overviewFromLoadedMap(map)
      if destOverview and lx >= 0 and ly >= 0
          and lx < destOverview.width and ly < destOverview.height then
        if WorldBackend.isGold(game) then
          -- The renderer has already proven this map is part of the visible
          -- seamless world.  Do not make a second geometry proof here.  Build
          -- a map-id route and let each physical Gold connection validate its
          -- own landing at runtime.
          local cross = ControlsFree.goldSimpleRemoteTarget(game, mapId, lx, ly)
          if cross then
            state.stats.remoteConnectionTargets =
              (state.stats.remoteConnectionTargets or 0) + 1
            return cross, true
          end
        else
          local direct = directByMap[mapId]
          if direct then
            return { sourceMapId = overview.mapId, destMapId = mapId,
              dir = direct.dir, compass = direct.compass, conn = direct.conn,
              targetX = lx, targetY = ly, destOverview = destOverview,
              destMap = map, renderOx = ox, renderOy = oy }, true
          end
        end
      end
      return nil, true
    end
  end
  return nil, sawVisibleNeighbour
end

local function neighbourInteractionAt(game, cross, x, y)
  if WorldBackend.isGold(game) then return nil end
  if not cross then return nil end
  local ow = game and game.overworld
  local ghosts = {}
  for _, ghost in ipairs((ow and ow.ghosts) or {}) do
    if ghost.map and ghost.map.id == cross.destMapId
        and entityIsInteractable(ghost.npc) then
      ghosts[#ghosts + 1] = ghost.npc
      local entity = ghost.npc
      if (entity.cellX == x and entity.cellY == y)
          or (entity.targetX == x and entity.targetY == y) then
        return entityInteraction(entity, x, y)
      end
    end
  end

  local fixed = staticInteractionAt(game, cross.destMapId, cross.destMap, x, y)
  if fixed then return fixed end

  -- Counter proxy on a rendered neighbour: use the loaded map's own counter
  -- classification and the visual ghost actors that will become real NPCs
  -- after the seamless crossing.
  local destMap = cross.destMap
  if destMap and type(destMap.isCounterCell) == "function" then
    local ok, isCounter = pcall(destMap.isCounterCell, destMap, x, y)
    if ok and isCounter then
      for _, d in ipairs(DIRS) do
        local bx, by = x + d.dx, y + d.dy
        for _, entity in ipairs(ghosts) do
          if (entity.cellX == bx and entity.cellY == by)
              or (entity.targetX == bx and entity.targetY == by) then
            local out = entityInteraction(entity, x, y)
            out.counterProxy = true
            out.preferredFacing = d.name
            return out
          end
        end
      end
    end
  end
  return nil
end


-- Voxel Provider Adapter -------------------------------------------------------
-- Keep the adapter in one namespace table: main.lua is already near Lua's
-- top-level local-variable ceiling, and companion integration should not spend
-- a dozen additional locals just to name adapter helpers.
local VoxelAdapter = {
  providers = {
    { id = "DRAMATIC_SHAPE", kind = "dramatic_shape", short = "DS" },
    { id = "potato_voxel", kind = "potato_voxel", short = "POTATO" },
  },
  cache = { id = nil, peer = nil, lib = nil },
}

function VoxelAdapter.module(lib, name)
  if type(lib) ~= "table" or type(lib.require) ~= "function" then return nil end
  local ok, value = pcall(lib.require, name)
  return ok and value or nil
end

function VoxelAdapter.discover()
  if WorldBackend.isGold(state.game) then
    -- Gold stays renderer-independent until a provider exposes an explicit,
    -- verified Gold scene contract. Never feed Gen I voxel assumptions into it.
    VoxelAdapter.cache = { id = nil, peer = nil, lib = nil }
    return nil
  end
  if type(mod.find) ~= "function" then
    VoxelAdapter.cache = { id = nil, peer = nil, lib = nil }
    return nil
  end

  local selected, fallback
  for _, spec in ipairs(VoxelAdapter.providers) do
    local okPeer, peer = pcall(mod.find, spec.id)
    local lib = okPeer and peer and type(peer.exports) == "table"
      and peer.exports.lib or nil
    if peer and type(lib) == "table" and type(lib.require) == "function" then
      local voxelState = VoxelAdapter.module(lib, "VoxelState")
      local voxel3d = VoxelAdapter.module(lib, "Voxel3D")
      if type(voxel3d) == "table" and type(voxel3d.project) == "function" then
        local candidate = {
          id = spec.id, kind = spec.kind, short = spec.short,
          peer = peer, lib = lib, voxelState = voxelState, voxel3d = voxel3d,
        }
        fallback = fallback or candidate
        local active = true
        if type(voxelState) == "table" and type(voxelState.active) == "function" then
          local okActive, value = pcall(voxelState.active)
          active = okActive and value == true
        end
        if active then selected = candidate break end
      end
    end
  end
  selected = selected or fallback
  if not selected then
    VoxelAdapter.cache = { id = nil, peer = nil, lib = nil }
    return nil
  end

  local old = VoxelAdapter.cache
  if old.id ~= selected.id or old.peer ~= selected.peer or old.lib ~= selected.lib then
    selected.voxelScene = VoxelAdapter.module(selected.lib, "VoxelScene")
    selected.structures = VoxelAdapter.module(selected.lib, "Structures")
    selected.tileShape = VoxelAdapter.module(selected.lib, "TileShape")
    selected.brickProfile = VoxelAdapter.module(selected.lib, "BrickProfile")
    selected.firstPerson = VoxelAdapter.module(selected.lib, "FirstPerson")
    VoxelAdapter.cache = selected
  end
  return VoxelAdapter.cache
end

function VoxelAdapter.canvasSize(scene)
  local voxel3d = scene and scene.voxel3d
  if type(voxel3d) ~= "table" then return nil end
  if type(voxel3d.size) == "function" then
    local ok, w, h = pcall(voxel3d.size)
    w, h = tonumber(w), tonumber(h)
    if ok and w and h and w > 0 and h > 0 then return w, h end
  end
  if type(voxel3d.canvas) == "function" then
    local okC, canvas = pcall(voxel3d.canvas)
    if okC and canvas then
      if type(canvas.getDimensions) == "function" then
        local ok, w, h = pcall(canvas.getDimensions, canvas)
        w, h = tonumber(w), tonumber(h)
        if ok and w and h and w > 0 and h > 0 then return w, h end
      end
      local okW, w = pcall(canvas.getWidth, canvas)
      local okH, h = pcall(canvas.getHeight, canvas)
      w, h = tonumber(w), tonumber(h)
      if okW and okH and w and h and w > 0 and h > 0 then return w, h end
    end
  end
  return nil
end

function VoxelAdapter.windowSize()
  local frame = state.frame or {}
  local ww, wh = tonumber(frame.ww), tonumber(frame.wh)
  if ww and wh and ww > 0 and wh > 0 then return ww, wh end
  if love and love.graphics and type(love.graphics.getDimensions) == "function" then
    local ok, w, h = pcall(love.graphics.getDimensions)
    w, h = tonumber(w), tonumber(h)
    if ok and w and h and w > 0 and h > 0 then return w, h end
  end
  return nil
end

function VoxelAdapter.pixelSize()
  local frame = state.frame or {}
  local pw, ph = tonumber(frame.pw), tonumber(frame.ph)
  if pw and ph and pw > 0 and ph > 0 then return pw, ph end
  if love and love.graphics and type(love.graphics.getPixelDimensions) == "function" then
    local ok, w, h = pcall(love.graphics.getPixelDimensions)
    w, h = tonumber(w), tonumber(h)
    if ok and w and h and w > 0 and h > 0 then return w, h end
  end
  return nil
end

function VoxelAdapter.flipY()
  -- v0.1.84+ sandboxes the LÖVE system module away from mod chunks. Platform detection
  -- belongs to the engine; ControlsFree.hostOS() reaches the engine's narrow
  -- Platform helper through the already-declared engine_internals permission.
  return ControlsFree.hostOS() == "iOS"
end

function VoxelAdapter.windowToCanvas(scene, x, y)
  local cw, ch = VoxelAdapter.canvasSize(scene)
  local ww, wh = VoxelAdapter.windowSize()
  if not (cw and ch and ww and wh) then return nil end
  local px, py = x * cw / ww, y * ch / wh
  if VoxelAdapter.flipY() then py = ch - py end
  return px, py, cw, ch
end

function VoxelAdapter.canvasToWindow(scene, x, y)
  local cw, ch = VoxelAdapter.canvasSize(scene)
  local ww, wh = VoxelAdapter.windowSize()
  if not (cw and ch and ww and wh) then return nil end
  if VoxelAdapter.flipY() then y = ch - y end
  return x * ww / cw, y * wh / ch
end

function VoxelAdapter.groundHeight(scene, map, cellX, cellY)
  local voxelScene = scene and scene.voxelScene
  if type(voxelScene) == "table" and type(voxelScene.groundAt) == "function" then
    local ok, h = pcall(voxelScene.groundAt, map, cellX, cellY)
    h = tonumber(h)
    if ok and h then return h end
  end
  local tileShape = scene and scene.tileShape
  if map and tileShape and type(tileShape.forMap) == "function"
      and type(map.cellTile) == "function" then
    if type(map.inBounds) == "function" then
      local ok, inside = pcall(map.inBounds, map, cellX, cellY)
      if ok and not inside then return 0 end
    end
    local okS, shapes = pcall(tileShape.forMap, map)
    local okT, tile = pcall(map.cellTile, map, cellX, cellY)
    local shape = okS and okT and type(shapes) == "table" and shapes[tile] or nil
    if type(shape) == "table" and shape.art ~= "stair" then
      return math.max(0, tonumber(shape.h) or 0)
    end
  end
  return 0
end

local function voxelContext()
  local scene = VoxelAdapter.discover()
  if not scene then return nil end
  local voxelState, voxel3d = scene.voxelState, scene.voxel3d
  if type(voxel3d) ~= "table" or type(voxel3d.project) ~= "function" then return nil end

  if type(voxelState) == "table" and type(voxelState.active) == "function" then
    local okActive, active = pcall(voxelState.active)
    if not okActive or not active then return nil end
    -- Async mesh builders explicitly expose readiness. Do not let a stale VP
    -- or stale canvas from the previous map/frame turn a 2D fallback frame into
    -- a bogus 3D pick.
    if voxelState.ready == false then return nil end
  end

  local cw, ch = VoxelAdapter.canvasSize(scene)
  if not (cw and ch and type(voxel3d.vp) == "table" and #voxel3d.vp >= 16) then
    return nil
  end
  scene.canvasW, scene.canvasH = cw, ch
  scene.ready = true
  return scene
end

local function pointInTriangle(px, py, ax, ay, bx, by, cx, cy)
  local v0x, v0y = cx - ax, cy - ay
  local v1x, v1y = bx - ax, by - ay
  local v2x, v2y = px - ax, py - ay
  local dot00 = v0x * v0x + v0y * v0y
  local dot01 = v0x * v1x + v0y * v1y
  local dot02 = v0x * v2x + v0y * v2y
  local dot11 = v1x * v1x + v1y * v1y
  local dot12 = v1x * v2x + v1y * v2y
  local denom = dot00 * dot11 - dot01 * dot01
  if math.abs(denom) < 0.000001 then return false end
  local inv = 1 / denom
  local u = (dot11 * dot02 - dot01 * dot12) * inv
  local v = (dot00 * dot12 - dot01 * dot02) * inv
  return u >= -0.001 and v >= -0.001 and (u + v) <= 1.001
end

local function pointInQuad(px, py, q)
  return pointInTriangle(px, py, q[1][1], q[1][2], q[2][1], q[2][2],
                         q[3][1], q[3][2])
      or pointInTriangle(px, py, q[1][1], q[1][2], q[3][1], q[3][2],
                         q[4][1], q[4][2])
end

local function pointSegmentDistance2(px, py, ax, ay, bx, by)
  local vx, vy = bx - ax, by - ay
  local len2 = vx * vx + vy * vy
  if len2 <= 0.000001 then
    local dx, dy = px - ax, py - ay
    return dx * dx + dy * dy
  end
  local t = ((px - ax) * vx + (py - ay) * vy) / len2
  if t < 0 then t = 0 elseif t > 1 then t = 1 end
  local qx, qy = ax + vx * t, ay + vy * t
  local dx, dy = px - qx, py - qy
  return dx * dx + dy * dy
end

local function framebufferPoint(x, y, voxel3d)
  local scene = VoxelAdapter.discover()
  if scene and scene.voxel3d == voxel3d then
    return VoxelAdapter.windowToCanvas(scene, x, y)
  end
  return nil
end

local function projectedPoint(voxel3d, wx, wy, height)
  local ok, sx, sy, depth = pcall(voxel3d.project, wx, height or 0, wy)
  if not ok or type(sx) ~= "number" or type(sy) ~= "number"
      or sx ~= sx or sy ~= sy then
    return nil
  end
  return { sx, sy, tonumber(depth) }
end

-- Texture-independent semantic hit for engine hidden-event fixtures in the
-- active Voxel provider scene.  We do NOT inspect a texture or ask the event
-- to execute.  Instead, project the gameplay cell that owns each known hidden
-- fixture into screen space and use that only to SELECT the interaction.  The
-- pathfinder then walks to a legal adjacent cell, faces the required direction
-- and presses ordinary A; Gen1Recomp's native interaction dispatcher remains
-- the authority that actually opens the PC/text/menu.
function ControlsFree.voxelFixedHiddenInteractionFromTap(game, x, y, scene)
  local voxel3d = scene and scene.voxel3d
  local ow = game and game.overworld
  local map = ow and ow.map
  if not (voxel3d and map and type(voxel3d.project) == "function") then return nil end

  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if not cur or not overview or cur.mapId ~= map.id or overview.mapId ~= map.id then
    return nil
  end

  local px, py, cw, ch = framebufferPoint(x, y, voxel3d)
  if type(px) ~= "number" or type(py) ~= "number" then return nil end

  local frame = state.frame or {}
  local ww, wh = tonumber(frame.ww), tonumber(frame.wh)
  local scaleX = cw and ww and ww > 0 and cw / ww or tonumber(frame.dpiX) or 1
  local scaleY = ch and wh and wh > 0 and ch / wh or tonumber(frame.dpiY) or 1
  local pad = 5 * math.max(1, scaleX, scaleY)

  local best, bestScore
  for _, interaction in ipairs(ControlsFree.fixedHiddenInteractionCandidates(game, map.id, map)) do
    local cx, cy = tonumber(interaction.x), tonumber(interaction.y)
    if cx and cy then
      local x0, x1 = cx * TILE_SIZE, (cx + 1) * TILE_SIZE
      local z0, z1 = cy * TILE_SIZE, (cy + 1) * TILE_SIZE
      local minX, minY, maxX, maxY
      local okProjection = true
      for _, wx in ipairs({ x0, x1 }) do
        for _, wz in ipairs({ z0, z1 }) do
          for _, h in ipairs({ 0, VOXEL_COLUMN_HEIGHT }) do
            local q = projectedPoint(voxel3d, wx, wz, h)
            if q then
              minX = not minX and q[1] or math.min(minX, q[1])
              maxX = not maxX and q[1] or math.max(maxX, q[1])
              minY = not minY and q[2] or math.min(minY, q[2])
              maxY = not maxY and q[2] or math.max(maxY, q[2])
            else
              okProjection = false
            end
          end
        end
      end

      if okProjection and minX and px >= minX - pad and px <= maxX + pad
          and py >= minY - pad and py <= maxY + pad then
        local mid = projectedPoint(voxel3d, (cx + 0.5) * TILE_SIZE,
                                   (cy + 0.5) * TILE_SIZE,
                                   VOXEL_COLUMN_MID_HEIGHT)
        local score
        if mid then
          local dx, dy = px - mid[1], py - mid[2]
          score = dx * dx + dy * dy
        else
          local mx, my = (minX + maxX) * 0.5, (minY + maxY) * 0.5
          local dx, dy = px - mx, py - my
          score = dx * dx + dy * dy
        end
        if not best or score < bestScore then
          best, bestScore = interaction, score
        end
      end
    end
  end

  if not best then return nil end
  return {
    x = best.x, y = best.y, interaction = best,
    cur = cur, overview = overview,
  }
end

local voxelCandidateCache = { map = nil, neighbors = nil, connections = nil, entries = nil }

local function invalidateVoxelCandidateCache()
  voxelCandidateCache = { map = nil, neighbors = nil, connections = nil, entries = nil }
end

local function voxelCandidateMaps(game, overview)
  local ow = game and game.overworld
  if not ow or not ow.map then return {} end
  local connections = ow.map.def and ow.map.def.connections
  if voxelCandidateCache.map == ow.map
      and voxelCandidateCache.neighbors == ow.neighbors
      and voxelCandidateCache.connections == connections
      and voxelCandidateCache.entries then
    -- Active-map mapOverview is the one live piece (it can change after a
    -- block edit). Reuse the structural entry set but refresh that authority.
    voxelCandidateCache.entries[1].overview = overview
    return voxelCandidateCache.entries
  end

  local out = {
    { map = ow.map, mapId = ow.map.id, ox = 0, oy = 0, active = true,
      overview = overview },
  }
  local direct = {}
  for _, conn in pairs(connections or {}) do
    if conn and (conn.map or conn.mapId) then direct[conn.map] = true end
  end
  for _, nb in ipairs(ow.neighbors or {}) do
    if nb.map and direct[nb.map.id] then
      out[#out + 1] = {
        map = nb.map, mapId = nb.map.id,
        ox = tonumber(nb.ox) or 0, oy = tonumber(nb.oy) or 0,
        active = false, overview = overviewFromLoadedMap(nb.map),
      }
    end
  end
  voxelCandidateCache = {
    map = ow.map, neighbors = ow.neighbors, connections = connections, entries = out,
  }
  return out
end

local function voxelStrongSemanticCell(game, entry, x, y)
  local map = entry and entry.map
  local ov = entry and entry.overview
  local ch = cellChar(ov, x, y)

  -- A visible wall/solid or warp is exactly where 3D geometry can cover a
  -- more distant floor quad. Treat those as occluding semantic surfaces.
  if ch == " " or ch == "+" then return true end

  if map and map.def then
    for _, w in ipairs(map.def.warps or {}) do
      if tonumber(w.x) == x and tonumber(w.y) == y then return true end
    end
    local fixed = staticInteractionAt(game, map.id, map, x, y)
    if fixed then return true end
    if type(map.isCounterCell) == "function" then
      local ok, yes = pcall(map.isCounterCell, map, x, y)
      if ok and yes then return true end
    end
  end

  local ow = game and game.overworld
  if entry and entry.active then
    for _, entity in ipairs((ow and ow.npcs) or {}) do
      if entityIsInteractable(entity)
          and ((entity.cellX == x and entity.cellY == y)
            or (entity.targetX == x and entity.targetY == y)) then
        return true
      end
    end
  else
    for _, ghost in ipairs((ow and ow.ghosts) or {}) do
      local entity = ghost.npc
      if ghost.map and map and ghost.map.id == map.id
          and entityIsInteractable(entity)
          and ((entity.cellX == x and entity.cellY == y)
            or (entity.targetX == x and entity.targetY == y)) then
        return true
      end
    end
  end
  return false
end

-- ------------------------------ native Voxel 3D ray picking -----------------
-- Voxel3D exposes the exact row-major view-projection matrix used by the
-- shader.  Invert it and cast the pointer back through the rendered scene.
-- This is the important distinction from the older compatibility layer:
-- the TOUCH is now interpreted in Voxel camera space first, and only then
-- translated back to a Gen1 gameplay cell.
local function invert4(m)
  if type(m) ~= "table" or #m < 16 then return nil end
  local a = {}
  for r = 1, 4 do
    a[r] = {}
    for c = 1, 4 do a[r][c] = tonumber(m[(r - 1) * 4 + c]) or 0 end
    for c = 1, 4 do a[r][c + 4] = (r == c) and 1 or 0 end
  end
  for c = 1, 4 do
    local pivot = c
    local best = math.abs(a[c][c])
    for r = c + 1, 4 do
      local v = math.abs(a[r][c])
      if v > best then best, pivot = v, r end
    end
    if best < 1e-12 then return nil end
    if pivot ~= c then a[c], a[pivot] = a[pivot], a[c] end
    local d = a[c][c]
    for j = 1, 8 do a[c][j] = a[c][j] / d end
    for r = 1, 4 do
      if r ~= c then
        local f = a[r][c]
        if math.abs(f) > 1e-15 then
          for j = 1, 8 do a[r][j] = a[r][j] - f * a[c][j] end
        end
      end
    end
  end
  local out = {}
  for r = 1, 4 do
    for c = 1, 4 do out[(r - 1) * 4 + c] = a[r][c + 4] end
  end
  return out
end

local function mulPoint4(m, x, y, z, w)
  return m[1]*x + m[2]*y + m[3]*z + m[4]*w,
         m[5]*x + m[6]*y + m[7]*z + m[8]*w,
         m[9]*x + m[10]*y + m[11]*z + m[12]*w,
         m[13]*x + m[14]*y + m[15]*z + m[16]*w
end

local function voxelRayFromPointer(x, y, voxel3d)
  local vp = voxel3d and voxel3d.vp
  if type(vp) ~= "table" then return nil end
  local px, py, cw, ch = framebufferPoint(x, y, voxel3d)
  if not (px and py and cw and ch and cw > 0 and ch > 0) then return nil end
  local inv = invert4(vp)
  if not inv then return nil end
  local nx, ny = px / cw * 2 - 1, py / ch * 2 - 1
  local x0,y0,z0,w0 = mulPoint4(inv, nx, ny, -1, 1)
  local x1,y1,z1,w1 = mulPoint4(inv, nx, ny,  1, 1)
  if math.abs(w0) < 1e-12 or math.abs(w1) < 1e-12 then return nil end
  x0,y0,z0 = x0/w0,y0/w0,z0/w0
  x1,y1,z1 = x1/w1,y1/w1,z1/w1
  local dx,dy,dz = x1-x0,y1-y0,z1-z0
  local len = math.sqrt(dx*dx + dy*dy + dz*dz)
  if len < 1e-9 then return nil end
  return { x=x0, y=y0, z=z0, dx=dx/len, dy=dy/len, dz=dz/len,
           px=px, py=py, canvasW=cw, canvasH=ch }
end

local function voxelCurveDrop(voxel3d, x, z)
  local k = tonumber(voxel3d and voxel3d.curveK) or 0
  if k <= 0 then return 0 end
  local cx = tonumber(voxel3d.curveX) or 0
  local cz = tonumber(voxel3d.curveZ) or 0
  local dx, dz = x - cx, z - cz
  return (dx*dx + dz*dz) * k
end

-- Intersect the live ray with the same curved ground equation Voxel3D.project
-- applies in its shader: y = -k * distance_from_focus^2.
local function rayGroundT(ray, voxel3d)
  local k = tonumber(voxel3d and voxel3d.curveK) or 0
  local cx = tonumber(voxel3d and voxel3d.curveX) or 0
  local cz = tonumber(voxel3d and voxel3d.curveZ) or 0
  if k <= 0 then
    if math.abs(ray.dy) < 1e-9 then return nil end
    local t = -ray.y / ray.dy
    return t >= 0 and t or nil
  end
  local rx, rz = ray.x - cx, ray.z - cz
  local A = k * (ray.dx*ray.dx + ray.dz*ray.dz)
  local B = ray.dy + 2*k*(rx*ray.dx + rz*ray.dz)
  local C = ray.y + k*(rx*rx + rz*rz)
  if math.abs(A) < 1e-12 then
    if math.abs(B) < 1e-12 then return nil end
    local t = -C / B
    return t >= 0 and t or nil
  end
  local disc = B*B - 4*A*C
  if disc < 0 then return nil end
  local root = math.sqrt(disc)
  local t1, t2 = (-B-root)/(2*A), (-B+root)/(2*A)
  local best
  if t1 >= 0 then best = t1 end
  if t2 >= 0 and (not best or t2 < best) then best = t2 end
  return best
end

local function rayAabbT(ray, x0,y0,z0,x1,y1,z1, maxT)
  local tmin, tmax = 0, maxT or math.huge
  local function axis(o, d, lo, hi)
    if math.abs(d) < 1e-10 then
      if o < lo or o > hi then return nil end
      return -math.huge, math.huge
    end
    local a, b = (lo-o)/d, (hi-o)/d
    if a > b then a,b = b,a end
    return a,b
  end
  for _, row in ipairs({{ray.x,ray.dx,x0,x1},{ray.y,ray.dy,y0,y1},{ray.z,ray.dz,z0,z1}}) do
    local a,b = axis(row[1],row[2],row[3],row[4])
    if not a then return nil end
    if a > tmin then tmin = a end
    if b < tmax then tmax = b end
    if tmax < tmin then return nil end
  end
  if tmax < 0 then return nil end
  if tmin < 0 then tmin = 0 end
  return tmin
end

local function voxelStructureKey(tx, ty)
  return (ty + 64) * 4096 + (tx + 64)
end

local function voxelStructuresFor(scene, entry)
  if not scene or not scene.structures or not entry or not entry.map then return nil end
  if entry._tapStructures ~= nil then
    return entry._tapStructures ~= false and entry._tapStructures or nil
  end
  local ok, S = pcall(scene.structures.forMap, entry.map)
  entry._tapStructures = (ok and type(S) == "table") and S or false
  return entry._tapStructures ~= false and entry._tapStructures or nil
end

local function voxelTileHeight(scene, entry, tx, ty)
  local S = voxelStructuresFor(scene, entry)
  if not S then return nil end
  local k = voxelStructureKey(tx, ty)
  local shape = S.shapeAt and S.shapeAt[k]
  if not shape then return nil end
  -- `skip` means the ordinary column was replaced by a voxelized object.
  -- Its profile height is still a useful conservative picking hull; the
  -- renderer's synthesized ground remains at y=0 below it.
  local run = S.runs and S.runs[k]
  local h = tonumber(run and run.h) or tonumber(shape.h) or 0
  if run and tonumber(run.rise) and run.rise > 0 then h = h + run.rise end
  if h <= 0 and S.skip and S.skip[k] then h = tonumber(shape.h) or 16 end
  return h, shape, S
end

-- Find which gameplay map owns a world X/Z point.  Connected Voxel maps are
-- rendered in one world coordinate system using the exact nb.ox/nb.oy model
-- translations, so no screen-space guessing is needed here.
local function voxelMapAtWorld(entries, wx, wz)
  local best
  for _, entry in ipairs(entries or {}) do
    local map = entry.map
    local w = map and (map.widthCells or (map.def and map.def.width and map.def.width*2))
    local h = map and (map.heightCells or (map.def and map.def.height and map.def.height*2))
    if w and h then
      local lx, lz = wx - entry.ox, wz - entry.oy
      if lx >= 0 and lz >= 0 and lx < w*TILE_SIZE and lz < h*TILE_SIZE then
        local hit = { entry=entry, x=math.floor(lx/TILE_SIZE),
                      y=math.floor(lz/TILE_SIZE), lx=lx, lz=lz }
        if entry.active then return hit end
        best = best or hit
      end
    end
  end
  return best
end

-- Traverse the ray through a map's 8x8 visual-tile grid and test the actual
-- structure heights the active Voxel provider cached for its ChunkMesher.  This catches
-- a building/wall/counter BEFORE the ground behind it, matching the depth
-- buffered scene well enough for semantic picking without duplicating the
-- renderer's enormous raw mesh in Lua memory.
local function voxelStructureHit(scene, entry, ray, maxT)
  if not scene.structures then return nil end
  local map = entry.map
  local tw = map and map.def and map.def.width and map.def.width*4
  local th = map and map.def and map.def.height and map.def.height*4
  if not (tw and th) then return nil end

  -- Clip the ray's X/Z segment to the map body, then sample each crossed
  -- visual tile.  Step size 4px is half a voxel tile: conservative enough to
  -- never leap over an 8px column, while bounded by the camera->ground span.
  local startT, stopT = 0, maxT
  local function clip(o,d,lo,hi)
    if math.abs(d) < 1e-10 then return (o>=lo and o<=hi) and -math.huge or nil, math.huge end
    local a,b=(lo-o)/d,(hi-o)/d; if a>b then a,b=b,a end; return a,b
  end
  local ax,bx=clip(ray.x,ray.dx,entry.ox,entry.ox+tw*8)
  local az,bz=clip(ray.z,ray.dz,entry.oy,entry.oy+th*8)
  if not ax or not az then return nil end
  startT=math.max(startT,ax,az); stopT=math.min(stopT,bx,bz)
  if stopT < startT then return nil end

  local horiz=math.sqrt(ray.dx*ray.dx+ray.dz*ray.dz)
  local dt = horiz > 1e-9 and (4/horiz) or (stopT-startT+1)
  if dt <= 0 then return nil end
  local seen, bestT, bestTX, bestTY = {}, nil, nil, nil
  local t=startT
  local guard=0
  while t <= stopT + 1e-6 and guard < 4096 do
    guard=guard+1
    local wx,wz=ray.x+ray.dx*t,ray.z+ray.dz*t
    local tx=math.floor((wx-entry.ox)/8)
    local ty=math.floor((wz-entry.oy)/8)
    if tx>=0 and ty>=0 and tx<tw and ty<th then
      local kk=tx..","..ty
      if not seen[kk] then
        seen[kk]=true
        local h=voxelTileHeight(scene,entry,tx,ty)
        if h and h>0 then
          local x0,z0=entry.ox+tx*8,entry.oy+ty*8
          local cx,cz=x0+4,z0+4
          local base=-voxelCurveDrop(scene.voxel3d,cx,cz)
          local hit=rayAabbT(ray,x0,base,z0,x0+8,base+h,z0+8,maxT)
          if hit and hit <= maxT and (not bestT or hit<bestT) then
            bestT,bestTX,bestTY=hit,tx,ty
          end
        end
      end
    end
    t=t+dt
  end
  if not bestT then return nil end
  local _, shape, S = voxelTileHeight(scene, entry, bestTX, bestTY)
  local k = voxelStructureKey(bestTX, bestTY)
  return {
    t=bestT, entry=entry, x=math.floor(bestTX/2), y=math.floor(bestTY/2),
    visualTX=bestTX, visualTY=bestTY,
    visualTile=S and S.tileAt and S.tileAt[k] or nil,
    visualClass=shape and shape.class or nil,
  }
end

local function voxelEntityHit(game, entries, ray, maxT, voxel3d)
  local ow=game and game.overworld
  local best
  local function one(entity, entry)
    if not entityIsInteractable(entity) then return end
    local cx=entity.targetX or entity.cellX
    local cy=entity.targetY or entity.cellY
    if type(cx)~="number" or type(cy)~="number" then return end
    local x0=entry.ox+cx*TILE_SIZE
    local z0=entry.oy+cy*TILE_SIZE
    local base=-voxelCurveDrop(voxel3d,x0+8,z0+8)
    local hit=rayAabbT(ray,x0,base,z0,x0+16,base+40,z0+16,maxT)
    if hit and (not best or hit<best.t) then
      best={t=hit,entry=entry,x=cx,y=cy}
    end
  end
  local active=entries and entries[1]
  if active then for _,e in ipairs((ow and ow.npcs) or {}) do one(e,active) end end
  for _,ghost in ipairs((ow and ow.ghosts) or {}) do
    for _,entry in ipairs(entries or {}) do
      if not entry.active and ghost.map and entry.map and ghost.map.id==entry.map.id then
        one(ghost.npc,entry); break
      end
    end
  end
  return best
end

local function voxelRayTargetFromTap(game, x, y, scene)
  local voxel3d=scene and scene.voxel3d
  if not (voxel3d and type(voxel3d.vp)=="table") then return nil end
  local free=overworldGate(game)
  if not free then return { error="busy" } end
  local cur=mod.world and mod.world:current()
  local overview=WorldBackend.overview(game)
  if not cur or not overview or cur.mapId~=overview.mapId then return { error="no_map" } end
  local ray=voxelRayFromPointer(x,y,voxel3d)
  if not ray then return nil end
  local tGround=rayGroundT(ray,voxel3d)
  if not tGround then return { error="outside_world", cur=cur, overview=overview } end
  local gx,gz=ray.x+ray.dx*tGround,ray.z+ray.dz*tGround
  local entries=voxelCandidateMaps(game,overview)
  local activeEntry = entries and entries[1]
  local intentX = activeEntry and ((gx - activeEntry.ox) / TILE_SIZE) or nil
  local intentY = activeEntry and ((gz - activeEntry.oy) / TILE_SIZE) or nil

  local visible
  for _,entry in ipairs(entries) do
    local h=voxelStructureHit(scene,entry,ray,tGround)
    if h then h.kind = "structure" end
    if h and (not visible or h.t<visible.t) then visible=h end
  end
  local ent=voxelEntityHit(game,entries,ray,tGround,voxel3d)
  if ent then ent.kind = "entity" end
  if ent and (not visible or ent.t<visible.t) then visible=ent end

  local groundHit = voxelMapAtWorld(entries,gx,gz)

  -- The active Voxel provider already has a stronger answer than our 2D collision shell:
  -- Structures.forMap resolves every rendered 8x8 visual tile and classifies
  -- atlas-black/transparent interior darkness as shape.class == "void".
  -- Capture the EXACT ground visual tile under this ray before folding it back
  -- into Gen1's coarser 16x16 gameplay cell. A user can therefore tap the
  -- black tile they actually see and we can distinguish it from furniture or
  -- a wall that merely shares the same gameplay cell.
  local visualTile, visualClass, visualTX, visualTY
  if visible and visible.kind == "structure" then
    visualTile, visualClass = visible.visualTile, visible.visualClass
    visualTX, visualTY = visible.visualTX, visible.visualTY
  elseif groundHit and groundHit.entry then
    local e = groundHit.entry
    visualTX = math.floor((gx - e.ox) / 8)
    visualTY = math.floor((gz - e.oy) / 8)
    local S = voxelStructuresFor(scene, e)
    local k = voxelStructureKey(visualTX, visualTY)
    local shape = S and S.shapeAt and S.shapeAt[k] or nil
    visualTile = S and S.tileAt and S.tileAt[k] or nil
    visualClass = shape and shape.class or nil
  end
  -- Keep the last exact Voxel pick visible in DEBUG OVERLAY. VOXEL/RAY are
  -- counters, not tile ids; this line is the authoritative per-tap tile/class.
  -- Tile/class data is diagnostic only: v1.3.14 deliberately stopped using
  -- visual `void` classification as an EXIT-intent heuristic.
  state.lastVoxelPick = {
    tile = visualTile, class = visualClass,
    tx = visualTX, ty = visualTY,
    cellX = groundHit and groundHit.x or nil,
    cellY = groundHit and groundHit.y or nil,
  }

  local outsideBehind = false
  if visible and visible.entry and visible.entry.active and not groundHit then
    local active = entries and entries[1]
    local map = active and active.map
    local w = map and (map.widthCells or (map.def and map.def.width and map.def.width * 2))
    local h = map and (map.heightCells or (map.def and map.def.height and map.def.height * 2))
    if active and w and h then
      local x0, z0 = active.ox, active.oy
      local x1, z1 = x0 + w * TILE_SIZE, z0 + h * TILE_SIZE
      local dx = gx < x0 and (x0 - gx) or (gx > x1 and (gx - x1) or 0)
      local dz = gz < z0 and (z0 - gz) or (gz > z1 and (gz - z1) or 0)
      outsideBehind = math.max(dx, dz) >= TILE_SIZE * 0.5
    end
  end

  local hit=visible or groundHit
  if not hit then
    state.stats.voxelRayOutside=state.stats.voxelRayOutside+1
    return { error="outside_world", cur=cur, overview=overview, ray=true,
             intentX=intentX, intentY=intentY }
  end
  state.stats.voxelTargets=state.stats.voxelTargets+1
  state.stats.voxelRayTargets=state.stats.voxelRayTargets+1
  if visible then state.stats.voxelColumnTargets=state.stats.voxelColumnTargets+1 end
  if hit.entry.active then
    return { x=hit.x,y=hit.y,cur=cur,overview=overview,
             outsideBehind = outsideBehind,
             visibleKind = visible and visible.kind or nil,
             visualTile = visualTile, visualClass = visualClass,
             visualTX = visualTX, visualTY = visualTY,
             intentX=intentX, intentY=intentY }
  end
  local wx=hit.entry.ox+(hit.x+0.5)*TILE_SIZE
  local wy=hit.entry.oy+(hit.y+0.5)*TILE_SIZE
  local cross,saw=visibleNeighborTarget(game,wx,wy,overview)
  if cross then
    cross.targetX,cross.targetY=hit.x,hit.y
    return { x=hit.x,y=hit.y,cur=cur,overview=overview,cross=cross }
  end
  return { error=saw and "connected_map" or "outside_map",cur=cur,overview=overview,
           intentX=intentX, intentY=intentY }
end

-- Hit-test the actual ground quads the active Voxel provider's current camera projects.
-- Grid intersections are projected once and shared by adjacent cells. Raised
-- semantic surfaces (actors, counters, walls, warps) may occlude a farther
-- ground quad, matching the renderer's depth-buffered presentation.
local function voxelTargetFromTap(game, x, y, voxel3d)
  local free = overworldGate(game)
  if not free then return nil, nil, nil, nil, "busy" end
  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if not cur or not overview or cur.mapId ~= overview.mapId then
    return nil, nil, nil, nil, "no_map"
  end

  local px, py = framebufferPoint(x, y, voxel3d)
  local frame = state.frame or {}
  local dpiX, dpiY = tonumber(frame.dpiX) or 1, tonumber(frame.dpiY) or 1
  local snapRadius = VOXEL_COLUMN_SNAP_UNITS * math.max(1, (dpiX + dpiY) * 0.5)
  local snap2 = snapRadius * snapRadius
  local searchY = VOXEL_COLUMN_SEARCH_Y_UNITS * math.max(1, dpiY)

  local best, bestD2, bestDepth
  local columnCandidates = {}

  for _, entry in ipairs(voxelCandidateMaps(game, overview)) do
    local ov = entry.overview
    if ov and ov.width and ov.height then
      local points = {}
      for gy = 0, ov.height do
        local row = {}
        points[gy] = row
        for gx = 0, ov.width do
          row[gx] = projectedPoint(voxel3d,
            entry.ox + gx * TILE_SIZE,
            entry.oy + gy * TILE_SIZE)
        end
      end

      for cy = 0, ov.height - 1 do
        for cx = 0, ov.width - 1 do
          local a = points[cy][cx]
          local b = points[cy][cx + 1]
          local c = points[cy + 1][cx + 1]
          local d = points[cy + 1][cx]
          if a and b and c and d then
            local quad = { a, b, c, d }
            local mx = (a[1] + b[1] + c[1] + d[1]) * 0.25
            local my = (a[2] + b[2] + c[2] + d[2]) * 0.25
            local ddx, ddy = px - mx, py - my
            local d2 = ddx * ddx + ddy * ddy
            local depth = (tonumber(a[3]) or 0) + (tonumber(b[3]) or 0)
                        + (tonumber(c[3]) or 0) + (tonumber(d[3]) or 0)

            if pointInQuad(px, py, quad) then
              -- Exact projected top-down ground ownership always wins.
              if not best or d2 < bestD2
                  or (math.abs(d2 - bestD2) < 0.01 and depth > bestDepth) then
                best = { entry = entry, x = cx, y = cy, exact = true }
                bestD2, bestDepth = d2, depth
              end
            elseif math.abs(ddx) <= snapRadius * 2
                and math.abs(ddy) <= searchY then
              -- Voxel scenery is vertically extruded, while gameplay remains
              -- a 2D cell grid. Keep only screen-near semantic cells and, if
              -- no ground quad owns the tap, test the vertical screen segment
              -- rising from that cell. This makes NPC slabs, counters, doors,
              -- stairs and raised/tall scenery tappable without guessing at
              -- the renderer's private mesh topology or depth buffer.
              columnCandidates[#columnCandidates + 1] = {
                entry = entry, x = cx, y = cy,
                mx = mx, my = my, depth = depth, groundD2 = d2,
                strong = voxelStrongSemanticCell(game, entry, cx, cy),
              }
            end
          end
        end
      end
    end
  end

  if #columnCandidates > 0 then
    -- A depth-buffered 3D object can visually sit over a different cell's
    -- ground quad. Therefore exact ground ownership is not absolute: an
    -- actor/counter/wall/warp column may override it. Generic columns are
    -- considered only when no ground quad was hit, preventing invisible
    -- open-floor prisms from stealing ordinary walking taps.
    table.sort(columnCandidates, function(a, b)
      if a.strong ~= b.strong then return a.strong == true end
      return (a.groundD2 or math.huge) < (b.groundD2 or math.huge)
    end)
    local colBest, colD2, colDepth
    local limit = math.min(#columnCandidates, VOXEL_COLUMN_MAX_CANDIDATES)
    for i = 1, limit do
      local cand = columnCandidates[i]
      if not best or cand.strong then
        local wx = cand.entry.ox + (cand.x + 0.5) * TILE_SIZE
        local wy = cand.entry.oy + (cand.y + 0.5) * TILE_SIZE
        local mid = projectedPoint(voxel3d, wx, wy, VOXEL_COLUMN_MID_HEIGHT)
        local top = projectedPoint(voxel3d, wx, wy, VOXEL_COLUMN_HEIGHT)
        if mid and top then
          local d2a = pointSegmentDistance2(px, py,
            cand.mx, cand.my, mid[1], mid[2])
          local d2b = pointSegmentDistance2(px, py,
            mid[1], mid[2], top[1], top[2])
          local d2 = math.min(d2a, d2b)
          if d2 <= snap2 and (not colBest or d2 < colD2
              or (math.abs(d2 - colD2) < 0.01
                  and cand.depth > (colDepth or -math.huge))) then
            colBest, colD2, colDepth = cand, d2, cand.depth
          end
        end
      end
    end
    if colBest then
      local replacesGround = not best or colBest.strong
      if replacesGround then
        best = { entry = colBest.entry, x = colBest.x, y = colBest.y,
                 exact = false }
        state.stats.voxelColumnTargets = state.stats.voxelColumnTargets + 1
      end
    end
  end

  if not best then return nil, nil, cur, overview, "outside_world" end
  state.stats.voxelTargets = state.stats.voxelTargets + 1
  if best.entry.active then
    return best.x, best.y, cur, overview, nil, nil
  end

  -- Reuse the same direct-connection object the flat renderer path uses,
  -- feeding it the centre of the Voxel cell in the engine's common world
  -- coordinate space.
  local wx = best.entry.ox + (best.x + 0.5) * TILE_SIZE
  local wy = best.entry.oy + (best.y + 0.5) * TILE_SIZE
  local cross, saw = visibleNeighborTarget(game, wx, wy, overview)
  if cross then
    cross.targetX, cross.targetY = best.x, best.y
    return best.x, best.y, cur, overview, nil, cross
  end
  return nil, nil, cur, overview, saw and "connected_map" or "outside_map"
end

-- Gold draws TILT by warping the already-scaled window-sized ground plane
-- through Tilt.groundPoint(). The upstream helper is forward-only, but its
-- perspective equation has a closed-form inverse, so touch picking can use
-- the exact same presentation transform instead of guessing or disabling
-- Tap to Move whenever TILT is enabled.
function ControlsFree.goldWindowSize()
  local frame = state.frame or {}
  local w, h = tonumber(frame.ww), tonumber(frame.wh)
  if w and h and w > 0 and h > 0 then return w, h end
  if love and love.graphics and type(love.graphics.getDimensions) == "function" then
    local ok, ww, wh = pcall(love.graphics.getDimensions)
    if ok and tonumber(ww) and tonumber(wh) and ww > 0 and wh > 0 then
      return ww, wh
    end
  end
  return nil, nil
end

function ControlsFree.goldTiltState()
  local ok, Tilt = pcall(require, "src.render.Tilt")
  if not ok or type(Tilt) ~= "table" then return nil, false end
  local active = type(Tilt.active) == "function" and Tilt.active() == true
  return Tilt, active
end

function ControlsFree.goldTiltScreenToFlat(x, y, vw, vh)
  local Tilt, active = ControlsFree.goldTiltState()
  if not active then return x, y, false end
  local a = tonumber(Tilt.angle) or 0
  if a <= 0 then return x, y, false end
  vw, vh = tonumber(vw), tonumber(vh)
  if not (vw and vh and vw > 0 and vh > 0) then return nil, nil, true end

  -- Forward upstream equation:
  --   scale = d / (d - w*sin(a))
  --   sy-Cy = w*cos(a)*scale
  -- Solving the second line for w gives the exact inverse below.
  local d = (tonumber(Tilt.FOCAL) or 1) * vh
  local sinA, cosA = math.sin(a), math.cos(a)
  local screenY = y - vh * 0.5
  local denom = cosA * d + screenY * sinA
  if math.abs(denom) < 1e-7 then return nil, nil, true end
  local row = screenY * d / denom
  local scaleDenom = d - row * sinA
  if math.abs(scaleDenom) < 1e-7 then return nil, nil, true end
  local scale = d / scaleDenom
  if scale <= 0 or scale ~= scale then return nil, nil, true end
  local flatX = vw * 0.5 + (x - vw * 0.5) / scale
  local flatY = vh * 0.5 + row
  return flatX, flatY, true
end

function ControlsFree.goldTiltFlatToScreen(x, y, vw, vh)
  local Tilt, active = ControlsFree.goldTiltState()
  if not active then return x, y, false end
  if type(Tilt.groundPoint) ~= "function" then return nil, nil, true end
  local ok, sx, sy = pcall(Tilt.groundPoint, x, y, vw, vh)
  if not ok or type(sx) ~= "number" or type(sy) ~= "number"
      or sx ~= sx or sy ~= sy then
    return nil, nil, true
  end
  return sx, sy, true
end

-- Exact Gold frame transforms.  Prefer the geometry captured after the world
-- was rendered; fall back to the live helpers only during the first frame after
-- boot/resize where no render.compose snapshot exists yet.
function ControlsFree.goldFrameGeometry(game, expectedMapId)
  local frame = state.frame or {}
  local g = frame.gold
  if g and (expectedMapId == nil or g.mapId == expectedMapId)
      and tonumber(g.scale) and g.scale > 0 then
    return g
  end

  local world = game and game.world
  if not (world and world.camera and type(world.zoomScale) == "function") then
    return nil
  end
  local okScale, scale = pcall(world.zoomScale, world)
  scale = okScale and tonumber(scale) or nil
  local ww, wh = ControlsFree.goldWindowSize()
  if not (scale and scale > 0 and ww and wh) then return nil end
  local captureW, captureH, cropX, cropY = ww, wh, 0, 0
  local tiltAngle, tiltFocal, tiltActive = 0, 1, false
  local Tilt, active = ControlsFree.goldTiltState()
  if active and Tilt then
    tiltActive = true
    tiltAngle = tonumber(Tilt.angle) or 0
    tiltFocal = tonumber(Tilt.FOCAL) or 1
    if type(Tilt.viewGrowth) == "function" then
      local okGrowth, growth = pcall(Tilt.viewGrowth)
      growth = okGrowth and tonumber(growth) or nil
      if growth and growth > 0 then
        captureW, captureH = math.ceil(ww * growth), math.ceil(wh * growth)
        cropX, cropY = (ww - captureW) / 2, (wh - captureH) / 2
      end
    end
  end
  local cameraX, cameraY = tonumber(world.camera.x) or 0, tonumber(world.camera.y) or 0
  return {
    mapId = world.map and world.map.id or expectedMapId,
    scale = scale, cameraX = cameraX, cameraY = cameraY,
    originX = math.floor(-cameraX * scale),
    originY = math.floor(-cameraY * scale),
    windowW = ww, windowH = wh,
    captureW = captureW, captureH = captureH,
    cropX = cropX, cropY = cropY,
    tiltActive = tiltActive, tiltAngle = tiltAngle, tiltFocal = tiltFocal,
  }
end

function ControlsFree.goldFrameScreenToFlat(game, x, y, expectedMapId)
  local g = ControlsFree.goldFrameGeometry(game, expectedMapId)
  if not g then return nil, nil, nil end
  if not g.tiltActive or (g.tiltAngle or 0) <= 0 then return x, y, g end

  -- World:drawTilted draws the projected capture translated by cropX/cropY.
  -- Undo that crop before inverting Tilt.groundPoint in capture coordinates.
  local sx, sy = x - (g.cropX or 0), y - (g.cropY or 0)
  local vw, vh = tonumber(g.captureW), tonumber(g.captureH)
  if not (vw and vh and vw > 0 and vh > 0) then return nil, nil, g end
  local a, focal = tonumber(g.tiltAngle) or 0, tonumber(g.tiltFocal) or 1
  local d = focal * vh
  local sinA, cosA = math.sin(a), math.cos(a)
  local screenY = sy - vh * 0.5
  local denom = cosA * d + screenY * sinA
  if math.abs(denom) < 1e-7 then return nil, nil, g end
  local row = screenY * d / denom
  local scaleDenom = d - row * sinA
  if math.abs(scaleDenom) < 1e-7 then return nil, nil, g end
  local perspective = d / scaleDenom
  if perspective <= 0 or perspective ~= perspective then return nil, nil, g end
  local flatX = vw * 0.5 + (sx - vw * 0.5) / perspective
  local flatY = vh * 0.5 + row
  return flatX, flatY, g
end

function ControlsFree.goldFrameFlatToScreen(game, x, y, expectedMapId)
  local g = ControlsFree.goldFrameGeometry(game, expectedMapId)
  if not g then return nil, nil end
  if not g.tiltActive or (g.tiltAngle or 0) <= 0 then return x, y end
  local vw, vh = tonumber(g.captureW), tonumber(g.captureH)
  if not (vw and vh and vw > 0 and vh > 0) then return nil, nil end
  local a, focal = tonumber(g.tiltAngle) or 0, tonumber(g.tiltFocal) or 1
  local u, row = x - vw * 0.5, y - vh * 0.5
  local d = focal * vh
  local denom = d - row * math.sin(a)
  if math.abs(denom) < 1e-7 then return nil, nil end
  local perspective = d / denom
  if perspective <= 0 or perspective ~= perspective then return nil, nil end
  local sx = vw * 0.5 + u * perspective + (g.cropX or 0)
  local sy = vh * 0.5 + row * math.cos(a) * perspective + (g.cropY or 0)
  return sx, sy
end

-- Project the visual centre of one Gold collision cell back onto the window.
-- This is intentionally the exact reverse of targetFromTap's Gold transform
-- and is used only for diagnostics/preview alignment, never as movement data.
function ControlsFree.goldCellCenterToScreen(game, mapId, cellX, cellY)
  local g = ControlsFree.goldFrameGeometry(game, mapId)
  local scale = g and tonumber(g.scale) or nil
  if not (g and scale and scale > 0 and cellX ~= nil and cellY ~= nil) then
    return nil, nil
  end
  local originX = tonumber(g.originX)
    or math.floor(-(tonumber(g.cameraX) or 0) * scale)
  local originY = tonumber(g.originY)
    or math.floor(-(tonumber(g.cameraY) or 0) * scale)
  local flatX = originX + (tonumber(cellX) * TILE_SIZE + TILE_SIZE / 2) * scale
  local flatY = originY + (tonumber(cellY) * TILE_SIZE + TILE_SIZE / 2) * scale
  return ControlsFree.goldFrameFlatToScreen(game, flatX, flatY, mapId)
end

local function targetFromTap(game, x, y)
  local scene = voxelContext()
  if scene then
    local ray = voxelRayTargetFromTap(game, x, y, scene)
    if ray then
      -- A live NPC hit stays absolute. Otherwise fixed hidden-event fixtures
      -- get a direct semantic screen hit before ground/outside-map intent is
      -- interpreted. This is what makes a visible wall PC a real pathfinding
      -- target even when the 3D ground ray lands behind the room.
      if ray.visibleKind ~= "entity" and option("interact", true) ~= false then
        local hiddenHit = ControlsFree.voxelFixedHiddenInteractionFromTap(game, x, y, scene)
        if hiddenHit then
          state.stats.voxelNativeHiddenPathTargets =
            (state.stats.voxelNativeHiddenPathTargets or 0) + 1
          return hiddenHit.x, hiddenHit.y, hiddenHit.cur, hiddenHit.overview,
                 nil, nil, {
                   forcedInteraction = hiddenHit.interaction,
                   nativeHiddenPathTarget = true,
                   intentX = ray.intentX, intentY = ray.intentY,
                 }
        end
      end

      -- Raised wall-mounted interaction surfaces are the one place where a
      -- mathematically correct ground ray can still be semantically wrong.
      -- The Pokémon Center PC is the canonical example: its hidden-event cell
      -- sits on the far-right wall (x=13,y=3), so tapping the visible machine
      -- can put the ray's ground intersection behind the compact interior and
      -- report outside_map/outside_world. Before Smart Exit sees that result,
      -- reuse the older projected-column picker ONLY as a semantic rescue.
      -- It may replace the ray only when the recovered current-map cell is a
      -- real engine interaction (PC/sign/bookshelf/counter/NPC/etc.). Ordinary
      -- floor/wall cells can never win this fallback, so exit intent and normal
      -- movement keep the ray path as their authority.
      local rayInteraction = ray.x and ray.y
        and interactionAt(game, ray.x, ray.y) or nil
      local semanticRescueEligible = ray.error ~= nil
        or ray.outsideBehind == true
        or (ray.visibleKind == "structure" and rayInteraction == nil)
      if semanticRescueEligible then
        local sx, sy, scur, soverview, serr, scross =
          voxelTargetFromTap(game, x, y, scene.voxel3d)
        if sx and sy and not serr and not scross
            and interactionAt(game, sx, sy) ~= nil then
          state.stats.voxelSemanticRecoveries =
            (state.stats.voxelSemanticRecoveries or 0) + 1
          local meta = {
            semanticRecovery = true,
            intentX = ray.intentX, intentY = ray.intentY,
            rayError = ray.error,
            recoveredFromOutside = ray.error == "outside_world"
              or ray.error == "outside_map",
          }
          return sx, sy, scur, soverview, nil, nil, meta
        end
      end
      if ray.error then
        return nil, nil, ray.cur, ray.overview, ray.error, nil, ray
      end
      return ray.x, ray.y, ray.cur, ray.overview, nil, ray.cross, ray
    end
    -- Older Voxel provider builds (or the very first frame before a VP has
    -- been established) retain the projection-based compatibility path.
    -- Once a live VP exists, the ray path above is authoritative except for
    -- the explicit semantic rescue above.
    return voxelTargetFromTap(game, x, y, scene.voxel3d)
  end

  local free = overworldGate(game)
  if not free then return nil, nil, nil, nil, "busy" end

  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if WorldBackend.isGold(game) then
    local world = WorldBackend.owner(game)
    if not (world and world.camera and type(world.zoomScale) == "function"
        and cur and overview and cur.mapId == overview.mapId) then
      return nil, nil, cur, overview, "no_map"
    end
    -- Gold's world fills the window, but the exact render is not simply
    -- `camera + screen/zoom`: drawGround floors the map origin, and TILT first
    -- renders into a grown capture which is later cropped back to the window.
    -- Invert the frame snapshot captured by render.compose so flat and tilted
    -- targeting both resolve against the pixels the player actually saw.
    local pickX, pickY, goldFrame =
      ControlsFree.goldFrameScreenToFlat(game, x, y, overview.mapId)
    if not pickX or not goldFrame then
      return nil, nil, cur, overview, "no_view"
    end
    local scale = tonumber(goldFrame.scale)
    if not scale or scale <= 0 then
      return nil, nil, cur, overview, "no_view"
    end
    local originX = tonumber(goldFrame.originX)
      or math.floor(-(tonumber(goldFrame.cameraX) or 0) * scale)
    local originY = tonumber(goldFrame.originY)
      or math.floor(-(tonumber(goldFrame.cameraY) or 0) * scale)
    local worldX = (pickX - originX) / scale
    local worldY = (pickY - originY) / scale
    local tiltActive = goldFrame.tiltActive == true
    local meta = { intentX = worldX / TILE_SIZE, intentY = worldY / TILE_SIZE,
                   generation = 2, flatGold = not tiltActive,
                   tiltedGold = tiltActive and true or false,
                   exactGoldFrame = true }
    local tx, ty = math.floor(worldX / TILE_SIZE), math.floor(worldY / TILE_SIZE)
    if tx < 0 or ty < 0 or tx >= overview.width or ty >= overview.height then
      local cross, sawNeighbour = visibleNeighborTarget(game, worldX, worldY, overview)
      if cross then
        return cross.targetX, cross.targetY, cur, overview, nil, cross, meta
      end
      return nil, nil, cur, overview,
        sawNeighbour and "connected_map" or "outside_map", nil, meta
    end
    return tx, ty, cur, overview, nil, nil, meta
  end

  local view = state.view
  if not view then return nil, nil, nil, nil, "no_view" end
  if not cur or not overview or cur.mapId ~= overview.mapId then
    return nil, nil, nil, nil, "no_map"
  end

  local tapPX, tapPY = x * view.dpiX, y * view.dpiY
  local right = view.ox + view.worldW * view.scale
  local bottom = view.oy + view.worldH * view.scale
  local outsideCanvas = tapPX < view.ox or tapPY < view.oy
    or tapPX >= right or tapPY >= bottom

  -- Deliberately map even letterbox/outside-canvas clicks through the live
  -- camera.  Those extrapolated map-cell coordinates are not movement targets;
  -- they are only directional intent used to choose between multiple real
  -- exits in an enclosed interior.
  local canvasX = (tapPX - view.ox) / view.scale
  local canvasY = (tapPY - view.oy) / view.scale
  local ppx, ppy = playerPixel(game, cur)
  local ow = game and game.overworld
  -- Prefer the live camera when available: it is exactly what rendered the
  -- neighbour rectangles and also includes temporary camera pans.  The public
  -- player-follow formula remains a compatibility fallback.
  local cameraX = ow and ow.camera and tonumber(ow.camera.x)
    or (ppx - (view.worldW / 2 - 16))
  local cameraY = ow and ow.camera and tonumber(ow.camera.y)
    or (ppy - (view.worldH / 2 - 8))
  local worldX = cameraX + canvasX
  local worldY = cameraY + canvasY
  local intentMeta = { intentX = worldX / TILE_SIZE, intentY = worldY / TILE_SIZE }
  local tx = math.floor(worldX / TILE_SIZE)
  local ty = math.floor(worldY / TILE_SIZE)

  if outsideCanvas then
    return nil, nil, cur, overview, "outside_world", nil, intentMeta
  end

  if tx < 0 or ty < 0 or tx >= overview.width or ty >= overview.height then
    local cross, sawNeighbour = visibleNeighborTarget(game, worldX, worldY, overview)
    if cross then
      return cross.targetX, cross.targetY, cur, overview, nil, cross
    end
    -- Survey can show maps more than one connection away.  Recognize that the
    -- tap really hit rendered world, but refuse it until every intervening seam
    -- can be validated rather than treating it as an arbitrary border tap.
    return nil, nil, cur, overview, sawNeighbour and "connected_map" or "outside_map",
      nil, intentMeta
  end

  return tx, ty, cur, overview, nil, nil, intentMeta
end

local function newNavigation(cur)
  return {
    mapId = cur.mapId,
    targetX = nil,
    targetY = nil,
    path = nil,
    index = 1,
    blockedEdges = {},
    blockedCells = {},
    tempBlocked = {},
    lastX = cur.x,
    lastY = cur.y,
    lastProgressTick = state.tick,
    phase = "PLANNING",
    createdTick = state.tick,
  }
end

local function deferUntilCurrentStepLands(game, nav)
  local player = WorldBackend.player(game)
  if not player or player.moving ~= true then return false end
  if type(player.targetX) ~= "number" or type(player.targetY) ~= "number" then
    return false
  end
  nav.pendingStartX, nav.pendingStartY = player.targetX, player.targetY
  releaseHold(nav)
  setPhase(nav, "WAITING_PLAYER_STEP", "tap_during_existing_step")
  return true
end

-- When the pointer is intentionally aimed outside an enclosed map, interpret
-- that as "leave this area" instead of requiring the player to hit a tiny
-- doorway tile.  Public mapOverview warp markers are the primary source; the
-- '+' terrain scan is a compatibility fallback for stale/older overviews.
-- Only maps with no seamless map connections opt into this affordance: on an
-- outdoor/connected map, off-map taps remain ordinary invalid targets rather
-- than silently choosing an unrelated door/ladder warp.
local function listHas(list, value)
  for _, v in ipairs(list or {}) do
    if v == value then return true end
  end
  return false
end

-- Convert an off-map pointer position into the side(s) of the CURRENT map the
-- user is actually aiming through. Smart Exit is intentionally conservative:
-- a click above a room may only select an UP exit, a click to the right only a
-- RIGHT exit, etc. Diagonal outside space may name two sides; the larger
-- overflow is ordered first so a corner click still has a deterministic
-- preference without ever falling back to the opposite side of the room.
--
-- Returning an empty list is meaningful: the pointer may be outside the
-- framebuffer/3D ground ray while its extrapolated map intent is not actually
-- beyond a map edge. In that case there is NO safe automatic exit direction.
function ControlsFree.outsideIntentDirections(overview, intentX, intentY)
  if not overview or type(intentX) ~= "number" or type(intentY) ~= "number"
      or type(overview.width) ~= "number" or type(overview.height) ~= "number" then
    return {}
  end

  local scored = {}
  local function add(dir, amount)
    scored[#scored + 1] = { dir = dir, amount = math.max(0, amount or 0) }
  end
  if intentY < 0 then add("up", -intentY) end
  if intentY >= overview.height then
    add("down", intentY - overview.height + 0.000001)
  end
  if intentX < 0 then add("left", -intentX) end
  if intentX >= overview.width then
    add("right", intentX - overview.width + 0.000001)
  end

  table.sort(scored, function(a, b)
    if math.abs(a.amount - b.amount) > 0.000001 then return a.amount > b.amount end
    local order = { up = 1, down = 2, left = 3, right = 4 }
    return (order[a.dir] or 9) < (order[b.dir] or 9)
  end)
  local out = {}
  for _, row in ipairs(scored) do out[#out + 1] = row.dir end
  return out
end

function ControlsFree.firstMatchingDirection(available, wanted)
  for _, dir in ipairs(wanted or {}) do
    if listHas(available, dir) then return dir end
  end
  return nil
end

-- Resolve every direction that can activate a real warp SOURCE.
-- IMPORTANT: Gen1Recomp has TWO independent directional mechanisms:
--   1) Warp.onEdge: standing on a warp record at the map boundary and trying
--      to step OUT OF BOUNDS. This does NOT consult warpCarpets at all.
--   2) Warp.onCollision / ExtraWarpCheck: carpet/front-tile rules.
--
-- Older Tap to Move builds treated those as mutually exclusive. On a tileset
-- that uses function2 carpet rules, a genuine top-edge warp such as
-- CERULEAN_TRASHED_HOUSE (3,0) could therefore lose its required UP even
-- though Warp.onEdge would accept it. Return the UNION instead: edge direction
-- is always authoritative, with any valid carpet directions added afterwards.
function ControlsFree.engineWarpExtraCheck(game, map, x, y, dir)
  -- Gold has its own COLL_* warp vocabulary. Never route it through a Gen I
  -- warp-carpet mirror.
  if WorldBackend.isGold(game) then return nil end
  if not map then return nil end

  -- Exact local mirror of current Gen1Recomp Warp.extraCheck. Keeping the
  -- already-proven rules here avoids a Gen1-only src.world.Warp require in a
  -- package that is being audited for Gold, while preserving the baseline
  -- decision for every edge/carpet source.
  local facingEdge =
    (dir == "up" and y == 0)
    or (dir == "down" and y == map.heightCells - 1)
    or (dir == "left" and x == 0)
    or (dir == "right" and x == map.widthCells - 1)
  local carpets = game and game.data and game.data.field
      and game.data.field.warpCarpets
  if not carpets then return facingEdge end

  local useCarpet
  if listHas(carpets.edgeMaps, map.id) then
    useCarpet = false
  elseif listHas(carpets.function2Maps, map.id) then
    useCarpet = true
  else
    useCarpet = listHas(carpets.function2Tilesets, map.def and map.def.tileset)
  end
  if not useCarpet then return facingEdge end

  local d = DIR_BY_NAME[dir]
  if not d or type(map.cellTile) ~= "function" then return false end
  local okFront, front = pcall(map.cellTile, map, x + d.dx, y + d.dy)
  if not okFront then return false end
  local ss = carpets.ssAnneBow
  if ss and map.id == ss.map then return front == ss.tile end
  return listHas(carpets.tiles and carpets.tiles[dir], front)
end

local function warpActivationDirections(game, map, x, y)
  if not map then return {} end

  if WorldBackend.isGold(game) then
    local Permissions = WorldBackend.gold.permissionsModule()
    if not (Permissions and type(map.cellCollision) == "function") then
      return {}
    end
    local ok, coll = pcall(map.cellCollision, map, x, y)
    if not ok then return {} end
    local dir = Permissions.carpetDirection
        and Permissions.carpetDirection(coll) or nil
    -- Immediate Gold warps fire on landing. Directional carpets alone require
    -- an extra held direction while standing on the source cell.
    return dir and { dir } or {}
  end

  local dirs, seen = {}, {}

  local function add(dir)
    if not seen[dir] then
      seen[dir] = true
      dirs[#dirs + 1] = dir
    end
  end

  -- Prefer the live engine's ExtraWarpCheck when exposed. If this host does
  -- not provide src.world.Warp, retain the proven pre-v1.4.10 mirror below.
  local engineAvailable = ControlsFree.engineWarpExtraCheck(
    game, map, x, y, "up") ~= nil
  if engineAvailable then
    for _, d in ipairs(DIRS) do
      if ControlsFree.engineWarpExtraCheck(game, map, x, y, d.name) then
        add(d.name)
      end
    end
    -- Warp.onEdge is independent of ExtraWarpCheck.
    if y == 0 then add("up") end
    if map.heightCells and y == map.heightCells - 1 then add("down") end
    if x == 0 then add("left") end
    if map.widthCells and x == map.widthCells - 1 then add("right") end
    return dirs
  end

  local carpets = game and game.data and game.data.field
      and game.data.field.warpCarpets
  local useCarpet = false
  if carpets then
    if listHas(carpets.edgeMaps, map.id) then
      useCarpet = false
    elseif listHas(carpets.function2Maps, map.id) then
      useCarpet = true
    else
      useCarpet = listHas(carpets.function2Tilesets,
                          map.def and map.def.tileset)
    end
  end

  if y == 0 then add("up") end
  if map.heightCells and y == map.heightCells - 1 then add("down") end
  if x == 0 then add("left") end
  if map.widthCells and x == map.widthCells - 1 then add("right") end

  if useCarpet then
    for _, d in ipairs(DIRS) do
      local dir = d.name
      local tx, ty = x + d.dx, y + d.dy
      local front
      if type(map.cellTile) == "function" then
        local worked, value = pcall(map.cellTile, map, tx, ty)
        if worked then front = value end
      end
      local ss = carpets and carpets.ssAnneBow
      local ok
      if ss and map.id == ss.map then
        ok = front == ss.tile
      else
        ok = listHas(carpets and carpets.tiles and carpets.tiles[dir], front)
      end
      if ok then add(dir) end
    end
  end
  return dirs
end

local function defLooksOutdoor(game, def)
  if type(def) ~= "table" then return false end
  return WorldBackend.defLooksOutdoor(game, def)
end

local function warpExitRank(game, warpDef)
  if not warpDef then return 2 end
  if warpDef.destMap == "LAST_MAP" then return 0 end
  local maps = WorldBackend.mapDefinitions(game)
  local dest = maps and maps[warpDef.destMap]
  if dest and defLooksOutdoor(game, dest) then return 0 end
  return 1
end

-- Cheap map-graph distance to the outside. This is deliberately topological:
-- the CURRENT map leg still uses real A* walking cost, while unloaded floors
-- contribute only the number of transitions required to reach LAST_MAP or an
-- outdoor map. That is enough to choose the correct staircase/door through a
-- multi-floor interior without loading or pathfinding every remote floor.
local function mapExitHopDistance(game, startMapId)
  if not startMapId or startMapId == "LAST_MAP" then return 0 end
  local maps = WorldBackend.mapDefinitions(game)
  local start = maps and maps[startMapId]
  if not start then return nil end
  if defLooksOutdoor(game, start) then return 0 end

  local queue = { { id = startMapId, d = 0 } }
  local head, seen = 1, { [startMapId] = true }
  while head <= #queue do
    local node = queue[head]; head = head + 1
    if node.d < 24 then
      local def = maps[node.id]
      if def then
        local nextIds = {}
        local runtimeMap = WorldBackend.isGold(game)
          and WorldBackend.gold.neighborMap(game, node.id) or nil
        for _, w in ipairs(def.warps or {}) do
          local usable = true
          if WorldBackend.isGold(game) then
            usable = runtimeMap ~= nil
              and WorldBackend.gold.warpFiresAt(game, runtimeMap, w.x, w.y)
          end
          if usable then
            local dest = w.destMap
            if dest == "LAST_MAP" then return node.d + 1 end
            if type(dest) == "string" and dest ~= "" then nextIds[#nextIds+1] = dest end
          end
        end
        for _, conn in pairs(def.connections or {}) do
          local dest = conn and (conn.map or conn.mapId)
          if type(dest) == "string" and dest ~= "" then nextIds[#nextIds+1] = dest end
        end
        for _, dest in ipairs(nextIds) do
          local ddef = maps[dest]
          if ddef and defLooksOutdoor(game, ddef) then return node.d + 1 end
          if ddef and not seen[dest] then
            seen[dest] = true
            queue[#queue+1] = { id = dest, d = node.d + 1 }
          end
        end
      end
    end
  end
  return nil
end

local function warpExitHops(game, warpDef)
  if not warpDef then return nil end
  local dest = warpDef.destMap
  if dest == "LAST_MAP" then return 1 end
  local maps = WorldBackend.mapDefinitions(game)
  local ddef = maps and maps[dest]
  if ddef and defLooksOutdoor(game, ddef) then return 1 end
  local tail = mapExitHopDistance(game, dest)
  return tail and (tail + 1) or nil
end

local function mapTransitionExitHops(game, destMapId)
  local maps = WorldBackend.mapDefinitions(game)
  local ddef = maps and maps[destMapId]
  if ddef and defLooksOutdoor(game, ddef) then return 1 end
  local tail = mapExitHopDistance(game, destMapId)
  return tail and (tail + 1) or nil
end

local function actualWarpCells(map)
  if not map then return {} end
  local defs = map.warps or (map.def and map.def.warps) or nil
  local cache = ControlsFree.warpCellsCache[map]
  if cache and cache.defs == defs and cache.count == #(defs or {}) then
    state.stats.warpCacheHits = (state.stats.warpCacheHits or 0) + 1
    return cache.cells
  end

  local out, seen = {}, {}
  for i, w in ipairs(defs or {}) do
    local x, y = tonumber(w.x), tonumber(w.y)
    if x and y then
      x, y = math.floor(x), math.floor(y)
      local k = key(x, y)
      if not seen[k] then
        seen[k] = true
        out[#out + 1] = { x=x, y=y, def=(w.def or w), index=i }
      end
    end
  end
  ControlsFree.warpCellsCache[map] = {
    defs = defs, count = #(defs or {}), cells = out,
  }
  state.stats.warpCacheMisses = (state.stats.warpCacheMisses or 0) + 1
  return out
end

local function warpIntentAt(game, map, cur, x, y)
  for _, w in ipairs(actualWarpCells(map)) do
    if w.x == x and w.y == y then
      if WorldBackend.isGold(game)
          and not WorldBackend.gold.warpFiresAt(game, map, x, y) then
        -- Gold extraction also carries arrival-only warp coordinates sitting
        -- on ordinary floor. They are destinations, not exits.
        goto continue_warp_intent
      end
      local dirs = warpActivationDirections(game, map, x, y)
      -- A directional ExtraWarpCheck source needs one final D-pad press after
      -- Tap to Move reaches the warp record.  v1.3.11 originally kept this
      -- safety step unconditionally only for DOWN carpets; that accidentally
      -- dropped UP/LEFT/RIGHT when the source collision tile ALSO looked like
      -- a normal arrival warp.  If the engine exposes exactly one activation
      -- direction, preserve it regardless of warpTile: a true arrival warp
      -- changes maps before the follow-up can fire, while a directional source
      -- receives exactly the missing press.  Ambiguous multi-direction sources
      -- still do not get guessed (except the legacy DOWN carpet preference).
      local exitDir = (#dirs == 1) and dirs[1] or nil
      if not exitDir and listHas(dirs, "down") then exitDir = "down" end
      if not exitDir and cur and cur.x == x and cur.y == y then
        exitDir = dirs[1]
      end
      local edgeWarp = exitDir ~= nil and (
        (exitDir == "up" and y == 0)
        or (exitDir == "down" and map.heightCells and y == map.heightCells - 1)
        or (exitDir == "left" and x == 0)
        or (exitDir == "right" and map.widthCells and x == map.widthCells - 1))
      return {
        kind = "warp", x=x, y=y, def=w.def, warpDef=w.def,
        rank = warpExitRank(game, w.def), exitDir=exitDir,
        carpetDown = exitDir == "down", edgeWarp = edgeWarp,
      }
    end
    ::continue_warp_intent::
  end
  return nil
end

-- Deterministic rescue for directional Gen I warp openings.  ExtraWarpCheck
-- is not a DOWN-only carpet mechanic: a warp SOURCE may require UP/DOWN/LEFT/
-- RIGHT toward a special tile in FRONT of the player.  The visible opening
-- the user taps can therefore be one gameplay cell away from the actual warp
-- record.  Resolve all four directions through the same engine-mirrored
-- warpActivationDirections() rules instead of guessing a graphic tile id.
--
-- Return the real warp SOURCE plus the direction that must be pressed after
-- reaching it.  A normal arrival warp still works unchanged: the map changes
-- before the follow-up direction can fire.
function ControlsFree.directionalWarpIntentAt(game, map, cur, x, y)
  if not map or type(x) ~= "number" or type(y) ~= "number" then return nil end

  local direct = warpIntentAt(game, map, cur, x, y)
  if direct and direct.exitDir then
    direct.clickedDirectionalX, direct.clickedDirectionalY = x, y
    direct.directionalFrontCell = false
    if direct.exitDir == "down" then direct.carpetDown = true end
    return direct
  end

  local warps = actualWarpCells(map)
  for _, d in ipairs(DIRS) do
    -- If moving d from SOURCE reaches the clicked visible opening, SOURCE is
    -- one cell opposite that direction.
    local sx, sy = x - d.dx, y - d.dy
    for _, w in ipairs(warps) do
      if w.x == sx and w.y == sy then
        local dirs = warpActivationDirections(game, map, sx, sy)
        if listHas(dirs, d.name) then
          return {
            kind = "warp", x = sx, y = sy, def = w.def, warpDef = w.def,
            rank = warpExitRank(game, w.def), exitDir = d.name,
            carpetDown = d.name == "down", edgeWarp = false,
            clickedDirectionalX = x, clickedDirectionalY = y,
            directionalFrontCell = true,
          }
        end
      end
    end
  end
  return nil
end


-- Gold door/stair targeting assist.  The activation cell is the authoritative
-- target, but the visible doorway artwork often extends one 16px cell ABOVE
-- that source.  A raw tap on that graphic used to select the wall cell and then
-- either fail or route beside the building.  Snap only to a REAL Gold warp
-- record whose native COLL_* semantics actually fire; arrival-only warp rows
-- and ordinary floor can never become magnets.
function ControlsFree.goldDoorMagnet(game, map, cur, overview, tx, ty, meta)
  if not WorldBackend.isGold(game) or not map or not overview
      or type(tx) ~= "number" or type(ty) ~= "number" then return nil end
  if warpIntentAt(game, map, cur, tx, ty) then return nil end
  if interactionAt(game, tx, ty) ~= nil then return nil end
  if hiddenTreasureInteractionAt(game, cur and cur.mapId, tx, ty) ~= nil then return nil end
  if ControlsFree.cutInteractionAt(game, map, overview, tx, ty) ~= nil then return nil end

  local intentX = meta and tonumber(meta.intentX) or (tx + 0.5)
  local intentY = meta and tonumber(meta.intentY) or (ty + 0.5)
  local clickedChar = cellChar(overview, tx, ty)
  local clickedSolid = clickedChar ~= "." and clickedChar ~= "~" and clickedChar ~= "+"
  local best, bestScore
  for _, w in ipairs(actualWarpCells(map)) do
    if WorldBackend.gold.warpFiresAt(game, map, w.x, w.y) then
      local cx, cy = w.x + 0.5, w.y + 0.5
      local dx, dy = intentX - cx, intentY - cy
      local score = dx * dx + dy * dy
      local accept = score <= (0.72 * 0.72)
      local visualDoor = clickedSolid and tx == w.x and ty == w.y - 1
          and math.abs(intentX - cx) <= 0.72
          and intentY >= (w.y - 1.0) and intentY <= (w.y + 0.15)
      if visualDoor then
        -- Prefer the visually aligned source over a merely nearby stair/warp.
        score = score * 0.35
        accept = true
      end
      if accept and (not bestScore or score < bestScore) then
        bestScore = score
        best = warpIntentAt(game, map, cur, w.x, w.y)
      end
    end
  end
  if best then
    best.doorMagnet = true
    best.clickedX, best.clickedY = tx, ty
  end
  return best
end


-- Gold smart-door barrier inference.  A user can deliberately tap well past a
-- building/facade instead of on the tiny door sprite itself.  Do NOT solve
-- that by making the door magnet huge: that would let unrelated doors steal
-- ordinary floor taps.  Instead prove a semantic barrier first.
--
-- 1) The requested point must already be non-walkable / outside the local
--    graph, or a nominally walkable local point must have no static A* path.
-- 2) March the user's intent ray from the player and find its FIRST static
--    solid cell.
-- 3) Flood only that connected solid component (the facade/building/fence).
-- 4) A real active Gold warp may win only if it borders THAT component, lies
--    ahead of the player near the intent ray, and is itself reachable through
--    the normal movement graph.
--
-- This is deliberately a "door through the barrier I am aiming past" rule,
-- not "nearest door in roughly that direction".  It therefore handles a tap
-- high above a building while refusing to pull a click across an unrelated
-- wall toward some other entrance elsewhere on the map.
function ControlsFree.goldBarrierDoorIntent(game, map, cur, overview,
    intentX, intentY, tx, ty, targetErr, cross)
  if not WorldBackend.isGold(game) or not map or not cur or not overview then
    return nil
  end
  if cross then return nil end -- a validated connected-map target is stronger
  intentX, intentY = tonumber(intentX), tonumber(intentY)
  if not intentX or not intentY then
    if type(tx) ~= "number" or type(ty) ~= "number" then return nil end
    intentX, intentY = tx + 0.5, ty + 0.5
  end

  -- Never steal an explicit semantic target.
  if type(tx) == "number" and type(ty) == "number" then
    if warpIntentAt(game, map, cur, tx, ty) then return nil end
    if interactionAt(game, tx, ty) ~= nil then return nil end
    if hiddenTreasureInteractionAt(game, cur.mapId, tx, ty) ~= nil then return nil end
    if ControlsFree.cutInteractionAt(game, map, overview, tx, ty) ~= nil then return nil end
  end

  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local topology = ledgeTopology(game, map, overview)
  local _, _, staticOccupied = liveOccupancy(game)

  -- The rule is a fallback, not a shortcut through an otherwise valid route.
  local eligible = false
  if targetErr == "outside_world" or targetErr == "outside_map"
      or targetErr == "connected_map" then
    eligible = true
  elseif targetErr ~= nil then
    return nil
  elseif type(tx) == "number" and type(ty) == "number" then
    local ch = cellChar(overview, tx, ty)
    local legal = ch == "." or (ch == "~" and waterMode)
    if not legal then
      eligible = true
    else
      local direct = findPath(overview, cur.x, cur.y, tx, ty, waterMode,
        staticOccupied, nil, topology.blockedEdges, nil, topology.jumps)
      if direct then return nil end
      eligible = true
    end
  end
  if not eligible then return nil end

  local activeWarps, activeByKey = {}, {}
  for _, w in ipairs(actualWarpCells(map)) do
    if WorldBackend.gold.warpFiresAt(game, map, w.x, w.y) then
      activeWarps[#activeWarps + 1] = w
      activeByKey[key(w.x, w.y)] = w
    end
  end
  if #activeWarps == 0 then return nil end

  local function legalCell(cx, cy)
    local ch = cellChar(overview, cx, cy)
    return ch == "." or (ch == "~" and waterMode)
  end
  local function staticSolid(cx, cy)
    if cx < 0 or cy < 0 or cx >= overview.width or cy >= overview.height then
      return false
    end
    if activeByKey[key(cx, cy)] then return false end
    return not legalCell(cx, cy)
  end

  -- Intent ownership is TAP-centric, not PLAYER-centric.  The old algorithm
  -- marched from the player and committed to the first facade on that ray.
  -- That made a nearby building steal a slightly skewed click intended for a
  -- farther building.  Instead find the solid surface/component whose geometry
  -- is closest to the actual tap.  If that component has no door, do not jump
  -- to an unrelated building merely because it has a reachable entrance.
  local function pointToCellDistanceSq(wx, wy, cx, cy)
    local dx, dy = 0, 0
    if wx < cx then dx = cx - wx
    elseif wx > cx + 1 then dx = wx - (cx + 1) end
    if wy < cy then dy = cy - wy
    elseif wy > cy + 1 then dy = wy - (cy + 1) end
    return dx * dx + dy * dy
  end

  local seedX, seedY, seedDist
  -- An explicit solid clicked cell is the strongest possible component seed.
  if type(tx) == "number" and type(ty) == "number" and staticSolid(tx, ty) then
    seedX, seedY, seedDist = tx, ty, 0
  else
    -- Only runs on semantic fallback/no-route taps, never on the normal hot
    -- movement path.  A full map scan is deterministic and cheap enough here,
    -- and importantly works even when the tap lies outside the current map.
    for cy = 0, overview.height - 1 do
      for cx = 0, overview.width - 1 do
        if staticSolid(cx, cy) then
          local dist = pointToCellDistanceSq(intentX, intentY, cx, cy)
          if seedDist == nil or dist < seedDist then
            seedX, seedY, seedDist = cx, cy, dist
          end
        end
      end
    end
  end
  if seedX == nil then return nil end

  -- Do not reinterpret a genuine local interaction/CUT surface as a building
  -- just because the nearest geometric component also has a door somewhere.
  if interactionAt(game, seedX, seedY) ~= nil
      or ControlsFree.cutInteractionAt(game, map, overview, seedX, seedY) ~= nil then
    return nil
  end

  -- Flood exactly the tap-nearest obstacle component.  This is what gives the
  -- click ownership to the intended building rather than the building nearest
  -- to the player.
  local component = {}
  local queue = { { seedX, seedY } }
  local head, componentSize = 1, 0
  component[key(seedX, seedY)] = true
  local COMPONENT_LIMIT = 320
  while head <= #queue and componentSize < COMPONENT_LIMIT do
    local node = queue[head]; head = head + 1
    componentSize = componentSize + 1
    for _, d in ipairs(DIRS) do
      local nx, ny = node[1] + d.dx, node[2] + d.dy
      local nk = key(nx, ny)
      if not component[nk] and staticSolid(nx, ny) then
        component[nk] = true
        queue[#queue + 1] = { nx, ny }
      end
    end
  end

  local function componentDistance(wx, wy)
    local best = nil
    for dy = -2, 2 do
      for dx = -2, 2 do
        local md = math.abs(dx) + math.abs(dy)
        if md <= 2 and component[key(wx + dx, wy + dy)] then
          if not best or md < best then best = md end
        end
      end
    end
    return best
  end

  local px, py = cur.x + 0.5, cur.y + 0.5
  local ivx, ivy = intentX - px, intentY - py
  local best, bestTapDist, bestCompDist, bestPathCost
  for _, w in ipairs(activeWarps) do
    local compDist = componentDistance(w.x, w.y)
    if compDist ~= nil then
      local cx, cy = w.x + 0.5, w.y + 0.5
      -- Keep obviously backwards entrances from stealing a forward intent, but
      -- do not use player distance as a score.  Zero/near-zero intent vectors
      -- simply skip this half-plane guard.
      local rpx, rpy = cx - px, cy - py
      local forward = ivx * ivx + ivy * ivy < 0.25
        or (rpx * ivx + rpy * ivy) > -0.10
      if forward then
        local wk = key(w.x, w.y)
        local blocked = {}
        for other in pairs(activeByKey) do
          if other ~= wk then blocked[other] = true end
        end
        local dirs = warpActivationDirections(game, map, w.x, w.y)
        local path = findPath(overview, cur.x, cur.y, w.x, w.y, waterMode,
          staticOccupied, nil, topology.blockedEdges, blocked, topology.jumps,
          #dirs > 0)
        if path then
          local dx, dy = cx - intentX, cy - intentY
          local tapDist = dx * dx + dy * dy
          local pathCost = #path
          -- Strict lexicographic priority:
          --   1. closest door to the CLICK,
          --   2. tightest attachment to that component,
          --   3. only then the player's route cost as a tie-breaker.
          -- This guarantees that a closer player-side shop cannot beat the
          -- building the pointer is actually nearest to.
          local better = bestTapDist == nil or tapDist < bestTapDist - 1e-9
          if not better and bestTapDist ~= nil
              and math.abs(tapDist - bestTapDist) <= 1e-9 then
            better = bestCompDist == nil or compDist < bestCompDist
            if not better and bestCompDist == compDist then
              better = bestPathCost == nil or pathCost < bestPathCost
            end
          end
          if better then
            local intent = warpIntentAt(game, map, cur, w.x, w.y)
            if intent then
              intent.barrierDoor = true
              intent.barrierDirectRay = false
              intent.barrierX, intent.barrierY = seedX, seedY
              intent.barrierComponentSize = componentSize
              intent.barrierComponentDistance = compDist
              intent.barrierPathCost = pathCost
              intent.barrierTapDistance = math.sqrt(tapDist)
              intent.barrierSeedDistance = math.sqrt(seedDist or 0)
              best, bestTapDist = intent, tapDist
              bestCompDist, bestPathCost = compDist, pathCost
            end
          end
        end
      end
    end
  end
  return best
end

-- Scripted dungeon holes are a different transition class: they can be
-- ordinary walkable collision cells with NO map warp record at all; the map's
-- onStep script performs the transition after Red actually steps onto them
-- (Victory Road / Seafoam / Pokémon Mansion-style dungeon warps).  When a
-- Voxel structure hit lands on the solid cell immediately beside one of these
-- holes, snap only if that solid tap has exactly one adjacent, genuinely
-- walkable engine hole.  Ordinary floor taps are never redirected.
function ControlsFree.holeStepIntentAt(map, overview, x, y)
  if not map or type(x) ~= "number" or type(y) ~= "number" then return nil end
  if type(map.warpPadOrHoleAt) ~= "function"
      or type(map.isWalkableCell) ~= "function" then return nil end

  local function isHole(cx, cy)
    if type(map.inBounds) == "function" and not map:inBounds(cx, cy) then return false end
    local okKind, kind = pcall(map.warpPadOrHoleAt, map, cx, cy)
    if not okKind or kind ~= "hole" then return false end
    local okWalk, walk = pcall(map.isWalkableCell, map, cx, cy)
    return okWalk and walk == true
  end

  if isHole(x, y) then return { kind = "hole", x = x, y = y, proxied = false } end

  -- Never steal a legitimate floor/water/warp selection merely because a
  -- hole happens to be next to it.  The proxy is only for a non-movement
  -- visual/solid hit, which is exactly the Voxel occlusion failure mode.
  local ch = cellChar(overview, x, y)
  if ch == "." or ch == "~" or ch == "+" then return nil end

  local found = nil
  for _, d in ipairs(DIRS) do
    local hx, hy = x + d.dx, y + d.dy
    if isHole(hx, hy) then
      if found then return nil end -- ambiguous: do not guess between holes
      found = { kind = "hole", x = hx, y = hy, proxied = true,
                clickedX = x, clickedY = y }
    end
  end
  return found
end

-- Backward-compatible export name for external diagnostics that may have used
-- the v1.3.11 helper.  Its behavior is now the safer all-direction resolver.
ControlsFree.carpetDownIntentAt = ControlsFree.directionalWarpIntentAt

local function directConnectionExitIntents(game, overview, cur)
  local current = WorldBackend.map(game)
  local out = {}
  if not current or not current.def or not current.def.connections then
    return out
  end

  local all, dynamic, static = liveOccupancy(game)
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local sourceTopology = ledgeTopology(game, current, overview)
  local warpKeys = {}
  for _, w in ipairs(actualWarpCells(current)) do
    if not WorldBackend.isGold(game)
        or WorldBackend.gold.warpFiresAt(game, current, w.x, w.y) then
      warpKeys[key(w.x,w.y)] = true
    end
  end

  local function scanConnection(compass, conn, occupancy, dynamicOnly)
    local destMap, nb = loadedNeighborMap(game, conn.map or conn.mapId)
    local destOverview = overviewFromLoadedMap(destMap)
    local dir = COMPASS_TO_DIR[compass]
    if not destMap or not destOverview or not dir then return false end

    local crossBase = {
      sourceMapId = overview.mapId, destMapId = destMap.id,
      dir = dir, compass = compass, conn = conn,
      destOverview = destOverview, destMap = destMap,
      renderOx = nb and nb.ox, renderOy = nb and nb.oy,
    }

    local best = nil
    local function consider(sourceX, sourceY, entryX, entryY, cost, ledge)
      local lch = cellChar(destOverview, entryX, entryY)
      if lch ~= "." and not (lch == "~" and waterMode) then return end
      local path = findPath(overview, cur.x, cur.y, sourceX, sourceY, waterMode,
        occupancy, nil, sourceTopology.blockedEdges, nil, sourceTopology.jumps)
      if not path then return end
      local score = #path + (cost or 1)
      if not best or score < best.cost then
        local cross = copyFlat(crossBase)
        cross.targetX, cross.targetY = entryX, entryY
        if ledge then
          cross.exitLedge = true
          cross.exitLedgeMidX, cross.exitLedgeMidY = ledge.midX, ledge.midY
        end
        best = {
          kind = "connection", cross = cross,
          x = entryX, y = entryY, cost = score, rank = 0,
          exitHops = mapTransitionExitHops(game, cross.destMapId),
          dynamic = dynamicOnly,
        }
      end
    end

    -- Ordinary seamless seam: path to one source-edge cell, then one D-pad
    -- step out.  Skip any source cell that is itself an actual warp record,
    -- including plain-floor carpets not visible as '+' in mapOverview.
    for _, src in ipairs(
        ControlsFree.budgetedSeamSourceCells(crossBase, overview, cur)) do
      local sch = cellChar(overview, src.x, src.y)
      if sch and sch ~= "+" and not warpKeys[key(src.x,src.y)] then
        local lx, ly = seamLanding(crossBase, src.x, src.y)
        consider(src.x, src.y, lx, ly, 1)
      end
    end

    -- A ledge may consume the boundary tile as the midpoint and land in the
    -- neighbour on its second forced cell.  Treat it as another exit seam.
    for _, jump in ipairs(sourceTopology.seamJumps or {}) do
      if jump.dir == dir and not warpKeys[key(jump.sourceX,jump.sourceY)] then
        local lx, ly = seamLanding(crossBase, jump.midX, jump.midY)
        consider(jump.sourceX, jump.sourceY, lx, ly, jump.cost or 2, jump)
      end
    end

    if best then
      out[#out + 1] = best
      return true
    end
    return false
  end

  for _, compass in ipairs({ "north", "south", "west", "east" }) do
    local conn = current.def.connections[compass]
    if conn and conn.map then
      local immediate = scanConnection(compass, conn, all, false)
      if not immediate then
        scanConnection(compass, conn, static, true)
      end
    end
  end
  return out
end

-- When the pointer is aimed at space that belongs to neither the current map
-- nor a routable rendered neighbour, interpret it as "leave this area". This
-- deliberately uses ACTUAL warp records (map.def.warps), not only the visual
-- '+' cells from mapOverview: Gen I interior exit carpets are warp records on
-- ordinary-looking floor cells and only fire when the player then walks off
-- the edge / into the carpet direction.
function ControlsFree.crossTargetCandidateLimit()
  local profile = ControlsFree.pathBudgetProfile()
  return profile and tonumber(profile.crossTargets) or nil
end

function ControlsFree.smartExitCandidateLimit()
  local profile = ControlsFree.pathBudgetProfile()
  return profile and tonumber(profile.exits) or nil
end

function ControlsFree.rankSmartExitWarpsCheap(game, map, warps, cur,
    directionalGate, wantedExitDirs, intentX, intentY)
  local ranked = {}
  for _, dst in ipairs(warps or {}) do
    local dirs = preDirs or warpActivationDirections(game, map, dst.x, dst.y)
    local directedExit = directionalGate
      and ControlsFree.firstMatchingDirection(dirs, wantedExitDirs) or nil
    if not directionalGate or directedExit then
      local clickDistance = 0
      if type(intentX) == "number" and type(intentY) == "number" then
        local dx, dy = (dst.x + 0.5) - intentX, (dst.y + 0.5) - intentY
        clickDistance = dx * dx + dy * dy
      end
      local playerDistance = cur
        and (math.abs(dst.x - cur.x) + math.abs(dst.y - cur.y)) or 0
      ranked[#ranked + 1] = {
        dst = dst, dirs = dirs, directedExit = directedExit,
        clickDistance = clickDistance, playerDistance = playerDistance,
      }
    end
  end
  table.sort(ranked, function(a,b)
    if math.abs(a.clickDistance - b.clickDistance) > 0.0001 then
      return a.clickDistance < b.clickDistance
    end
    if a.playerDistance ~= b.playerDistance then
      return a.playerDistance < b.playerDistance
    end
    if a.dst.y ~= b.dst.y then return a.dst.y < b.dst.y end
    return a.dst.x < b.dst.x
  end)
  state.stats.exitCandidatesCheap =
    (state.stats.exitCandidatesCheap or 0) + #ranked
  return ranked
end

local function nearestExitTarget(game, overview, cur, intentX, intentY)
  local map = WorldBackend.map(game)
  if not map or not overview or not cur then return nil end

  -- Supplying intent coordinates means this is the INITIAL off-map click, not
  -- a later leg of an already-authorized multi-floor exit journey. In that
  -- initial case every candidate must prove that it leaves in one of the
  -- directions the pointer actually crossed. No direction = no Smart Exit.
  local directionalGate = type(intentX) == "number" and type(intentY) == "number"
  local wantedExitDirs = directionalGate
    and ControlsFree.outsideIntentDirections(overview, intentX, intentY) or nil
  if directionalGate and #wantedExitDirs == 0 then return nil end

  local candidates = {}
  local warps = actualWarpCells(map)
  if WorldBackend.isGold(game) then
    local usable = {}
    for _, w in ipairs(warps) do
      if WorldBackend.gold.warpFiresAt(game, map, w.x, w.y) then
        usable[#usable + 1] = w
      end
    end
    warps = usable
  end
  local all, dynamic, static = liveOccupancy(game)
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  local topology = ledgeTopology(game, map, overview)

  local warpKeys = {}
  for _, w in ipairs(warps) do warpKeys[key(w.x,w.y)] = true end

  local function pathToWarp(dst, occupied, dynamicOnly,
      preDirs, preDirectedExit, preClickDistance)
    if dst.x < 0 or dst.y < 0
        or dst.x >= overview.width or dst.y >= overview.height then
      return false
    end
    local blocked = {}
    -- A real warp record may live on a plain '.' carpet cell, which means the
    -- compact overview would otherwise allow A* to use it as an intermediate
    -- node and accidentally leave through the wrong exit. Block every OTHER
    -- warp record while scoring this one.
    for k in pairs(warpKeys) do
      if k ~= key(dst.x,dst.y) then blocked[k] = true end
    end
    local dirs = warpActivationDirections(game, map, dst.x, dst.y)
    -- Initial Smart Exit requests are direction-gated. A DOWN carpet is not a
    -- candidate for a click above/right/left of the room, even if it is the
    -- nearest warp to the player. This happens BEFORE path scoring so an
    -- opposite-side exit can never win later through walking cost or rank.
    local directedExit = preDirectedExit
    if directionalGate and directedExit == nil then
      directedExit = ControlsFree.firstMatchingDirection(dirs, wantedExitDirs)
    end
    if directionalGate and not directedExit then return false end

    -- Only directional warp sources (edge/carpet semantics) may need the
    -- special non-walkable endpoint exception. Ordinary arrival warps must
    -- remain reachable through their normal terrain legality.
    local path = findPath(overview, cur.x, cur.y, dst.x, dst.y, waterMode,
      occupied, nil, topology.blockedEdges, blocked, topology.jumps, #dirs > 0)
    if not path then return end
    -- When the outside click supplied a side, THAT side also resolves an
    -- otherwise multi-direction warp deterministically. Subsequent journey
    -- legs have no pointer coordinates and retain the older conservative
    -- unique-direction / DOWN-carpet policy.
    local exitDir = directedExit or ((#dirs == 1) and dirs[1] or nil)
    if not directionalGate and not exitDir and listHas(dirs, "down") then
      exitDir = "down"
    end
    if not directionalGate and not exitDir and cur.x == dst.x and cur.y == dst.y then
      exitDir = dirs[1]
    end

    local clickDistance = preClickDistance
    if clickDistance == nil and type(intentX) == "number"
        and type(intentY) == "number" then
      local dx, dy = (dst.x + 0.5) - intentX, (dst.y + 0.5) - intentY
      clickDistance = dx * dx + dy * dy
    end
    candidates[#candidates + 1] = {
      kind = "warp", x = dst.x, y = dst.y,
      cost = #path, rank = warpExitRank(game, dst.def),
      clickDistance = clickDistance,
      exitHops = warpExitHops(game, dst.def),
      dynamic = dynamicOnly,
      exitDir = exitDir,
      carpetDown = exitDir == "down",
      edgeWarp = exitDir ~= nil and (
        (exitDir == "up" and dst.y == 0)
        or (exitDir == "down" and map.heightCells and dst.y == map.heightCells - 1)
        or (exitDir == "left" and dst.x == 0)
        or (exitDir == "right" and map.widthCells and dst.x == map.widthCells - 1)),
      warpDef = dst.def,
    }
    return true
  end

  if directionalGate then
    local rankedWarps = ControlsFree.rankSmartExitWarpsCheap(
      game, map, warps, cur, true, wantedExitDirs, intentX, intentY)
    local limit = ControlsFree.smartExitCandidateLimit()
    local firstCount = limit and math.min(limit, #rankedWarps) or #rankedWarps
    for i = 1, firstCount do
      local item = rankedWarps[i]
      pathToWarp(item.dst, all, false,
        item.dirs, item.directedExit, item.clickDistance)
    end
    -- If the cheap front slice contained no reachable warp, progressively
    -- fall through to the remaining candidates. This preserves reachability
    -- while keeping the common successful case bounded.
    if #candidates == 0 and firstCount < #rankedWarps then
      state.stats.exitCandidatesDeferred =
        (state.stats.exitCandidatesDeferred or 0) + (#rankedWarps - firstCount)
      for i = firstCount + 1, #rankedWarps do
        local item = rankedWarps[i]
        if pathToWarp(item.dst, all, false,
            item.dirs, item.directedExit, item.clickDistance) then
          break
        end
      end
    end
  else
    -- Automated multi-floor exit journeys keep exhaustive scoring because no
    -- pointer direction exists to safely prune candidates.
    for _, dst in ipairs(warps) do pathToWarp(dst, all, false) end
  end

  local hasImmediateWarp = false
  for _, c in ipairs(candidates) do
    if c.kind == "warp" and not c.dynamic then
      hasImmediateWarp = true
      break
    end
  end
  if not hasImmediateWarp then
    if directionalGate then
      local rankedWarps = ControlsFree.rankSmartExitWarpsCheap(
        game, map, warps, cur, true, wantedExitDirs, intentX, intentY)
      local limit = ControlsFree.smartExitCandidateLimit()
      local count = limit and math.min(limit, #rankedWarps) or #rankedWarps
      for i = 1, count do
        local item = rankedWarps[i]
        pathToWarp(item.dst, static, true,
          item.dirs, item.directedExit, item.clickDistance)
      end
      if #candidates == 0 and count < #rankedWarps then
        for i = count + 1, #rankedWarps do
          local item = rankedWarps[i]
          if pathToWarp(item.dst, static, true,
              item.dirs, item.directedExit, item.clickDistance) then
            break
          end
        end
      end
    else
      for _, dst in ipairs(warps) do pathToWarp(dst, static, true) end
    end
  end

  for _, c in ipairs(directConnectionExitIntents(game, overview, cur)) do
    local connectionDir = c.cross and c.cross.dir or nil
    if not directionalGate or listHas(wantedExitDirs, connectionDir) then
      if type(intentX) == "number" and type(intentY) == "number"
          and type(c.x) == "number" and type(c.y) == "number" then
        local dx, dy = (c.x + 0.5) - intentX, (c.y + 0.5) - intentY
        c.clickDistance = dx * dx + dy * dy
      end
      c.exitDir = connectionDir
      candidates[#candidates + 1] = c
    end
  end

  if #candidates == 0 then return nil end
  table.sort(candidates, function(a,b)
    local ah, bh = a.exitHops or 999999, b.exitHops or 999999
    if ah ~= bh then return ah < bh end
    if (a.rank or 9) ~= (b.rank or 9) then
      return (a.rank or 9) < (b.rank or 9)
    end
    local ac, bc = a.clickDistance, b.clickDistance
    if ac ~= nil or bc ~= nil then
      ac, bc = ac or math.huge, bc or math.huge
      if math.abs(ac - bc) > 0.0001 then return ac < bc end
    end
    if (a.cost or 999999) ~= (b.cost or 999999) then
      return (a.cost or 999999) < (b.cost or 999999)
    end
    if (a.y or 0) ~= (b.y or 0) then return (a.y or 0) < (b.y or 0) end
    return (a.x or 0) < (b.x or 0)
  end)
  return candidates[1]
end


-- Gold indoor exit semantic safety check.  Smart Exit and barrier-door
-- inference are intentionally broad enough to understand a tap just outside a
-- room.  That same forgiving behavior can be too eager when the player merely
-- misses a visible NPC/item/fixture by a few screen pixels: without this pass,
-- the miss is interpreted as "leave the room" and the route heads for the
-- carpet/door instead of the thing the finger was obviously beside.
--
-- This is NOT a general NPC magnet.  It is considered only for an INDOOR tap
-- that is already exit-prone (outside-map/world or a non-walkable local hit),
-- and exact native exits/warps/holes plus exact interactions always win before
-- this function is allowed to look around.  Candidates are measured in the
-- rendered SCREEN space so zoom and TILT do not change the human tolerance.
-- A candidate must also have a valid interaction approach; an unreachable NPC
-- can never suppress a legitimate Smart Exit.
function ControlsFree.goldIndoorExitSemanticAssist(game, screenX, screenY,
    cur, overview, tx, ty, targetErr, cross, targetMeta)
  if not WorldBackend.isGold(game) or option("interact", true) == false then
    return nil
  end
  local world = WorldBackend.gold.owner(game)
  local map = world and world.map
  if not (world and map and cur and overview) then return nil end
  if map.id ~= cur.mapId or overview.mapId ~= cur.mapId then return nil end
  if defLooksOutdoor(game, map.def) or cross then return nil end

  -- Exact semantics remain authoritative.  In particular, an intentional tap
  -- on the carpet/door must never be stolen by a nearby nurse or item ball.
  if type(tx) == "number" and type(ty) == "number" then
    if interactionAt(game, tx, ty) ~= nil then return nil end
    if hiddenTreasureInteractionAt(game, cur.mapId, tx, ty) ~= nil then return nil end
    if ControlsFree.cutInteractionAt(game, map, overview, tx, ty) ~= nil then return nil end
    if warpIntentAt(game, map, cur, tx, ty) ~= nil then return nil end
    if ControlsFree.directionalWarpIntentAt
        and ControlsFree.directionalWarpIntentAt(game, map, cur, tx, ty) ~= nil then
      return nil
    end
    if ControlsFree.holeStepIntentAt
        and ControlsFree.holeStepIntentAt(map, overview, tx, ty) ~= nil then
      return nil
    end
  end

  local exitProne = targetErr == "outside_world" or targetErr == "outside_map"
      or (targetMeta and targetMeta.outsideBehind == true)
  if not exitProne and type(tx) == "number" and type(ty) == "number" then
    local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
    local ch = cellChar(overview, tx, ty)
    -- A valid floor click is ordinary movement and must never gain a semantic
    -- halo merely because an NPC happens to be nearby.
    exitProne = not (ch == "." or (ch == "~" and waterMode))
  end
  if not exitProne then return nil end

  local g = ControlsFree.goldFrameGeometry(game, cur.mapId)
  local scale = g and tonumber(g.scale) or nil
  screenX, screenY = tonumber(screenX), tonumber(screenY)
  if not (g and scale and scale > 0 and screenX and screenY) then return nil end

  local originX = tonumber(g.originX)
    or math.floor(-(tonumber(g.cameraX) or 0) * scale)
  local originY = tonumber(g.originY)
    or math.floor(-(tonumber(g.cameraY) or 0) * scale)
  local tilePx = TILE_SIZE * scale
  local spritePad = tilePx * 0.22
  local fixtureRadius = tilePx * 0.62

  local function worldPixelToScreen(wx, wy)
    wx, wy = tonumber(wx), tonumber(wy)
    if not wx or not wy then return nil end
    local flatX = originX + wx * scale
    local flatY = originY + wy * scale
    return ControlsFree.goldFrameFlatToScreen(game, flatX, flatY, cur.mapId)
  end

  local function rectDistance(px, py, l, t, r, b)
    local dx = px < l and (l - px) or (px > r and (px - r) or 0)
    local dy = py < t and (t - py) or (py > b and (py - b) or 0)
    return math.sqrt(dx * dx + dy * dy)
  end

  local function reachableInteraction(interaction)
    local probe = newNavigation(cur)
    probe.interaction = copyFlat(interaction)
    probe.goalKind = "interact"
    local ok, why = buildInteractionPath(game, probe, cur)
    if ok or why == "dynamic" then
      return probe.interaction
    end
    return nil
  end

  local best, bestScore, bestDist, bestKind
  local function consider(interaction, distance, kind, bias)
    if not interaction or distance == nil then return end
    local resolved = reachableInteraction(interaction)
    if not resolved then return end
    local score = distance / math.max(1, tilePx) + (bias or 0)
    if not bestScore or score < bestScore then
      best, bestScore, bestDist, bestKind = resolved, score, distance, kind
    end
  end

  -- NPCs and visible item balls are upright billboards under Gold TILT.  The
  -- renderer anchors each at its FOOT, then translates that foot to the tilted
  -- ground point without shearing/resizing the sprite.  Reproduce that exact
  -- geometry here and put only a small pad around the visible 16px sprite.
  for _, entity in ipairs(world.npcs or {}) do
    if WorldBackend.gold.entityIsInteractable(entity) then
      local ex = tonumber(entity.px)
        or (tonumber(entity.cellX) and tonumber(entity.cellX) * TILE_SIZE)
      local ey = tonumber(entity.py)
        or (tonumber(entity.cellY) and tonumber(entity.cellY) * TILE_SIZE)
      if ex and ey then
        local fx, fy = worldPixelToScreen(ex + TILE_SIZE * 0.5, ey + TILE_SIZE)
        if fx and fy then
          -- SpriteRenderer's overworld sheet sits slightly above its gameplay
          -- cell; use the rendered billboard footprint, not a whole-cell halo.
          local l, r = fx - tilePx * 0.50, fx + tilePx * 0.50
          local t, b = fy - tilePx * 1.28, fy + tilePx * 0.08
          local dist = rectDistance(screenX, screenY, l, t, r, b)
          if dist <= spritePad then
            local ix = tonumber(entity.cellX) or math.floor(ex / TILE_SIZE)
            local iy = tonumber(entity.cellY) or math.floor(ey / TILE_SIZE)
            consider(entityInteraction(entity, ix, iy), dist, "entity", 0)
          end
        end
      end
    end
  end

  -- Gold bg events are visible fixed fixtures/signs/PCs.  Hidden treasure is
  -- excluded by bgInteractionAt itself and therefore remains exact-tap only.
  for _, ev in ipairs((map.def and map.def.bgEvents) or {}) do
    local cx, cy = tonumber(ev.x), tonumber(ev.y)
    if cx and cy then
      local interaction = WorldBackend.gold.bgInteractionAt(game, cx, cy)
      if interaction then
        local sx, sy = ControlsFree.goldCellCenterToScreen(game, cur.mapId, cx, cy)
        if sx and sy then
          local dx, dy = screenX - sx, screenY - sy
          local dist = math.sqrt(dx * dx + dy * dy)
          if dist <= fixtureRadius then
            -- A real actor is the stronger interpretation when both overlap.
            consider(interaction, dist, "fixture", 0.08)
          end
        end
      end
    end
  end

  if not best then return nil end
  local ix, iy = interactionTarget(game, best)
  if ix == nil or iy == nil then return nil end
  return {
    x = ix, y = iy, interaction = best,
    kind = bestKind, screenDistance = bestDist,
  }
end

local function routeFeedback(showFeedback, kind, x, y)
  if showFeedback then setPulse(kind, x, y) end
end

local function retireForRetarget(oldNav, continuous)
  if not oldNav then return end
  releaseHold(oldNav)
  markStop(continuous and "hold_retargeted" or "retargeted", oldNav)
end

local function startRoute(game, screenX, screenY, continuous, showFeedback, gestureId)
  if not ControlsFree.mapRuntimeReady(game) then
    return false
  end
  if option("enabled", true) == false then return false end
  if showFeedback == nil then showFeedback = not continuous end

  -- The live pointer owns small semantic memory for Hold-to-Steer. A door/NPC
  -- is a deliberate object selection, while a wall sample one refresh later is
  -- often just camera motion moving that same screen point across geometry.
  local gesture = pointerForGesture and pointerForGesture(gestureId) or nil
  local function clearStickySemantic()
    if gesture then gesture.stickySemantic = nil end
  end
  local function setStickySemantic(kind, mapId, x, y, entityId)
    if gesture then
      gesture.stickySemantic = {
        kind = kind, mapId = mapId, x = x, y = y, entityId = entityId,
      }
    end
  end
  local function retainStickySemantic()
    if not (continuous and gesture and gesture.stickySemantic and state.nav) then
      return false
    end
    state.stats.retainedTargets = state.stats.retainedTargets + 1
    state.stats.stickySemanticRetains = state.stats.stickySemanticRetains + 1
    return true
  end

  -- A genuinely new pointer press supersedes a previous automatic
  -- multi-floor exit journey. Hold-to-Steer refreshes never reach here while
  -- an exit journey owns navigation, so only a fresh user intent cancels it.
  if gestureId ~= nil then
    if state.exitJourney then state.exitJourney = nil end
    -- A fresh user command also supersedes a remote target that was waiting
    -- for a warp/gate transition to settle.
    state.pendingRemoteGoal = nil
  end

  -- A fresh pointer intent supersedes any destination that was waiting to
  -- resume after a wild encounter. The CURRENT route is not retired until its
  -- replacement has a valid plan.
  state.battleResume = nil

  local tx, ty, cur, overview, targetErr, cross, targetMeta
  tx, ty, cur, overview, targetErr, cross, targetMeta =
    targetFromTap(game, screenX, screenY)

  -- Before Smart Exit or the broad barrier-door fallback can reinterpret an
  -- indoor miss as "leave", give a very small rendered-space halo to a real
  -- nearby NPC/item/fixture.  Exact carpet/door taps are excluded inside the
  -- helper, so this improves forgiving interaction without weakening exits.
  if not continuous and WorldBackend.isGold(game) then
    local semanticAssist = ControlsFree.goldIndoorExitSemanticAssist(
      game, screenX, screenY, cur, overview, tx, ty, targetErr, cross, targetMeta)
    if semanticAssist then
      targetMeta = targetMeta or {}
      targetMeta.forcedInteraction = semanticAssist.interaction
      targetMeta.goldExitSemanticAssist = semanticAssist
      targetMeta.semanticAssistRawX, targetMeta.semanticAssistRawY = tx, ty
      targetMeta.semanticAssistOriginalError = targetErr
      tx, ty = semanticAssist.x, semanticAssist.y
      targetErr, cross = nil, nil
      state.stats.goldExitSemanticAssists =
        (state.stats.goldExitSemanticAssists or 0) + 1
    end
  end

  -- A Gold doorway is visually taller than its collision/warp source.  On the
  -- initial press only, let a nearby REAL native warp claim that graphic.  Do
  -- not continuously acquire new exits while Hold-to-Steer is reprojecting the
  -- same pointer as the camera moves.
  if not continuous and tx and ty and not cross and not targetErr
      and WorldBackend.isGold(game) then
    local currentMap = WorldBackend.map(game)
    local magnet = ControlsFree.goldDoorMagnet(
      game, currentMap, cur, overview, tx, ty, targetMeta)
    if magnet then
      targetMeta = targetMeta or {}
      targetMeta.goldDoorMagnet = magnet
      targetMeta.doorMagnetClickedX, targetMeta.doorMagnetClickedY = tx, ty
      tx, ty = magnet.x, magnet.y
      state.stats.goldDoorMagnetSnaps =
        (state.stats.goldDoorMagnetSnaps or 0) + 1
    end
  end

  -- If the click is deliberately beyond an actually blocking Gold facade, a
  -- door on THAT obstacle may represent the user's intended continuation even
  -- when the pointer is several cells above the visible doorway.  This runs
  -- only on the initial tap and only after the narrow visual door magnet.
  if not continuous and WorldBackend.isGold(game)
      and not (targetMeta and targetMeta.goldDoorMagnet) then
    local currentMap = WorldBackend.map(game)
    local barrierDoor = ControlsFree.goldBarrierDoorIntent(
      game, currentMap, cur, overview,
      targetMeta and targetMeta.intentX or nil,
      targetMeta and targetMeta.intentY or nil,
      tx, ty, targetErr, cross)
    if barrierDoor then
      targetMeta = targetMeta or {}
      targetMeta.goldBarrierDoor = barrierDoor
      targetMeta.barrierDoorClickedX, targetMeta.barrierDoorClickedY = tx, ty
      targetMeta.barrierDoorOriginalError = targetErr
      tx, ty = barrierDoor.x, barrierDoor.y
      targetErr, cross = nil, nil
      state.stats.goldBarrierDoorSnaps =
        (state.stats.goldBarrierDoorSnaps or 0) + 1
    end
  end

  -- Preserve one exact live Gold tap sample for the existing DEBUG OVERLAY.
  -- This turns a screenshot into actionable calibration data: raw pointer,
  -- pre/post-door cell, projected centre, camera/zoom/crop and perspective.
  -- It is read-only instrumentation and never participates in route choice.
  if not continuous and WorldBackend.isGold(game) then
    local d = {
      screenX = tonumber(screenX), screenY = tonumber(screenY),
      mapId = cur and cur.mapId or (overview and overview.mapId),
      rawCellX = targetMeta and (targetMeta.doorMagnetClickedX
        or targetMeta.barrierDoorClickedX) or tx,
      rawCellY = targetMeta and (targetMeta.doorMagnetClickedY
        or targetMeta.barrierDoorClickedY) or ty,
      finalCellX = tx, finalCellY = ty,
      targetErr = targetErr,
      intentX = targetMeta and targetMeta.intentX or nil,
      intentY = targetMeta and targetMeta.intentY or nil,
      doorSnap = targetMeta and targetMeta.goldDoorMagnet ~= nil or false,
      barrierDoor = targetMeta and targetMeta.goldBarrierDoor ~= nil or false,
      semanticAssist = targetMeta and targetMeta.goldExitSemanticAssist ~= nil or false,
      semanticAssistKind = targetMeta and targetMeta.goldExitSemanticAssist
        and targetMeta.goldExitSemanticAssist.kind or nil,
      semanticAssistDistance = targetMeta and targetMeta.goldExitSemanticAssist
        and targetMeta.goldExitSemanticAssist.screenDistance or nil,
      barrierX = targetMeta and targetMeta.goldBarrierDoor
        and targetMeta.goldBarrierDoor.barrierX or nil,
      barrierY = targetMeta and targetMeta.goldBarrierDoor
        and targetMeta.goldBarrierDoor.barrierY or nil,
      barrierPerpendicular = targetMeta and targetMeta.goldBarrierDoor
        and targetMeta.goldBarrierDoor.barrierPerpendicular or nil,
      tick = state.tick,
    }
    local g = ControlsFree.goldFrameGeometry(game, d.mapId)
    if g then
      d.scale = tonumber(g.scale)
      d.cameraX, d.cameraY = tonumber(g.cameraX), tonumber(g.cameraY)
      d.originX, d.originY = tonumber(g.originX), tonumber(g.originY)
      d.captureW, d.captureH = tonumber(g.captureW), tonumber(g.captureH)
      d.cropX, d.cropY = tonumber(g.cropX), tonumber(g.cropY)
      d.tiltActive = g.tiltActive == true
      d.tiltAngle = tonumber(g.tiltAngle)
    end
    if d.finalCellX ~= nil and d.finalCellY ~= nil and d.mapId ~= nil then
      d.cellScreenX, d.cellScreenY = ControlsFree.goldCellCenterToScreen(
        game, d.mapId, d.finalCellX, d.finalCellY)
      if d.cellScreenX and d.screenX then d.deltaX = d.cellScreenX - d.screenX end
      if d.cellScreenY and d.screenY then d.deltaY = d.cellScreenY - d.screenY end
    end
    local live = mod.world and mod.world:current()
    if live and live.mapId == d.mapId then
      d.playerCellX, d.playerCellY = live.x, live.y
      d.playerScreenX, d.playerScreenY = ControlsFree.goldCellCenterToScreen(
        game, d.mapId, live.x, live.y)
    end
    state.lastGoldTapDiagnostic = d
  end

  -- The player's billboard is not an opaque semantic target. A short tap that
  -- begins on Red first gets the exact same scene/interaction resolution as
  -- every other tap. If an NPC, PC/sign/fixture, door/warp, scripted hole,
  -- connected-map entrance or Smart Exit is genuinely behind the avatar's
  -- projection, let that target continue through the normal pathfinder.
  -- Only when there is NO stronger semantic target does tapping Red proxy the
  -- native A button in the direction he already faces.
  local gp = gesture
  local sx, sy = gp and gp.startX or screenX, gp and gp.startY or screenY
  local pdx, pdy = screenX - sx, screenY - sy
  if option("interact", true) ~= false and not continuous and gestureId ~= nil
      and pdx * pdx + pdy * pdy
          <= PLAYER_HOLD_MOVE_SLOP_UNITS * PLAYER_HOLD_MOVE_SLOP_UNITS then
    local startedOnPlayer = gp and gp.startedOnPlayer == true
    if not startedOnPlayer and ControlsFree.playerScreenHit then
      startedOnPlayer = ControlsFree.playerScreenHit(game, sx, sy) == true
    end
    if startedOnPlayer then
      state.stats.playerAvatarHitDetections =
        (state.stats.playerAvatarHitDetections or 0) + 1

      local semanticBehind = cross ~= nil
        or (targetMeta and targetMeta.forcedInteraction ~= nil)
        or (targetMeta and targetMeta.visibleKind == "entity")
      local currentMap = WorldBackend.map(game)
      if not semanticBehind and tx and ty then
        semanticBehind = interactionAt(game, tx, ty) ~= nil
          or hiddenTreasureInteractionAt(game, cur and cur.mapId, tx, ty) ~= nil
          or ControlsFree.cutInteractionAt(game, currentMap, overview, tx, ty) ~= nil
          or warpIntentAt(game, currentMap, cur, tx, ty) ~= nil
        if not semanticBehind and ControlsFree.directionalWarpIntentAt then
          semanticBehind =
            ControlsFree.directionalWarpIntentAt(game, currentMap, cur, tx, ty) ~= nil
        end
        if not semanticBehind and ControlsFree.holeStepIntentAt then
          semanticBehind =
            ControlsFree.holeStepIntentAt(currentMap, overview, tx, ty) ~= nil
        end
      end
      if not semanticBehind and cur and overview
          and (targetErr == "outside_world" or targetErr == "outside_map")
          and targetMeta then
        local wanted = ControlsFree.outsideIntentDirections(
          overview, targetMeta.intentX, targetMeta.intentY)
        if #wanted > 0 then
          semanticBehind = nearestExitTarget(
            game, overview, cur, targetMeta.intentX, targetMeta.intentY) ~= nil
        end
      end

      if not semanticBehind then
        mod.input:tap(game, "a")
        state.stats.playerAvatarInteractionProxies =
          (state.stats.playerAvatarInteractionProxies or 0) + 1
        return true
      end
    end
  end

  local exitFallback = false
  local exitIntent = nil
  local nearestFallback = false
  local semanticKind, semanticEntityId

  -- Directional warp rescue: the visible opening can be the cell IN FRONT
  -- of the real warp source and ExtraWarpCheck can require any of the four
  -- directions, not only DOWN.  Resolve the opening through actual warp data
  -- first, then route to the source and append the engine-required direction.
  if targetMeta and (targetMeta.goldDoorMagnet or targetMeta.goldBarrierDoor) then
    targetMeta.directionalWarpIntent = targetMeta.goldDoorMagnet
      or targetMeta.goldBarrierDoor
    semanticKind = "door"
  end
  if tx and not cross and cur and overview
      and not (targetMeta and targetMeta.forcedInteraction)
      and ControlsFree.directionalWarpIntentAt then
    local map = WorldBackend.map(game)
    local directionalIntent = targetMeta
      and (targetMeta.goldDoorMagnet or targetMeta.goldBarrierDoor)
      or ControlsFree.directionalWarpIntentAt(game, map, cur, tx, ty)
    if directionalIntent then
      targetMeta = targetMeta or {}
      targetMeta.directionalWarpIntent = directionalIntent
      targetMeta.directionalClickedX, targetMeta.directionalClickedY = tx, ty
      tx, ty = directionalIntent.x, directionalIntent.y
      state.stats.directionalWarpIntents =
        (state.stats.directionalWarpIntents or 0) + 1
      if directionalIntent.edgeWarp then
        state.stats.edgeWarpIntents = (state.stats.edgeWarpIntents or 0) + 1
      end
      if directionalIntent.exitDir == "down" then
        state.stats.carpetDownIntents = (state.stats.carpetDownIntents or 0) + 1
      end
    end
  end

  -- Scripted dungeon holes are onStep transitions rather than map warp
  -- records.  Preserve an exact hole tap, and recover the common Voxel case
  -- where the rendered lip/wall is selected instead of the unique adjacent
  -- walkable hole cell.
  if tx and not cross and cur and overview
      and not (targetMeta and targetMeta.forcedInteraction)
      and not (targetMeta and targetMeta.directionalWarpIntent)
      and ControlsFree.holeStepIntentAt then
    local map = WorldBackend.map(game)
    local holeIntent = ControlsFree.holeStepIntentAt(map, overview, tx, ty)
    if holeIntent then
      targetMeta = targetMeta or {}
      targetMeta.holeStepIntent = holeIntent
      tx, ty = holeIntent.x, holeIntent.y
      state.stats.holeStepIntents = (state.stats.holeStepIntents or 0) + 1
    end
  end

  -- In Voxel mode an exterior wall can be the first depth hit even though the
  -- ray's ground point is clearly beyond the current interior.
  if tx and targetMeta and targetMeta.outsideBehind
      and targetMeta.visibleKind == "structure" and cur and overview then
    local currentMap = WorldBackend.map(game)
    local currentDef = currentMap and currentMap.def
    -- `outsideBehind` is the one retained Voxel-only geometric fallback: the
    -- SAME ray hits current-map exterior structure while its ground point lies
    -- at least half a gameplay cell beyond the rendered map body. Unlike the
    -- retired void/shell guesses, this has direct camera geometry behind it.
    -- Still, real semantics always win: never turn a tappable object/warp on
    -- that gameplay cell into an EXIT request merely because perspective puts
    -- the ray's ground point beyond the room.
    local visibleInteraction = option("interact", true) ~= false
      and interactionAt(game, tx, ty) or nil
    local visibleWarp = warpIntentAt(game, currentMap, cur, tx, ty)
    if not visibleInteraction and not visibleWarp and not defLooksOutdoor(game, currentDef) then
      tx, ty, cross, targetErr = nil, nil, nil, "outside_map"
    end
  end

  -- Once this gesture has deliberately selected a door/NPC, an immediately
  -- following invalid sample does NOT steal the route. A genuinely walkable
  -- target (or another semantic target) will replace it below.
  if not tx and retainStickySemantic() then return true end

  if not tx and cur and overview
      and (targetErr == "outside_world" or targetErr == "outside_map") then
    local intentX = targetMeta and targetMeta.intentX or nil
    local intentY = targetMeta and targetMeta.intentY or nil

    -- Hold-to-Steer continuously reprojects the SAME screen point while the
    -- camera moves. It must never acquire a brand-new Smart Exit merely
    -- because the room slid underneath a stationary finger/cursor. Only the
    -- initial pointer intent may authorize leaving an interior.
    if continuous then
      state.stats.exitContinuousSuppressions =
        (state.stats.exitContinuousSuppressions or 0) + 1
    else
      local wanted = ControlsFree.outsideIntentDirections(overview, intentX, intentY)
      if #wanted > 0 then
        exitIntent = nearestExitTarget(game, overview, cur, intentX, intentY)
      end
      if exitIntent then
        state.stats.exitDirectionalAccepts =
          (state.stats.exitDirectionalAccepts or 0) + 1
        state.stats.exitClickBiasedSelections =
          (state.stats.exitClickBiasedSelections or 0) + 1
      else
        state.stats.exitDirectionalRejects =
          (state.stats.exitDirectionalRejects or 0) + 1
      end
    end
    if exitIntent then
      if exitIntent.edgeWarp then
        state.stats.edgeWarpIntents = (state.stats.edgeWarpIntents or 0) + 1
      end
      exitFallback = true
      targetErr = nil
      if exitIntent.kind == "connection" then
        cross = exitIntent.cross
        tx, ty = exitIntent.x, exitIntent.y
      else
        tx, ty, cross = exitIntent.x, exitIntent.y, nil
      end
    end
  end

  if not tx then
    state.stats.invalidTaps = state.stats.invalidTaps + 1
    if continuous and state.nav then
      state.stats.retainedTargets = state.stats.retainedTargets + 1
    end
    if targetErr == "connected_map" or targetErr == "busy"
        or targetErr == "outside_world" or targetErr == "outside_map" then
      routeFeedback(showFeedback, "invalid", screenX, screenY)
    end
    return false
  end

  local requestedMapId = cross
    and ((cross.goldSimpleRemote and cross.goldSimpleRemote.mapId)
      or (cross.remoteGoal and cross.remoteGoal.mapId) or cross.destMapId)
    or (cur and cur.mapId)
  if continuous and state.nav
      and state.nav.goalKind ~= "move_nearest"
      and state.nav.requestedMapId == requestedMapId
      and state.nav.requestedX == tx and state.nav.requestedY == ty then
    return true
  end

  local oldNav = state.nav
  local candidate, buildStatus, buildWhy

  if cross then
    local rawTx, rawTy = tx, ty

    -- Gold remote-map taps use a deliberately isolated controller.  Do not
    -- feed them back through the older cross-target classifier: on a multi-hop
    -- route `tx,ty` belong to the FINAL map while cross.destOverview belongs
    -- to the FIRST destination map.  Treating those coordinate spaces as the
    -- same was exactly the kind of plausible-looking failure that made the
    -- previous remote routing brittle.
    if WorldBackend.isGold(game) and cross.goldSimpleRemote then
      candidate = newNavigation(cur)
      candidate.goalKind = exitFallback and "exit_connection" or "cross_move"
      candidate.cross = copyFlat(cross)
      candidate.goldSimpleRemote = copyFlat(cross.goldSimpleRemote)
      candidate.cross.goldSimpleRemote = candidate.goldSimpleRemote
      candidate.requestedMapId = candidate.goldSimpleRemote.mapId
      candidate.requestedX, candidate.requestedY = rawTx, rawTy
      buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)

      -- A rendered remote map can be visually straight ahead while a building
      -- or gatehouse intentionally breaks the seamless connection.  In that
      -- case the remote target is real, but the FIRST physical leg is not a
      -- map seam at all: it is a native warp door on the blocking facade.
      -- Only try this AFTER the ordinary Gold remote planner has proved there
      -- is no usable seam.  This preserves every test10 success and restores
      -- the older "click beyond the building -> use its door" affordance.
      if not buildStatus and buildWhy ~= "dynamic" and not continuous then
        local currentMap = WorldBackend.map(game)
        local portalDoor = ControlsFree.goldBarrierDoorIntent(
          game, currentMap, cur, overview,
          targetMeta and targetMeta.intentX or nil,
          targetMeta and targetMeta.intentY or nil,
          nil, nil, "connected_map", nil)
        if portalDoor then
          local remoteGoal = copyFlat(cross.goldSimpleRemote)
          local remoteDir = cross.dir
          targetMeta = targetMeta or {}
          targetMeta.goldBarrierDoor = portalDoor
          targetMeta.portalDoorRescue = true
          state.stats.goldBarrierDoorSnaps =
            (state.stats.goldBarrierDoorSnaps or 0) + 1

          candidate = newNavigation(cur)
          candidate.goalKind = "exit"
          candidate.targetX, candidate.targetY = portalDoor.x, portalDoor.y
          candidate.exitIntent = portalDoor
          candidate.exitDir = portalDoor.exitDir
          -- Unlike an ordinary indoor Smart Exit, this journey starts outside:
          -- the first door enters a gate, subsequent legs leave the gate, and
          -- then the original remote map/cell resumes.
          candidate.exitJourney = true
          candidate.remotePortalGoal = remoteGoal
          candidate.remotePortalDir = remoteDir
          candidate.requestedMapId = cur.mapId
          candidate.requestedX, candidate.requestedY = portalDoor.x, portalDoor.y
          buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)
          if buildStatus or buildWhy == "dynamic" then
            semanticKind = "door"
            exitFallback = true
            if state.lastGoldTapDiagnostic then
              state.lastGoldTapDiagnostic.barrierDoor = true
              state.lastGoldTapDiagnostic.portalDoorRescue = true
            end
          end
        end
      end
    else
    local rawInteraction = option("interact", true) ~= false
      and neighbourInteractionAt(game, cross, tx, ty) or nil
    local crossInteraction = rawInteraction
      and ((not continuous) or rawInteraction.kind == "entity")
      and rawInteraction or nil

    if crossInteraction and crossInteraction.kind == "entity" then
      semanticKind, semanticEntityId = "npc", crossInteraction.entityId
    end

    local remoteGoal = cross.remoteGoal
    local targetOverview = remoteGoal and remoteGoal.overview or cross.destOverview
    local targetMap = remoteGoal and remoteGoal.map or cross.destMap
    local targetChar = cellChar(targetOverview, tx, ty)
    local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
    local legalMovement = targetChar == "."
      or (targetChar == "~" and waterMode)
    local crossWarpIntent = warpIntentAt(game, targetMap, nil, tx, ty)
    if crossWarpIntent or targetChar == "+" then semanticKind = "door" end

    if legalMovement and not crossInteraction then clearStickySemantic() end

    local needsNearestCross = (targetChar ~= "." and targetChar ~= "+"
        and not (targetChar == "~" and waterMode) and not crossInteraction)
      or (continuous and rawInteraction ~= nil and not crossInteraction)

    if needsNearestCross then
      if retainStickySemantic() then return true end
      local nx, ny
      if remoteGoal then
        -- The expensive route validation below will prove whether this final
        -- map cell is actually reachable.  Here we only move an unstandable
        -- visual hit to the nearest legal cell on THAT final rendered map;
        -- never reinterpret its coordinates inside the immediate neighbour.
        local maxR = (targetOverview.width or 0) + (targetOverview.height or 0)
        for r = 0, maxR do
          local found
          for cy = rawTy - r, rawTy + r do
            local dy = math.abs(cy - rawTy)
            local dx = r - dy
            for _, cx in ipairs(dx == 0 and { rawTx } or { rawTx - dx, rawTx + dx }) do
              local ch = cellChar(targetOverview, cx, cy)
              if ch == "." or (ch == "~" and waterMode) or ch == "+" then
                found = { x=cx, y=cy }
                break
              end
            end
            if found then break end
          end
          if found then nx, ny = found.x, found.y; break end
        end
      else
        nx, ny = nearestReachableCrossTarget(
          game, cur, cross, rawTx, rawTy,
          continuous and rawInteraction ~= nil)
      end
      if not nx then
        if not continuous and ControlsFree.crossTargetCandidateLimit() ~= nil then
          local localFallback = ControlsFree.currentMapTowardCrossFallback(
            game, cur, overview, cross, rawTx, rawTy)
          if localFallback then
            if oldNav then cancelRoute("retargeted") end
            state.nav = localFallback
            state.stats.routesStarted = state.stats.routesStarted + 1
            routeFeedback(showFeedback, "accepted", screenX, screenY)
            return true
          end
        end
        state.stats.invalidTaps = state.stats.invalidTaps + 1
        if continuous and oldNav then
          state.stats.retainedTargets = state.stats.retainedTargets + 1
        elseif oldNav then
          cancelRoute("retargeted")
        end
        routeFeedback(showFeedback, "invalid", screenX, screenY)
        return false
      end
      cross = copyFlat(cross)
      if remoteGoal then
        remoteGoal = copyFlat(remoteGoal)
        remoteGoal.x, remoteGoal.y = nx, ny
        cross.remoteGoal = remoteGoal
        tx, ty = nx, ny
      else
        cross.targetX, cross.targetY = nx, ny
      end
      nearestFallback = true
      crossInteraction = nil
    end

    candidate = newNavigation(cur)
    candidate.goalKind = crossInteraction and "cross_interact"
      or (exitFallback and "exit_connection"
      or (nearestFallback and "cross_nearest" or "cross_move"))
    candidate.cross = cross
    candidate.remoteGoal = cross.remoteGoal
    candidate.goldSimpleRemote = cross.goldSimpleRemote
    if exitFallback then
      candidate.exitIntent = exitIntent
      candidate.exitJourney = not defLooksOutdoor(game, WorldBackend.map(game)
        and WorldBackend.map(game).def)
    end
    candidate.crossInteraction = crossInteraction
    if crossInteraction and gestureId ~= nil then
      candidate.interactionGestureId = gestureId
      candidate.interactionRequiresRelease = true
    end
    candidate.requestedMapId =
      (candidate.remoteGoal and candidate.remoteGoal.mapId) or cross.destMapId
    candidate.requestedX, candidate.requestedY = rawTx, rawTy
    local budgetHitsBeforeBuild = state.stats.pathBudgetHits or 0
    buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)
    local directCrossBudgetExhausted =
      (state.stats.pathBudgetHits or 0) > budgetHitsBeforeBuild

    -- Even an apparently legal neighbour tile can be disconnected from every
    -- usable seam. Fall back toward the requested point rather than making the
    -- held input disappear.
    if not buildStatus and buildWhy ~= "dynamic"
        and not candidate.remoteGoal
        and not crossInteraction and semanticKind ~= "door"
        and not (directCrossBudgetExhausted
          and ControlsFree.crossTargetCandidateLimit() ~= nil) then
      local nx, ny = nearestReachableCrossTarget(game, cur, cross, rawTx, rawTy, false)
      if nx and (nx ~= cross.targetX or ny ~= cross.targetY) then
        cross = copyFlat(cross)
        cross.targetX, cross.targetY = nx, ny
        candidate = newNavigation(cur)
        candidate.goalKind = "cross_nearest"
        candidate.cross = cross
        candidate.remoteGoal = cross.remoteGoal
        candidate.requestedMapId =
          (candidate.remoteGoal and candidate.remoteGoal.mapId) or cross.destMapId
        candidate.requestedX, candidate.requestedY = rawTx, rawTy
        buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)
        nearestFallback = buildStatus and true or nearestFallback
      end
    elseif not buildStatus and buildWhy ~= "dynamic"
        and not candidate.remoteGoal
        and not crossInteraction and semanticKind ~= "door"
        and directCrossBudgetExhausted
        and ControlsFree.crossTargetCandidateLimit() ~= nil then
      state.stats.crossFallbackBudgetExhaustedSkips =
        (state.stats.crossFallbackBudgetExhaustedSkips or 0) + 1
    end

    -- A bounded preset is allowed to give up on the expensive cross-map
    -- interpretation, but a single click must still produce useful movement.
    -- Fall back to one current-map nearest-reachable search toward the same
    -- visual direction. HOLD is intentionally excluded; its continuous
    -- steering behavior already remains responsive.
    if not buildStatus and not continuous
        and not candidate.remoteGoal
        and not crossInteraction and semanticKind ~= "door"
        and ControlsFree.crossTargetCandidateLimit() ~= nil then
      local localFallback = ControlsFree.currentMapTowardCrossFallback(
        game, cur, overview, cross, rawTx, rawTy)
      if localFallback then
        candidate = localFallback
        buildStatus, buildWhy = true, nil
      end
    end
    end -- isolated Gold remote-map controller / legacy cross classifier
  else
    -- A cell may intentionally be BOTH a background interaction and a real
    -- directional warp (CERULEAN_TRASHED_HOUSE's wall hole is exactly that).
    -- NPCs keep absolute interaction priority, but a confirmed directional
    -- warp wins over a fixed bg/sign interaction when the user taps that cell:
    -- tapping the hole means "go through it", not merely "read the hole".
    local selectedWarpIntent = targetMeta and targetMeta.directionalWarpIntent
      or warpIntentAt(game, WorldBackend.map(game),
                      cur, tx, ty)
    local forcedInteraction = targetMeta and targetMeta.forcedInteraction or nil
    local exactHiddenTreasure = option("interact", true) ~= false
      and hiddenTreasureInteractionAt(game, cur.mapId, tx, ty) or nil
    local cutInteraction = option("interact", true) ~= false
      and ControlsFree.cutInteractionAt(
        game, WorldBackend.map(game), overview, tx, ty) or nil
    local rawInteraction = forcedInteraction or exactHiddenTreasure or cutInteraction
      or (option("interact", true) ~= false and interactionAt(game, tx, ty) or nil)
    if cutInteraction and rawInteraction == cutInteraction then
      state.stats.cutTargets = (state.stats.cutTargets or 0) + 1
    end
    if exactHiddenTreasure and rawInteraction == exactHiddenTreasure then
      state.stats.hiddenTreasureTargets =
        (state.stats.hiddenTreasureTargets or 0) + 1
    end
    local directionalWarpOwnsCell = selectedWarpIntent ~= nil
      and selectedWarpIntent.exitDir ~= nil
      and forcedInteraction == nil
      and not (rawInteraction and rawInteraction.kind == "entity")
    local interaction = (not directionalWarpOwnsCell) and rawInteraction
      and ((not continuous) or rawInteraction.kind == "entity")
      and rawInteraction or nil

    if interaction and interaction.kind == "entity" then
      semanticKind, semanticEntityId = "npc", interaction.entityId
      candidate = newNavigation(cur)
      candidate.interaction = interaction
      candidate.goalKind = "interact"
      if gestureId ~= nil then
        candidate.interactionGestureId = gestureId
        candidate.interactionRequiresRelease = true
      end
      candidate.requestedMapId = cur.mapId
      candidate.requestedX, candidate.requestedY = tx, ty
      buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)
    elseif interaction then
      -- Non-hold Tap-to-Interact keeps all fixed interaction surfaces.
      candidate = newNavigation(cur)
      candidate.interaction = interaction
      candidate.goalKind = "interact"
      if gestureId ~= nil then
        candidate.interactionGestureId = gestureId
        candidate.interactionRequiresRelease = true
      end
      candidate.requestedMapId = cur.mapId
      candidate.requestedX, candidate.requestedY = tx, ty
      buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)
    else
      local ch = cellChar(overview, tx, ty)
      local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
      local directWarpIntent = selectedWarpIntent
      local activeExitIntent = exitIntent or directWarpIntent
      local legalMovement = ch == "." or (ch == "~" and waterMode)
      local doorSelection = activeExitIntent ~= nil or ch == "+"

      if doorSelection then
        semanticKind = "door"
      elseif legalMovement and not rawInteraction then
        clearStickySemantic()
      end

      -- Fixed interaction surfaces during a HOLD are movement targets only:
      -- approach their nearest legal floor, never fire A. Generic solid
      -- geometry gets the same nearest-reachable behavior.
      local needsNearest = ((not legalMovement and ch ~= "+")
          and activeExitIntent == nil)
        or (continuous and rawInteraction ~= nil)

      if needsNearest then
        if retainStickySemantic() then return true end
        candidate = newNavigation(cur)
        candidate.goalKind = "move_nearest"
        candidate.requestedMapId = cur.mapId
        candidate.requestedX, candidate.requestedY = tx, ty
        -- A fixed interaction surface may live on a terrain cell that the
        -- compact overview calls walkable. During Hold-to-Steer it is still
        -- an OBJECT target, so do not let nearest-legal fallback choose the
        -- surface itself; stop beside it instead.
        if continuous and rawInteraction ~= nil then
          candidate.blockedCells[key(tx, ty)] = true
        end
        buildStatus, buildWhy = buildNearestLegalPath(game, candidate, cur, tx, ty)
        nearestFallback = buildStatus and true or false
      else
        candidate = newNavigation(cur)
        candidate.goalKind = activeExitIntent and "exit" or "move"
        candidate.targetX, candidate.targetY = tx, ty
        if activeExitIntent then
          candidate.exitIntent = activeExitIntent
          candidate.exitDir = activeExitIntent.exitDir
          candidate.exitJourney = exitFallback and not defLooksOutdoor(game, WorldBackend.map(game)
            and WorldBackend.map(game).def) or false
        end
        candidate.requestedMapId = cur.mapId
        candidate.requestedX, candidate.requestedY = tx, ty
        buildStatus, buildWhy = rebuildNavigation(game, candidate, cur)

        -- A cell can look walkable yet be statically disconnected from the
        -- player. Do not revert to the previous route: move as close as the
        -- legal graph allows toward the newly selected position.
        if not buildStatus and buildWhy ~= "dynamic"
            and not activeExitIntent and legalMovement then
          candidate = newNavigation(cur)
          candidate.goalKind = "move_nearest"
          candidate.requestedMapId = cur.mapId
          candidate.requestedX, candidate.requestedY = tx, ty
          buildStatus, buildWhy = buildNearestLegalPath(game, candidate, cur, tx, ty)
          nearestFallback = buildStatus and true or false
        end
      end
    end
  end

  local dynamicallyReachable = buildWhy == "dynamic"
  if not buildStatus and not dynamicallyReachable then
    state.stats.invalidTaps = state.stats.invalidTaps + 1
    if continuous then
      if oldNav then state.stats.retainedTargets = state.stats.retainedTargets + 1 end
    else
      if oldNav then cancelRoute("retargeted") end
      state.nav = candidate
      if candidate and candidate.cross then
        cancelRoute("connection_no_route_" .. tostring(buildWhy))
      elseif candidate and candidate.interaction then
        cancelRoute("interaction_no_route_" .. tostring(buildWhy))
      else
        cancelRoute("no_route")
      end
    end
    routeFeedback(showFeedback, "invalid", screenX, screenY)
    return false
  end

  -- Preserve the ORIGINAL pointer intent on the route.  The Gold endpoint
  -- interaction assist runs only after movement has finished, so it must not
  -- infer intent from the camera position at that later time.
  if candidate then
    candidate.intentX = targetMeta and tonumber(targetMeta.intentX) or candidate.intentX
    candidate.intentY = targetMeta and tonumber(targetMeta.intentY) or candidate.intentY
    candidate.tapScreenX = tonumber(screenX)
    candidate.tapScreenY = tonumber(screenY)
  end

  retireForRetarget(oldNav, continuous)
  state.nav = candidate
  state.stats.routesStarted = state.stats.routesStarted + 1
  if nearestFallback then
    state.stats.nearestFallbacks = state.stats.nearestFallbacks + 1
  end
  if semanticKind == "door" then
    setStickySemantic("door", requestedMapId, tx, ty)
  elseif semanticKind == "npc" then
    setStickySemantic("npc", requestedMapId, tx, ty, semanticEntityId)
    if continuous then state.stats.npcHoldTargets = state.stats.npcHoldTargets + 1 end
  end

  if exitFallback then state.stats.exitFallbacks = state.stats.exitFallbacks + 1 end
  if candidate.exitJourney then
    state.exitJourney = {
      startedTick = state.tick, legs = 1,
      visited = { [cur.mapId] = 1 },
      remoteGoal = candidate.remotePortalGoal and copyFlat(candidate.remotePortalGoal) or nil,
      remoteDir = candidate.remotePortalDir,
    }
    state.stats.exitJourneyLegs = state.stats.exitJourneyLegs + 1
  end

  local feedbackKind = (candidate.interaction or candidate.crossInteraction)
      and "interaction" or "accepted"
  routeFeedback(showFeedback, feedbackKind, screenX, screenY)

  if deferUntilCurrentStepLands(game, candidate) then return true end

  if candidate.goalKind ~= "interact" and not candidate.cross
      and not (candidate.goalKind == "exit" and candidate.exitDir)
      and cur.x == candidate.targetX and cur.y == candidate.targetY then
    finishRoute()
    return true
  end

  if dynamicallyReachable then
    scheduleDynamicWait(candidate,
      candidate.cross and "initial_connection_dynamic"
      or candidate.interaction and "initial_interaction_dynamic"
      or "initial_dynamic_obstacle")
  end
  return true
end

-- Continue an off-map "leave this interior" request after an internal warp.
-- Each leg is planned only after the destination map becomes the live map, so
-- vanilla scripts/doors/NPCs remain authoritative. The map graph above picks
-- the warp that actually leads toward outdoors; local A* picks the shortest
-- reachable way to that warp from the player's current cell.
local function startExitJourneyLeg(game)
  local journey = state.exitJourney
  if not journey or state.nav then return false, "inactive" end
  if option("enabled", true) == false then
    state.exitJourney = nil
    return false, "disabled"
  end
  local free = overworldGate(game)
  if not free then return nil, "busy" end
  if anyDirectionDown and anyDirectionDown(game) then
    state.exitJourney = nil
    return false, "manual_override"
  end
  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if not cur or not overview or cur.mapId ~= overview.mapId then
    return nil, "map_not_ready"
  end
  local map = WorldBackend.map(game)
  local def = map and map.def
  if defLooksOutdoor(game, def) then
    if journey.remoteGoal then
      state.pendingRemoteGoal = copyFlat(journey.remoteGoal)
      state.exitJourney = nil
      return true, "remote_resume"
    end
    state.exitJourney = nil
    return false, "outside"
  end

  -- A portal rescue remembers which side of the original outdoor map the
  -- player was trying to reach.  Carry that compass intent through a gatehouse
  -- so the closer BACK door cannot win merely because it costs fewer steps.
  local intentX, intentY
  if journey.remoteDir == "up" then
    intentX, intentY = cur.x + 0.5, -1
  elseif journey.remoteDir == "down" then
    intentX, intentY = cur.x + 0.5, (overview.height or cur.y + 1) + 1
  elseif journey.remoteDir == "left" then
    intentX, intentY = -1, cur.y + 0.5
  elseif journey.remoteDir == "right" then
    intentX, intentY = (overview.width or cur.x + 1) + 1, cur.y + 0.5
  end
  local intent = nearestExitTarget(game, overview, cur, intentX, intentY)
  if not intent then
    state.exitJourney = nil
    return false, "no_exit"
  end

  local candidate = newNavigation(cur)
  candidate.exitJourney = true
  candidate.exitIntent = intent
  candidate.requestedX, candidate.requestedY = intent.x, intent.y
  local ok, why
  if intent.kind == "connection" then
    candidate.goalKind = "exit_connection"
    candidate.cross = intent.cross
    candidate.requestedMapId = intent.cross and intent.cross.destMapId or cur.mapId
    ok, why = rebuildNavigation(game, candidate, cur)
  else
    -- nearestExitTarget is built from ACTUAL map warp records. Do not run its
    -- chosen endpoint back through mapOverview terrain legality: some Gen I
    -- exit carpets are deliberately non-walkable collision cells and would
    -- be rejected here even though they are the correct warp source.
    candidate.goalKind = "exit"
    candidate.targetX, candidate.targetY = intent.x, intent.y
    candidate.exitDir = intent.exitDir
    candidate.requestedMapId = cur.mapId
    ok, why = rebuildNavigation(game, candidate, cur)
  end

  local dynamic = why == "dynamic"
  if not ok and not dynamic then
    state.exitJourney = nil
    return false, why or "no_route"
  end

  state.nav = candidate
  journey.legs = (journey.legs or 0) + 1
  journey.visited = journey.visited or {}
  journey.visited[cur.mapId] = (journey.visited[cur.mapId] or 0) + 1
  if journey.visited[cur.mapId] > 4 or journey.legs > 24 then
    state.nav = nil
    state.exitJourney = nil
    return false, "journey_loop"
  end
  state.stats.routesStarted = state.stats.routesStarted + 1
  state.stats.exitJourneyLegs = state.stats.exitJourneyLegs + 1
  if dynamic then scheduleDynamicWait(candidate, "exit_journey_dynamic") end
  return true
end

-- Resume the ORIGINAL connected-map cell after a barrier door/gate has put the
-- player back on an outdoor map.  This uses the exact same test10 Gold remote
-- controller that already works for ordinary seamless neighbours; the portal
-- layer only bridges the otherwise impossible first seam.
function ControlsFree.startPendingRemoteGoal(game)
  local goal = state.pendingRemoteGoal
  if not goal then return false, "inactive" end
  local free = overworldGate(game)
  if not free then return nil, "busy" end
  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if not cur or not overview or cur.mapId ~= overview.mapId then
    return nil, "map_not_ready"
  end

  local candidate = newNavigation(cur)
  local ok, why
  if cur.mapId == goal.mapId then
    candidate.goalKind = "move"
    candidate.targetX, candidate.targetY = goal.x, goal.y
    candidate.requestedMapId = goal.mapId
    candidate.requestedX, candidate.requestedY = goal.x, goal.y
    candidate.intentX, candidate.intentY = goal.x + 0.5, goal.y + 0.5
    ok, why = buildPath(game, candidate, cur)
    if not ok and why ~= "dynamic" then
      ok, why = buildNearestLegalPath(game, candidate, cur, goal.x, goal.y)
    end
  else
    local cross = ControlsFree.goldSimpleRemoteTarget(game, goal.mapId, goal.x, goal.y)
    if not cross then
      state.pendingRemoteGoal = nil
      return false, "no_map_route"
    end
    candidate.goalKind = "cross_move"
    candidate.cross = copyFlat(cross)
    candidate.goldSimpleRemote = copyFlat(cross.goldSimpleRemote)
    candidate.cross.goldSimpleRemote = candidate.goldSimpleRemote
    candidate.requestedMapId = goal.mapId
    candidate.requestedX, candidate.requestedY = goal.x, goal.y
    ok, why = rebuildNavigation(game, candidate, cur)
  end

  local dynamic = why == "dynamic"
  if not ok and not dynamic then
    state.pendingRemoteGoal = nil
    return false, why or "no_route"
  end
  state.pendingRemoteGoal = nil
  state.nav = candidate
  state.stats.routesStarted = state.stats.routesStarted + 1
  if dynamic then scheduleDynamicWait(candidate, "portal_remote_resume_dynamic") end
  return true
end

local function advanceAlongKnownPath(nav, cur)
  local nextNode = nav.path and nav.path[nav.index]
  if nextNode and nextNode.x == cur.x and nextNode.y == cur.y then
    nav.index = nav.index + 1
    return true
  end

  -- Ledges can advance more than one cell.  If vanilla movement lands farther
  -- along the route, fast-forward rather than treating the faithful hop as an
  -- override.  Forced movement to somewhere NOT on the route still cancels.
  for i = (nav.index or 1) + 1, #(nav.path or {}) do
    local node = nav.path[i]
    if node.x == cur.x and node.y == cur.y then
      nav.index = i + 1
      return true
    end
  end

  return false
end

local function holdIsDown(game, nav)
  local input = game and game.input
  if not nav or not nav.holdDir or not input or type(input.isDown) ~= "function" then
    return true -- no public observation available: keep the safe old behavior
  end
  local ok, down = pcall(input.isDown, input, nav.holdDir)
  if not ok then return true end
  return down == true
end

local function requestReplan(nav, reason)
  if not nav then return end
  nav.needsReplan = true
  state.stats.replans = state.stats.replans + 1
  setPhase(nav, "REPLANNING", reason)
end

local function processPendingInteraction()
  local pending = state.pendingInteraction
  if not pending then return end
  if state.tick - pending.tick > 3 then
    state.pendingInteraction = nil
    state.stats.interactionMisses = state.stats.interactionMisses + 1
    state.lastStop = {
      reason = "interaction_unconfirmed",
      tick = state.tick,
      mapId = pending.mapId,
      targetX = pending.x,
      targetY = pending.y,
    }
  end
end


-- Gold post-arrival semantic resolver ----------------------------------------
--
-- This runs ONLY after the proven movement core says "arrived".  It never
-- participates in pathfinding or exit selection, so a bad semantic guess cannot
-- stop basic movement.  The user asked for Gen1-style finishing: once stopped,
-- notice a nearby interaction, face it visibly, confirm facing, then press A.
ControlsFree.goldPromoteEndpointInteraction = function(game, nav, cur)
  if not (WorldBackend.isGold(game) and nav and cur)
      or option("interact", true) == false then return false end
  if nav.endpointAssistTried or nav.interaction or nav.cross then return false end
  if nav.goalKind == "exit" or nav.goalKind == "exit_connection"
      or nav.goalKind == "cross_move" or nav.goalKind == "cross_nearest"
      or nav.goalKind == "cross_interact" then return false end

  local player = WorldBackend.gold.player(game)
  if not player or player.moving then return false end
  nav.endpointAssistTried = true

  local intentX = tonumber(nav.intentX)
  local intentY = tonumber(nav.intentY)
  if not intentX or not intentY then
    intentX = tonumber(nav.requestedX) and (tonumber(nav.requestedX) + 0.5) or nil
    intentY = tonumber(nav.requestedY) and (tonumber(nav.requestedY) + 0.5) or nil
  end

  local best
  local function consider(interaction, tx, ty, dir, rank)
    if not interaction then return end
    if interaction.requiredFacing and interaction.requiredFacing ~= dir then return end
    if interaction.preferredFacing and interaction.preferredFacing ~= dir then
      rank = rank + 2
    end
    local dist = 0
    if intentX and intentY then
      local dx = (tx + 0.5) - intentX
      local dy = (ty + 0.5) - intentY
      dist = math.sqrt(dx * dx + dy * dy)
      -- The endpoint rule is intentionally stronger than the initial tap
      -- magnet: once movement has genuinely stopped, ANY cardinal-adjacent
      -- native interaction is eligible.  The original tap is used only to
      -- choose between multiple adjacent candidates.  This mirrors the user's
      -- Gen1 expectation for PCs/signs/NPCs/hidden objects and cannot interfere
      -- with walking because it runs only after route completion.
    end
    local score = dist * 10 + (rank or 0)
    if not best or score < best.score then
      best = { interaction = interaction, x = tx, y = ty,
               dir = dir, score = score }
    end
  end

  local overview = WorldBackend.overview(game)
  local liveMap = WorldBackend.map(game)
  for rank, d in ipairs(DIRS) do
    local tx, ty = cur.x + d.dx, cur.y + d.dy
    -- Visible/native semantics first.  CUT is also a native A interaction in
    -- Gold; the field-move handler itself remains authoritative for move/badge
    -- eligibility.  Hidden treasure is deliberately lower priority when two
    -- different adjacent semantics compete for the same endpoint.
    consider(interactionAt(game, tx, ty), tx, ty, d.name, rank)
    if overview and liveMap then
      consider(ControlsFree.cutInteractionAt(game, liveMap, overview, tx, ty),
               tx, ty, d.name, rank + 5)
    end
    consider(hiddenTreasureInteractionAt(game, cur.mapId, tx, ty),
             tx, ty, d.name, rank + 10)
  end

  if not best then return false end
  local interaction = copyFlat(best.interaction)
  local ix, iy = interactionTarget(game, interaction)
  if not ix then return false end
  interaction.targetX, interaction.targetY = ix, iy
  interaction.faceDir = best.dir
  interaction.clickedX = interaction.clickedX or best.x
  interaction.clickedY = interaction.clickedY or best.y

  nav.interaction = interaction
  nav.goalKind = "interact"
  nav.targetX, nav.targetY = cur.x, cur.y
  nav.lastX, nav.lastY = cur.x, cur.y
  nav.path, nav.index = {}, 1
  nav.faceNeutralTick = nil
  nav.facePressTick = nil
  nav.faceVerifiedTick = nil
  nav.faceRetryCount = 0
  nav.interactionRequiresRelease = false -- arrival occurs after the tap gesture
  nav.endpointAssistPromoted = true
  setPhase(nav, "WALKING", "gold_endpoint_semantic")
  state.stats.goldEndpointInteractionPromotions =
    (state.stats.goldEndpointInteractionPromotions or 0) + 1
  return true
end

local function interactionAtDestination(game, nav, cur)
  local interaction = nav and nav.interaction
  if not interaction then return false end
  local ix, iy, entity, err = interactionTarget(game, interaction)
  if not ix then
    cancelRoute("interaction_target_" .. tostring(err or "gone"))
    return true
  end

  if state.tick - (nav.createdTick or state.tick) > MAX_INTERACTION_AGE_TICKS then
    cancelRoute("interaction_timeout")
    return true
  end

  -- A wandering NPC is not actually present at targetX/targetY until its
  -- current step lands.  Wait without holding a direction, then the next tick
  -- either interacts or replans if it chose another wander step.
  if entity and entity.moving then
    releaseHold(nav)
    setPhase(nav, "WAITING_INTERACTION_TARGET", "target_mid_step")
    return true
  end

  if ix ~= interaction.targetX or iy ~= interaction.targetY then
    releaseHold(nav)
    interaction.chaseReplan = true
    requestReplan(nav, "interaction_target_moved_at_arrival")
    return true
  end

  -- Movement begins on pointer press, but A belongs to pointer RELEASE. If the
  -- same gesture is still physically down when we reach the approach cell,
  -- wait here without walking or turning. A short tap therefore feels instant
  -- on long routes, while an adjacent NPC cannot interact before the OS has
  -- even delivered the finger-up event. NPCs deliberately remain valid
  -- semantic targets during Hold-to-Steer; the held-pointer gate is what makes
  -- that safe, because A cannot fire until this gesture actually disappears.
  if nav.interactionRequiresRelease and nav.interactionGestureId ~= nil
      and gestureIsDown(nav.interactionGestureId) then
    releaseHold(nav)
    if nav.phase ~= "WAITING_INTERACTION_RELEASE" then
      state.stats.interactionReleaseWaits =
        (state.stats.interactionReleaseWaits or 0) + 1
    end
    setPhase(nav, "WAITING_INTERACTION_RELEASE", "pointer_still_down")
    return true
  end

  local dir = interaction.faceDir
  if not dir then
    cancelRoute("interaction_no_facing")
    return true
  end

  local player = WorldBackend.player(game)
  if not player then
    cancelRoute("interaction_no_player")
    return true
  end

  -- A completed path can arrive with Gen1Recomp's turn-in-place latch spent
  -- by the final walking direction.  A fresh facing input in that state may
  -- immediately try to WALK instead of being consumed as a pure turn.  The
  -- engine re-arms turns only after one input poll with no direction held
  -- (OverworldController's .noDirectionButtonsPressed path), so interaction
  -- finishing is deliberately staged:
  --
  --   ARRIVE -> one neutral poll -> press desired facing -> verify facing
  --          -> release direction / let the turn settle -> A
  --
  -- This is especially important for fixed hidden-event fixtures such as
  -- Pokémon Center PCs, whose engine callback rejects A unless player.facing
  -- exactly matches the event's required direction.
  if player.facing ~= dir then
    -- We already issued the turn press on a previous fixed tick.  Keep it for
    -- a short bounded window so the engine gets a chance to consume it, but
    -- never long enough to turn a delayed press into sustained navigation.
    if nav.phase == "FACING_INTERACTION" and nav.facePressTick then
      if state.tick - nav.facePressTick <= 2 then
        return true
      end
      releaseHold(nav)
      nav.facePressTick = nil
      nav.faceNeutralTick = state.tick
      nav.faceRetryCount = (nav.faceRetryCount or 0) + 1
      state.stats.interactionFaceRetries =
        (state.stats.interactionFaceRetries or 0) + 1
      if nav.faceRetryCount > 2 then
        cancelRoute("interaction_face_failed")
        return true
      end
      state.stats.interactionFaceNeutralTicks =
        (state.stats.interactionFaceNeutralTicks or 0) + 1
      setPhase(nav, "WAITING_INTERACTION_FACE_NEUTRAL",
               "retry_neutral_before_" .. dir)
      return true
    end

    if nav.phase == "WAITING_INTERACTION_FACE_NEUTRAL"
        and nav.faceNeutralTick and nav.faceNeutralTick < state.tick then
      -- The previous nextFn ran with our synthetic directions released, which
      -- is the poll Gen1Recomp needs to set player.turnArmed again.  Now the
      -- requested direction is guaranteed to be a turn-in-place attempt.
      releaseHold(nav)
      nav.holdDir = dir
      nav.hold = mod.input:press(game, dir)
      nav.facePressTick = state.tick
      state.stats.interactionFaceTurns =
        (state.stats.interactionFaceTurns or 0) + 1
      setPhase(nav, "FACING_INTERACTION", "turn_to_" .. dir)
      return true
    end

    -- First arrival with the wrong facing: do NOT press the direction yet.
    -- Give vanilla one complete neutral fixed step to re-arm its turn latch.
    releaseHold(nav)
    nav.facePressTick = nil
    nav.faceVerifiedTick = nil
    nav.faceNeutralTick = state.tick
    nav.faceRetryCount = nav.faceRetryCount or 0
    state.stats.interactionFaceNeutralTicks =
      (state.stats.interactionFaceNeutralTicks or 0) + 1
    setPhase(nav, "WAITING_INTERACTION_FACE_NEUTRAL",
             "neutral_before_" .. dir)
    return true
  end

  -- If we just reached the requested facing through our synthetic turn, stop
  -- holding the direction BEFORE doing anything else.  Waiting through the
  -- remaining turnTimer gives the renderer and vanilla movement state a clean
  -- settled frame and guarantees A is never mixed with a still-held D-pad.
  if nav.phase == "FACING_INTERACTION" then
    releaseHold(nav)
    nav.facePressTick = nil
    nav.faceVerifiedTick = state.tick
    state.stats.interactionFaceVerified =
      (state.stats.interactionFaceVerified or 0) + 1
    setPhase(nav, "WAITING_INTERACTION_FACE_SETTLE",
             "facing_verified_" .. dir)
    return true
  end

  if nav.phase == "WAITING_INTERACTION_FACE_SETTLE" then
    releaseHold(nav)
    if player.facing ~= dir then
      nav.faceNeutralTick = state.tick
      setPhase(nav, "WAITING_INTERACTION_FACE_NEUTRAL",
               "facing_changed_before_a")
      return true
    end
    -- Player:turnTimer is engine-owned and counts down during the fixed update.
    -- Waiting for it to clear is conservative (~4 frames in vanilla) and makes
    -- the visible avatar finish the turn before the interaction button fires.
    if tonumber(player.turnTimer or 0) > 0 then return true end
    if nav.faceVerifiedTick and nav.faceVerifiedTick >= state.tick then
      return true
    end
  end

  releaseHold(nav)
  if interaction.goldNativeCut and WorldBackend.isGold(game) then
    -- Tap to Move owns only target selection + stance/facing. Gold's ordinary
    -- A-press interaction owns move/badge eligibility, the yes/no prompt,
    -- animation, block replacement and SFX.
    mod.input:tap(game, "a")
    state.stats.cutDirectTriggers = (state.stats.cutDirectTriggers or 0) + 1
    state.pendingInteraction = {
      tick = state.tick, mapId = nav.mapId, kind = "gold_cut",
      x = ix, y = iy,
    }
    markStop("interaction_triggered", nav)
    state.nav = nil
    return true
  end
  if interaction.cutTarget then
    local ow = game and game.overworld
    local okCheck, status = false, nil
    if ow and type(ow.useCutFieldMove) == "function" then
      okCheck, status = pcall(ow.useCutFieldMove, ow)
    end
    -- Avoid any custom "success" shortcut: tryCut owns the real Gen I text,
    -- block swap, animation and SFX. The only acceptable preflight is "ok".
    if status ~= "ok" or not ow or type(ow.tryCut) ~= "function" then
      state.stats.cutDenied = (state.stats.cutDenied or 0) + 1
      cancelRoute("cut_direct_rejected_" .. tostring(status or "no_api"))
      return true
    end
    local okCut, started = pcall(ow.tryCut, ow, ix, iy)
    if not okCut or started ~= true then
      state.stats.cutDenied = (state.stats.cutDenied or 0) + 1
      cancelRoute("cut_direct_failed")
      return true
    end
    nav.interaction = nil
    nav.cutWait = { x = ix, y = iy, direct = true, startedTick = state.tick }
    state.stats.cutDirectTriggers = (state.stats.cutDirectTriggers or 0) + 1
    setPhase(nav, "WAITING_CUT_FLOW", "cut_direct_tree")
    return true
  end

  mod.input:tap(game, "a")
  if interaction.hiddenTreasure then
    state.stats.hiddenTreasureTriggers =
      (state.stats.hiddenTreasureTriggers or 0) + 1
  end
  state.pendingInteraction = {
    tick = state.tick,
    mapId = nav.mapId,
    kind = interaction.kind,
    entityId = interaction.entityId,
    x = ix, y = iy,
  }
  state.stats.interactionsTriggered = state.stats.interactionsTriggered + 1
  markStop("interaction_triggered", nav)
  state.nav = nil
  return true
end

anyDirectionDown = function(game)
  local input = game and game.input
  if not input or not input.isDown then return false end
  return input:isDown("up") or input:isDown("down")
      or input:isDown("left") or input:isDown("right")
end

local function dropBattleResume(reason)
  if not state.battleResume then return false end
  state.stats.battleResumeDrops = state.stats.battleResumeDrops + 1
  state.lastStop = {
    reason = "battle_resume_" .. tostring(reason or "dropped"),
    tick = state.tick,
    mapId = state.battleResume.mapId,
    targetX = state.battleResume.x, targetY = state.battleResume.y,
  }
  state.battleResume = nil
  return true
end

local function tryBattleResume(game)
  local resume = state.battleResume
  if not resume or not resume.ready or state.nav then return false end
  if option("enabled", true) == false then
    dropBattleResume("mod_disabled")
    return false
  end
  if option("battle_resume", false) ~= true then
    dropBattleResume("disabled")
    return false
  end
  if state.tick - (resume.endedTick or state.tick) > MAX_BATTLE_RESUME_AGE_TICKS then
    dropBattleResume("timeout")
    return false
  end
  if resume.readyTick and state.tick < resume.readyTick then return false end

  local free = overworldGate(game)
  if not free then return false end
  -- Manual movement after the fight is a stronger signal than the stored tap.
  -- Do not fight the player for the first overworld tick back.
  if anyDirectionDown(game) then
    dropBattleResume("manual_override")
    return false
  end

  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  if not cur or not overview or cur.mapId ~= resume.mapId
      or overview.mapId ~= resume.mapId then
    dropBattleResume("map_changed")
    return false
  end

  local ch = cellChar(overview, resume.x, resume.y)
  local waterMode = ControlsFree.routeWaterMode(game, overview, cur)
  if ch ~= "." and ch ~= "+" and not (ch == "~" and waterMode) then
    dropBattleResume("target_invalid")
    return false
  end

  local targetX, targetY = resume.x, resume.y
  state.battleResume = nil
  local nav = newNavigation(cur)
  nav.goalKind = "move"
  nav.targetX, nav.targetY = targetX, targetY
  nav.requestedX, nav.requestedY = targetX, targetY
  nav.resumedAfterBattle = true
  state.nav = nav
  state.stats.routesStarted = state.stats.routesStarted + 1
  state.stats.battleResumes = state.stats.battleResumes + 1

  if cur.x == targetX and cur.y == targetY then
    finishRoute()
    return true
  end
  local ok, why = rebuildNavigation(game, nav, cur)
  if ok then return true end
  if why == "dynamic" then
    scheduleDynamicWait(nav, "battle_resume_dynamic")
    return true
  end
  cancelRoute("battle_resume_no_route_" .. tostring(why))
  return false
end

local function currentWorldPointerHeld()
  local id = state.tapOwner
  local p = id and state.pointers[id]
  return p ~= nil and not p.ignored and not p.manualSuppressed
      and not p.gestureSuppressed
end

-- Seamless connections have one engine-specific wrinkle: checkEdgeExit only
-- runs when the player is ALREADY facing the edge direction. Autowalk can
-- arrive at a seam immediately after a corner while the vanilla turn-in-place
-- latch is still spent. Give the engine one fixed tick with no synthetic
-- direction held; its ordinary no-direction path re-arms turning. On the next
-- tick we hold the seam direction continuously, allowing vanilla to turn and
-- then cross without first treating the map edge as a wall.
local function prepareConnectionCross(nav)
  if not (nav and nav.cross and not nav.cross.crossed) then return false end
  releaseHold(nav)
  nav.connectionNeutralTick = state.tick
  state.stats.seamNeutralTicks = (state.stats.seamNeutralTicks or 0) + 1
  setPhase(nav, "WAITING_CONNECTION_FACE",
           "neutral_before_" .. tostring(nav.cross.dir))
  return true
end

local function pressConnectionCross(game, nav, cur)
  if not (nav and nav.cross and cur) then return false end
  releaseHold(nav)
  local dir = nav.cross.dir
  local dx, dy = cur.x, cur.y
  if nav.cross.ledgeSeam then
    dx, dy = nav.cross.ledgeMidX, nav.cross.ledgeMidY
  elseif dir == "up" then dy = dy - 1
  elseif dir == "down" then dy = dy + 1
  elseif dir == "left" then dx = dx - 1
  else dx = dx + 1 end
  nav.holdDir = dir
  nav.expectedX, nav.expectedY = dx, dy
  nav.hold = mod.input:press(game, dir)
  nav.lastProgressTick = state.tick
  nav.connectionPressTick = state.tick
  nav.connectionNeutralTick = nil
  setPhase(nav, "CROSSING_CONNECTION", "cross_" .. dir)
  return true
end

-- Last-resort commit for a directional exit that the normal synthetic D-pad
-- press did not trigger.  This is intentionally narrow: the player must be
-- standing on the exact active map warp record, the requested direction must
-- still satisfy the engine-mirrored ExtraWarpCheck rule, and we invoke the
-- overworld's own takeWarp() transition with that SAME record.  No coordinates
-- are written and no destination is invented.
function ControlsFree.commitValidatedExitWarp(game, nav, cur)
  -- Gold transitions remain exclusively movement-driven. Never call takeWarp
  -- or manufacture destination coordinates from the mod.
  if WorldBackend.isGold(game) then return false end
  local ow = game and game.overworld
  local map = ow and ow.map
  if not (ow and map and nav and cur and nav.goalKind == "exit"
      and nav.exitDir and cur.x == nav.targetX and cur.y == nav.targetY
      and type(map.warpAtCell) == "function" and type(ow.takeWarp) == "function") then
    return false
  end
  local w = map:warpAtCell(cur.x, cur.y)
  if not (w and w.def) then return false end
  local intended = nav.exitIntent and nav.exitIntent.warpDef
  if intended and (w.def.destMap ~= intended.destMap
      or w.def.destWarp ~= intended.destWarp) then
    return false
  end
  local dirs = warpActivationDirections(game, map, cur.x, cur.y)
  if not listHas(dirs, nav.exitDir) then return false end
  releaseHold(nav)
  local ok = pcall(ow.takeWarp, ow, w.def)
  if ok then
    nav.exitForcedCommit = true
    nav.lastProgressTick = state.tick
    state.stats.exitWarpForcedCommits =
      (state.stats.exitWarpForcedCommits or 0) + 1
    setPhase(nav, "EXITING_WARP", "forced_commit_" .. tostring(nav.exitDir))
    return true
  end
  return false
end

local function navigationTick(game)
  state.tick = state.tick + 1
  state.game = game

  -- map.entered can fire while world/current, mapOverview, neighbours, Voxel
  -- scene and NPC tables are still converging on the destination. Never run
  -- interaction completion or route work until the public map authorities
  -- agree on the new map.
  if not ControlsFree.mapRuntimeReady(game) then
    return
  end

  processPendingInteraction()

  local nav = state.nav
  if not nav and state.pendingRemoteGoal and ControlsFree.goldNativeForcedDirection(game) then
    -- A gate can drop the player on the same native forced-spawn movement used
    -- by ordinary doors/stairs.  Resume the remote target only after Gold has
    -- physically finished that landing step.
    ControlsFree.releaseSimpleHold()
    return
  end
  if not nav and state.pendingRemoteGoal then
    local resumed, why = ControlsFree.startPendingRemoteGoal(game)
    nav = state.nav
    if resumed == nil then return end
    if not resumed and not nav then
      markStop("portal_remote_" .. tostring(why), nil)
    end
  end
  if not nav and state.exitJourney and ControlsFree.goldNativeForcedDirection(game) then
    -- Gold's PlayerEvents owns currents, ice continuation and the forced DOWN
    -- step after door/stair/cave spawns.  An interior-exit journey can arrive
    -- on one of those cells between legs; let the native move settle before
    -- computing the next floor's route from the real landing coordinate.
    ControlsFree.releaseSimpleHold()
    return
  end
  if not nav and state.exitJourney then
    startExitJourneyLeg(game)
    nav = state.nav
  end
  if not nav then
    tryBattleResume(game)
    nav = state.nav
    if not nav then return end
  end
  if option("enabled", true) == false then
    cancelRoute("disabled")
    return
  end

  local free, gateReason = overworldGate(game)
  if not free then
    if nav.phase == "WAITING_CUT_FLOW" or nav.phase == "WAITING_GOLD_SURF" then return end
    cancelRoute("interrupt_" .. tostring(gateReason))
    return
  end

  if nav.phase == "WAITING_GOLD_SURF" then
    releaseHold(nav)
    if ControlsFree.playerIsSurfing(game) then
      nav.goldSurfStartedTick = nil
      setPhase(nav, "WALKING", "gold_surf_ready")
    elseif state.tick - (nav.goldSurfStartedTick or state.tick) > 600 then
      cancelRoute("gold_surf_timeout")
      return
    else
      return
    end
  end

  local cur = mod.world and mod.world:current()
  if not cur or cur.mapId ~= nav.mapId then
    cancelRoute("map_changed")
    return
  end

  -- Gold consumes a held D-pad continuously. Crucially, on the exact logic
  -- frame a step lands, World:stepBody can immediately start ANOTHER step in
  -- the still-held direction before Tap to Move gets its next input.step hook.
  -- That is harmless on a straight run, but at a corner / final cell it makes
  -- the player overshoot with the OLD direction and the next tick reports
  -- unexpected_movement. Released taps show it most clearly; Hold-to-Steer can
  -- hide it by continuously retargeting.
  --
  -- Pulse ordinary Gold route input one cell at a time: once vanilla has
  -- actually started the step, release our token and wait for the player to
  -- settle on the destination cell before choosing the next route direction.
  -- Turning in place still works because player.moving remains false until the
  -- turnTimer has drained and the step really begins. Connection/warp/forced
  -- phases keep their dedicated held-input semantics below.
  if WorldBackend.isGold(game) and nav.phase == "WALKING" then
    local goldPlayer = WorldBackend.player(game)
    if nav.goldStepPulseWait then
      if goldPlayer and goldPlayer.moving then return end
      nav.goldStepPulseWait = nil
    elseif nav.hold and goldPlayer and goldPlayer.moving then
      releaseHold(nav)
      nav.goldStepPulseWait = true
      state.stats.goldStepPulses = (state.stats.goldStepPulses or 0) + 1
      return
    end
  end

  -- A connected-map seam may itself be the first land -> water edge.
  -- Mount before the crossing input, using the destination overview's real
  -- entry cell rather than guessing from the source shore tile.
  if nav.cross and not nav.cross.crossed
      and cur.x == nav.targetX and cur.y == nav.targetY
      and nav.cross.destOverview and nav.cross.entryX and nav.cross.entryY
      and cellChar(nav.cross.destOverview, nav.cross.entryX, nav.cross.entryY) == "~"
      and not ControlsFree.playerIsSurfing(game) then
    if WorldBackend.isGold(game) then
      cancelRoute("gold_surf_connection_unverified")
      return
    end
    local surfState, surfWhy =
      ControlsFree.prepareSeamlessSurfStep(game, nav, nav.cross.dir)
    if surfState == "waiting" then return end
    if surfState == "failed" then
      cancelRoute("surf_cross_" .. tostring(surfWhy))
      return
    end
  end

  if nav.phase == "WAITING_CUT_FLOW" then
    releaseHold(nav)
    local ow = game and game.overworld
    local wait = nav.cutWait
    if not (ow and wait) then
      cancelRoute("cut_wait_missing")
      return
    end
    if ow.cutAnim then return end
    if state.tick - (wait.startedTick or state.tick) > 600 then
      cancelRoute("cut_flow_timeout")
      return
    end

    local map = ow.map
    local walkable = map and type(map.isWalkableCell) == "function"
      and map:isWalkableCell(wait.x, wait.y) == true
    if not walkable then return end

    ControlsFree.cutGeometryCache[map] = nil
    nav.cutWait = nil
    if wait.direct then
      finishRoute()
      return
    end

    nav.path, nav.index = nil, 1
    nav.lastX, nav.lastY = cur.x, cur.y
    nav.lastProgressTick = state.tick
    local ok, why = rebuildNavigation(game, nav, cur)
    if not ok then
      if why == "dynamic" then
        scheduleDynamicWait(nav, "dynamic_after_cut")
        return
      end
      cancelRoute("post_cut_plan_failed_" .. tostring(why))
      return
    end
    return
  end

  if nav.phase == "WAITING_CONNECTION_FACE" then
    releaseHold(nav)
    local player = WorldBackend.player(game)
    if player and player.moving then return end
    pressConnectionCross(game, nav, cur)
    return
  end

  -- The first seam-direction poll may legitimately be consumed by vanilla's
  -- turn-in-place state. Keep the SAME synthetic direction held on subsequent
  -- fixed ticks until crossConnection/map.entered actually takes over. Without
  -- this guard, arrival detection below would see the unchanged edge cell and
  -- re-enter WAITING_CONNECTION_FACE every tick, repeatedly releasing the
  -- direction before the engine got its second poll to walk across the seam.
  if nav.phase == "CROSSING_CONNECTION"
      and cur.x == nav.targetX and cur.y == nav.targetY then
    if state.tick - (nav.connectionPressTick or state.tick) > 45 then
      cancelRoute("connection_cross_timeout")
      return
    end
    if not holdIsDown(game, nav) then
      releaseHold(nav)
      nav.holdDir = nav.cross and nav.cross.dir or nav.holdDir
      if nav.holdDir then nav.hold = mod.input:press(game, nav.holdDir) end
    end
    return
  end

  if nav.phase == "WAITING_CONNECTION_STEP" then
    releaseHold(nav)
    local player = WorldBackend.player(game)
    if player and player.moving then return end
    if cur.x ~= nav.cross.entryX or cur.y ~= nav.cross.entryY then
      cancelRoute("connection_landing_mismatch")
      return
    end
    nav.lastX, nav.lastY = cur.x, cur.y
    nav.lastProgressTick = state.tick
    nav.path, nav.index = nil, 1

    -- test10 Gold remote routing deliberately re-plans one physical map at a
    -- time.  The map change and landing above are already the engine's real
    -- result; now derive the next seam (or final local A*) from this live map.
    if nav.goldSimpleRemote then
      local advanced, why = ControlsFree.advanceGoldSimpleRemote(game, nav, cur)
      if not advanced then
        if why == "dynamic" then
          scheduleDynamicWait(nav, "dynamic_after_gold_simple_connection")
          return
        end
        cancelRoute("gold_simple_connection_" .. tostring(why))
        return
      end
      return
    end

    -- Legacy remote planner retained for Gen1-compatible/internal paths.
    if nav.remoteGoal and cur.mapId ~= nav.remoteGoal.mapId then
      local advanced, why = ControlsFree.advanceRemoteConnection(game, nav, cur)
      if not advanced then
        state.stats.remoteConnectionRejects =
          (state.stats.remoteConnectionRejects or 0) + 1
        if why == "dynamic" then
          scheduleDynamicWait(nav, "dynamic_after_remote_connection")
          return
        end
        cancelRoute("remote_connection_no_route_" .. tostring(why))
        return
      end
      return
    end

    if nav.crossInteraction then
      nav.interaction = nav.crossInteraction
      nav.crossInteraction = nil
      nav.goalKind = "interact"
    elseif cur.x == nav.targetX and cur.y == nav.targetY then
      finishRoute()
      return
    end
    local ok, why = rebuildNavigation(game, nav, cur)
    if not ok then
      if why == "dynamic" then
        scheduleDynamicWait(nav, "dynamic_after_connection")
        return
      end
      cancelRoute("connection_destination_no_route_" .. tostring(why))
      return
    end
  end

  if nav.phase == "WAITING_PLAYER_STEP" then
    releaseHold(nav)
    if cur.x == nav.pendingStartX and cur.y == nav.pendingStartY then
      nav.pendingStartX, nav.pendingStartY = nil, nil
      nav.lastX, nav.lastY = cur.x, cur.y
      nav.lastProgressTick = state.tick
      if not nav.interaction
          and not (nav.goalKind == "exit" and nav.exitDir)
          and cur.x == nav.targetX and cur.y == nav.targetY then
        finishRoute()
        return
      end
      local ok, why = rebuildNavigation(game, nav, cur)
      if not ok then
        if why == "dynamic" then
          scheduleDynamicWait(nav, "dynamic_after_existing_step")
          return
        end
        cancelRoute("post_step_plan_failed_" .. tostring(why))
        return
      end
    else
      -- The manually initiated step has not landed yet.  A normal player step
      -- is 16 frames (bike 8); this generous bound is only a stuck-state fuse.
      if state.tick - (nav.createdTick or state.tick) > 90 then
        cancelRoute("existing_step_timeout")
      end
      return
    end
  end

  if nav.interaction then
    if state.tick - (nav.createdTick or state.tick) > MAX_INTERACTION_AGE_TICKS then
      cancelRoute("interaction_timeout")
      return
    end
    local ix, iy, _, ierr = interactionTarget(game, nav.interaction)
    if not ix then
      cancelRoute("interaction_target_" .. tostring(ierr or "gone"))
      return
    end
    if ix ~= nav.interaction.targetX or iy ~= nav.interaction.targetY then
      releaseHold(nav)
      nav.interaction.chaseReplan = true
      requestReplan(nav, "interaction_target_moved")
    end
  end

  local _, dynamicNow = liveOccupancy(game)
  cleanupTempBlocks(nav, dynamicNow)

  if cur.x ~= nav.lastX or cur.y ~= nav.lastY then
    -- Cross-map ledges spend one scripted step on the current map's edge tile
    -- before the engine callback performs the seamless connection.  That
    -- midpoint is expected movement even though the normal approach path has
    -- already ended at the ledge's standing cell.
    if nav.phase == "CROSSING_CONNECTION" and nav.cross and nav.cross.ledgeSeam
        and cur.x == nav.cross.ledgeMidX and cur.y == nav.cross.ledgeMidY then
      nav.lastX, nav.lastY = cur.x, cur.y
      nav.lastProgressTick = state.tick
      releaseHold(nav) -- the scripted ledge callback owns the actual crossing
      return
    end

    local oldDir = nav.holdDir
    local matched = advanceAlongKnownPath(nav, cur)
    nav.lastX, nav.lastY = cur.x, cur.y
    nav.lastProgressTick = state.tick
    nav.dynamicWaitStarted = nil

    if not matched then
      cancelRoute("unexpected_movement")
      return
    end

    local nextNode = nav.path and nav.path[nav.index]
    local nextDir = nextNode and directionTo(cur.x, cur.y, nextNode.x, nextNode.y)
    if not nextDir or nextDir ~= oldDir then releaseHold(nav) end
  end

  if nav.phase == "WAITING_DYNAMIC" then
    releaseHold(nav)
    if nav.dynamicWaitStarted
        and state.tick - nav.dynamicWaitStarted > MAX_DYNAMIC_WAIT_TICKS then
      cancelRoute("dynamic_timeout")
      return
    end
    if nav.waitUntil and state.tick < nav.waitUntil then return end

    local ok, why = rebuildNavigation(game, nav, cur)
    if not ok then
      if why == "dynamic" then
        scheduleDynamicWait(nav, "dynamic_still_blocked")
        return
      end
      cancelRoute("replan_failed_" .. tostring(why))
      return
    end
  end

  if nav.needsReplan or nav.phase == "REPLANNING" then
    releaseHold(nav)
    local ok, why = rebuildNavigation(game, nav, cur)
    if not ok then
      if why == "dynamic" then
        scheduleDynamicWait(nav, "dynamic_after_replan")
        return
      end
      cancelRoute("replan_failed_" .. tostring(why))
      return
    end
  end

  if nav.phase == "EXITING_WARP" then
    -- Give vanilla several fixed ticks to consume the synthetic direction.
    -- Some Gen I wall openings only evaluate their special warp during the
    -- landing-frame CheckWarpsNoCollision window; if that window was missed,
    -- commit the exact validated warp record through the engine's own
    -- takeWarp() transition rather than bonking forever.
    local elapsed = state.tick - (nav.exitCommitTick or nav.lastProgressTick or state.tick)
    if elapsed >= 6 and not nav.exitForcedCommit then
      if ControlsFree.commitValidatedExitWarp(game, nav, cur) then return end
    end
    if elapsed > 45 then
      cancelRoute("exit_warp_timeout")
    end
    return
  end

  -- Resolve arrival only after any target-movement/collision replan above.
  -- This is especially important for Tap to Interact: an NPC can move while
  -- the player is standing on the OLD approach cell, and that stale arrival
  -- must not starve the replan forever.
  if cur.x == nav.targetX and cur.y == nav.targetY then
    if nav.cross and not nav.cross.crossed then
      local player = WorldBackend.player(game)
      -- When the user is actively HOLDING and vanilla already faces the seam,
      -- there is nothing to re-arm: begin the connection press on this very
      -- fixed tick. Released taps retain the neutral safety poll, and a held
      -- corner approach whose facing differs still gets that one safe poll to
      -- avoid the engine's edge-bonk turn-latch case.
      if currentWorldPointerHeld() and player
          and player.facing == nav.cross.dir then
        state.stats.seamHeldFastStarts =
          (state.stats.seamHeldFastStarts or 0) + 1
        pressConnectionCross(game, nav, cur)
      else
        prepareConnectionCross(nav)
      end
    elseif nav.interaction then
      interactionAtDestination(game, nav, cur)
    elseif nav.goalKind == "exit" and nav.exitDir then
      -- Gen I interior exit carpets are warp records on ordinary floor cells.
      -- Reaching the record is only half the action; the engine activates it
      -- when the player tries to move out / into the carpet direction.
      releaseHold(nav)
      nav.holdDir = nav.exitDir
      nav.hold = mod.input:press(game, nav.exitDir)
      nav.lastProgressTick = state.tick
      nav.exitCommitTick = state.tick
      nav.exitForcedCommit = nil
      setPhase(nav, "EXITING_WARP", "exit_" .. nav.exitDir)
    else
      finishRoute()
    end
    return
  end

  if nav.phase == "WALKING" and nav.lastProgressTick
      and state.tick - nav.lastProgressTick > NO_PROGRESS_TICKS then
    cancelRoute("no_progress_timeout")
    return
  end

  local nextNode = nav.path and nav.path[nav.index]
  if not nextNode then
    requestReplan(nav, "stale_plan")
    return
  end

  local dir = directionTo(cur.x, cur.y, nextNode.x, nextNode.y)
  if not dir and WorldBackend.isGold(game) and nextNode.forced == "forced" then
    releaseHold(nav)
    nav.forcedWaitStarted = nav.forcedWaitStarted or state.tick
    setPhase(nav, "WAITING_FORCED", "gold_native_forced")
    if state.tick - nav.forcedWaitStarted > 240 then
      requestReplan(nav, "forced_timeout_replan")
    end
    return
  end
  if not dir then
    cancelRoute("non_adjacent_plan")
    return
  end
  if nav.phase == "WAITING_FORCED" then
    nav.forcedWaitStarted = nil
    setPhase(nav, "WALKING", "forced_settled")
  end

  local activeOverview = WorldBackend.overview(game)
  local activeMap = WorldBackend.map(game)
  local player = WorldBackend.player(game)

  -- Seamless Surf must never claim an edge that already belongs to an
  -- exit/warp journey. Some carpet exits can expose terrain classifications
  -- that look water-like to the compact overview, but exit semantics must win.
  local nextWarpIntent = activeMap
    and warpIntentAt(game, activeMap, cur, nextNode.x, nextNode.y) or nil
  local surfOwnsNextEdge = nav.goalKind ~= "exit"
    and nav.exitIntent == nil
    and nav.cross == nil
    and nextWarpIntent == nil

  if surfOwnsNextEdge and activeOverview and player and not ControlsFree.playerIsSurfing(game)
      and cellChar(activeOverview, nextNode.x, nextNode.y) == "~" then
    local surfState, surfWhy =
      ControlsFree.prepareSeamlessSurfStep(game, nav, dir)
    if surfState == "waiting" then return end
    if surfState == "failed" then
      cancelRoute("surf_step_" .. tostring(surfWhy))
      return
    end
    -- Mounted successfully. Continue below on the SAME planned edge; the
    -- actual water entry is still ordinary synthetic D-pad movement.
  end

  if nav.hold and nav.holdDir == dir then
    nav.expectedX, nav.expectedY = nextNode.x, nextNode.y
    -- Input recovery (focus loss, hotplug, resume) retires mod.input tokens.
    -- Verify the direction is genuinely down and acquire a fresh token if not.
    if not holdIsDown(game, nav) then
      releaseHold(nav)
      nav.holdDir = dir
      nav.hold = mod.input:press(game, dir)
    end
    return
  end

  releaseHold(nav)
  nav.expectedX, nav.expectedY = nextNode.x, nextNode.y
  nav.holdDir = dir
  nav.hold = mod.input:press(game, dir)
end

-- Keep a read-only frame description for precise tap -> world-cell mapping.
mod.hooks:wrap("render.compose", function(nextFn, renderer, ctx)
  -- Some mobile pinch implementations deliver the survey-zoom mutation after
  -- the touch callback which identified the gesture. Restore the reserved
  -- pre-gesture zoom immediately before composing the frame as a second line
  -- of defence, so a native pinch cannot visibly leak through for one frame.
  if restoreNativeZoomSuppression and state.game then
    restoreNativeZoomSuppression(state.game)
  end
  captureView(ctx)
  return nextFn()
end)

local function startSelectTouchMode()
  -- SIMPLE TOUCH MOVEMENT owns its own A/B/START gesture set. Do not let the
  -- separate START/SELECT option reserve the same avatar touch or pinch pair.
  if ControlsFree.simpleTouchEnabled and ControlsFree.simpleTouchEnabled() then
    return "off"
  end
  local value = tostring(option("start_select_touch_control", "off") or "off")
  if value == "hold_player_sprite" or value == "pinch_or_spread" then
    return value
  end
  return "off"
end

local function twoFingerFeatureEnabled()
  return startSelectTouchMode() == "pinch_or_spread"
end

local function gestureDistance(a, b)
  if not a or not b then return nil end
  local dx, dy = (a.x or 0) - (b.x or 0), (a.y or 0) - (b.y or 0)
  return math.sqrt(dx * dx + dy * dy)
end

-- Public input.pointer supplies the contacts and mod.input supplies the GB
-- buttons. Zoom is touched only as a compatibility guard: mobile builds can
-- synthesize pinch as zoom/wheel input outside the pointer hook, so a reserved
-- two-finger gesture must be able to veto that one presentation shortcut.
local function zoomModule()
  if state.zoomModule ~= nil then
    return state.zoomModule ~= false and state.zoomModule or nil
  end
  local ok, z = pcall(require, "src.render.Zoom")
  state.zoomModule = ok and z or false
  return ok and z or nil
end

local function nativeZoomSuppressionAlive()
  local z = state.nativeZoomSuppression
  if not z or not z.block then return false end
  if z.rawActive then return true end
  return state.tick <= (z.untilTick or -1)
end

local function captureNativeZoomSuppression(game, forceBlock)
  local existing = state.nativeZoomSuppression
  if existing and (existing.rawActive or state.tick <= (existing.untilTick or -1)) then
    existing.rawActive = true
    existing.untilTick = math.max(existing.untilTick or 0,
                                  state.tick + PINCH_ZOOM_GRACE_TICKS)
    if forceBlock ~= nil then existing.block = forceBlock and true or false end
    return existing
  end

  local z = zoomModule()
  local opts = game and game.save and game.save.options
  local suppression = {
    zoomOffset = z and z.offset or nil,
    zoomOption = opts and opts.zoom or nil,
    rawActive = true,
    untilTick = state.tick + PINCH_ZOOM_GRACE_TICKS,
    block = forceBlock and true or false,
    dirty = false,
  }
  state.nativeZoomSuppression = suppression
  return suppression
end

local function setNativeZoomSuppressionBlock(game, block)
  local suppression = state.nativeZoomSuppression
  if not suppression then
    suppression = captureNativeZoomSuppression(game, block)
  else
    suppression.block = block and true or false
  end
  if suppression.block and restoreNativeZoomSuppression then
    restoreNativeZoomSuppression(game)
  end
end

restoreNativeZoomSuppression = function(game)
  local suppression = state.nativeZoomSuppression
  if not nativeZoomSuppressionAlive() then
    if suppression and not suppression.rawActive
        and state.tick > (suppression.untilTick or -1) then
      state.nativeZoomSuppression = nil
    end
    return false
  end

  local changed = false
  local z = zoomModule()
  if z and suppression.zoomOffset ~= nil and z.offset ~= suppression.zoomOffset then
    z.offset = suppression.zoomOffset
    changed = true
  end
  local opts = game and game.save and game.save.options
  if opts and suppression.zoomOption ~= nil and opts.zoom ~= suppression.zoomOption then
    opts.zoom = suppression.zoomOption
    changed = true
  end
  if changed then
    suppression.dirty = true
    state.stats.pinchZoomSuppressed =
      (state.stats.pinchZoomSuppressed or 0) + 1
  end
  return changed
end

local function installZoomGestureGuard(game)
  if state.zoomGuardInstalled or not game or type(game.zoomStep) ~= "function" then
    return
  end
  local original = game.zoomStep
  state.zoomGuardOriginal = original
  game.zoomStep = function(self, delta)
    if nativeZoomSuppressionAlive() then
      state.stats.pinchZoomSuppressed =
        (state.stats.pinchZoomSuppressed or 0) + 1
      return
    end
    local gesture = state.twoFingerGesture
    if gesture and gesture.blockZoom then
      state.stats.pinchZoomSuppressed =
        (state.stats.pinchZoomSuppressed or 0) + 1
      return
    end
    return original(self, delta)
  end
  state.zoomGuardInstalled = true
end

local function captureGestureZoom(game, gesture)
  if not gesture then return end
  -- Raw touch tracking captures the baseline before TouchControls and before
  -- input.pointer. Reuse that earlier baseline when available, otherwise fall
  -- back to the historical per-gesture snapshot.
  local suppression = state.nativeZoomSuppression
  if suppression then
    gesture.zoomOffset = suppression.zoomOffset
    gesture.zoomOption = suppression.zoomOption
    return
  end
  local z = zoomModule()
  gesture.zoomOffset = z and z.offset or nil
  gesture.zoomOption = game and game.save and game.save.options
      and game.save.options.zoom or nil
end

local function restoreGestureZoom(game, gesture)
  if not gesture or not gesture.blockZoom then return false end
  local changed = false
  -- Prefer the raw-touch baseline because it is captured before any native
  -- touch consumer can mutate survey zoom.
  if state.nativeZoomSuppression then
    setNativeZoomSuppressionBlock(game, true)
    changed = restoreNativeZoomSuppression(game) or changed
  else
    local z = zoomModule()
    if z and gesture.zoomOffset ~= nil and z.offset ~= gesture.zoomOffset then
      z.offset = gesture.zoomOffset
      changed = true
    end
    local opts = game and game.save and game.save.options
    if opts and gesture.zoomOption ~= nil and opts.zoom ~= gesture.zoomOption then
      opts.zoom = gesture.zoomOption
      changed = true
    end
  end
  if changed then gesture.zoomDirty = true end
  return changed
end

local function rawTouchCount()
  local count = 0
  for _ in pairs(state.rawZoomTouches or {}) do count = count + 1 end
  return count
end

local function rawGestureIds()
  local ids = {}
  for id in pairs(state.rawZoomTouches or {}) do ids[#ids + 1] = id end
  table.sort(ids, function(a, b) return tostring(a) < tostring(b) end)
  return ids
end

local function suppressRawGesturePointer(id)
  local p = id and state.pointers[id]
  if not p then return end
  p.gestureSuppressed = "two_finger_gesture"
  p.manualSuppressed = true
  p.ignored = true
end

-- Raw game touches are the authoritative mobile gesture stream.  They arrive
-- before TouchControls gets first refusal, which matters because the second
-- finger may land over a virtual control and therefore never reach
-- input.pointer.  v1.2.2 already used this layer to suppress native zoom; from
-- v1.2.3 the START/SELECT remaps use the same exact contact pair as well.
local function beginRawTwoFingerGesture(game)
  if state.twoFingerGesture or not twoFingerFeatureEnabled() then return false end
  local ids = rawGestureIds()
  if #ids < 2 then return false end
  local a, b = state.rawZoomTouches[ids[1]], state.rawZoomTouches[ids[2]]
  local dist = gestureDistance(a, b)
  if not dist then return false end

  local gesture = {
    id1 = ids[1], id2 = ids[2], startDistance = dist, lastDistance = dist,
    direction = nil, fired = false, ended = false, blockZoom = true,
    raw = true,
  }
  state.twoFingerGesture = gesture
  captureGestureZoom(game, gesture)
  suppressRawGesturePointer(gesture.id1)
  suppressRawGesturePointer(gesture.id2)
  for _, gid in ipairs({ gesture.id1, gesture.id2 }) do
    local dt = state.dialogTouches and state.dialogTouches[gid]
    if dt then
      if dt.bFired then gesture.actionSuppressed = true end
      dt.suppressed = true
    end
    local bt = state.battleTouches and state.battleTouches[gid]
    if bt then
      if bt.bFired then gesture.actionSuppressed = true end
      bt.suppressed = true
    end
    local ph = state.playerHoldTouches and state.playerHoldTouches[gid]
    if ph then ph.cancelled = true; ph.cancelReason = "two_finger" end
    -- A bottom-edge reservation may have swallowed the first finger before
    -- input.pointer. Once a true two-finger gesture owns that contact, keep
    -- the reservation swallowed through release so it cannot replay a stray
    -- tap after START/SELECT fires.
    local edge = state.systemEdgeTouches and state.systemEdgeTouches[gid]
    if edge then edge.systemGesture = true; edge.twoFingerSuppressed = true end
    -- The first overworld finger may still be inside the short pairing grace
    -- window and therefore has not reached Tap to Move at all. Claim it now so
    -- its later release can never replay a single-touch route underneath the
    -- two-finger START/SELECT gesture.
    local grace = state.pinchGraceTouches and state.pinchGraceTouches[gid]
    if grace then
      grace.suppressed = true
      grace.suppressReason = "two_finger_gesture"
    end
  end
  state.stats.pinchGracePairsClaimed =
    (state.stats.pinchGracePairsClaimed or 0) + 1
  if state.nav then cancelRoute("two_finger_gesture") end
  state.stats.twoFingerGestures = (state.stats.twoFingerGestures or 0) + 1
  return true
end

local function classifyRawTwoFingerGesture(game)
  local gesture = state.twoFingerGesture
  if not gesture or not gesture.raw or gesture.ended or gesture.direction then return end
  local a = state.rawZoomTouches and state.rawZoomTouches[gesture.id1]
  local b = state.rawZoomTouches and state.rawZoomTouches[gesture.id2]
  local dist = gestureDistance(a, b)
  if not dist then return end
  gesture.lastDistance = dist
  local threshold = math.max(TWO_FINGER_TRIGGER_UNITS,
                             (gesture.startDistance or dist) * TWO_FINGER_TRIGGER_RATIO)
  local delta = dist - (gesture.startDistance or dist)
  if math.abs(delta) < threshold then
    restoreGestureZoom(game, gesture)
    return
  end

  local direction = delta > 0 and "spread" or "pinch"
  gesture.direction = direction
  -- PINCH OR SPREAD owns the complete two-finger gesture. While selected,
  -- native pinch/spread zoom is disabled and the classified gesture is mapped
  -- directly to the corresponding Game Boy button.
  gesture.blockZoom = twoFingerFeatureEnabled()
  if state.nativeZoomSuppression then
    setNativeZoomSuppressionBlock(game, gesture.blockZoom)
  end
  if gesture.blockZoom then restoreGestureZoom(game, gesture) end

  if not gesture.actionSuppressed
      and twoFingerFeatureEnabled() and direction == "spread" then
    mod.input:tap(game, "start")
    gesture.fired = true
    state.stats.gestureStartTriggers =
      (state.stats.gestureStartTriggers or 0) + 1
  elseif not gesture.actionSuppressed
      and twoFingerFeatureEnabled() and direction == "pinch" then
    mod.input:tap(game, "select")
    gesture.fired = true
    state.stats.gestureSelectTriggers =
      (state.stats.gestureSelectTriggers or 0) + 1
  end
end

local function finishRawTwoFingerGesture(game, id)
  local gesture = state.twoFingerGesture
  if not gesture or not gesture.raw
      or (id ~= gesture.id1 and id ~= gesture.id2) then return end
  gesture.ended = true
  restoreGestureZoom(game, gesture)
  -- Raw zoom suppression deliberately outlives the contact pair.  Do not clear
  -- it here: delayed native pinch callbacks are still blocked by the grace
  -- latch established in noteRawTouchReleased.
  gesture.blockZoom = false
end

local function maybeClearRawTwoFingerGesture(game)
  local gesture = state.twoFingerGesture
  if not gesture or not gesture.raw then return end
  if state.rawZoomTouches[gesture.id1] or state.rawZoomTouches[gesture.id2] then
    return
  end
  local suppression = state.nativeZoomSuppression
  if (gesture.zoomDirty or (suppression and suppression.dirty))
      and game and type(game.writeOptions) == "function" then
    pcall(function() game:writeOptions() end)
    if suppression then suppression.dirty = false end
  end
  state.twoFingerGesture = nil
end

local function noteRawTouchPressed(game, id, x, y)
  if id == nil or id == "mouse" then return end
  state.rawZoomTouches = state.rawZoomTouches or {}
  state.rawZoomTouches[id] = { x = x, y = y }
  if rawTouchCount() >= 2 and twoFingerFeatureEnabled() then
    installZoomGestureGuard(game)
    -- Before the direction is classified we reserve zoom provisionally, which
    -- matches the original behaviour of the remap recognizer. PINCH OR
    -- SPREAD therefore blocks native zoom immediately from second-finger down.
    captureNativeZoomSuppression(game, true)
    restoreNativeZoomSuppression(game)
    beginRawTwoFingerGesture(game)
    local gesture = state.twoFingerGesture
    if gesture and gesture.raw then
      suppressRawGesturePointer(gesture.id1)
      suppressRawGesturePointer(gesture.id2)
    end
  end
end

local function noteRawTouchMoved(game, id, x, y)
  local t = state.rawZoomTouches and state.rawZoomTouches[id]
  if not t then return end
  t.x, t.y = x, y
  local suppression = state.nativeZoomSuppression
  if suppression and rawTouchCount() >= 2 then
    suppression.rawActive = true
    suppression.untilTick = state.tick + PINCH_ZOOM_GRACE_TICKS
    restoreNativeZoomSuppression(game)
  end
  local gesture = state.twoFingerGesture
  if gesture and gesture.raw then
    suppressRawGesturePointer(gesture.id1)
    suppressRawGesturePointer(gesture.id2)
    classifyRawTwoFingerGesture(game)
    restoreGestureZoom(game, gesture)
  end
end

local function noteRawTouchReleased(game, id)
  if not (state.rawZoomTouches and state.rawZoomTouches[id]) then return end
  finishRawTwoFingerGesture(game, id)
  state.rawZoomTouches[id] = nil
  local suppression = state.nativeZoomSuppression
  if suppression and rawTouchCount() < 2 then
    suppression.rawActive = false
    suppression.untilTick = state.tick + PINCH_ZOOM_GRACE_TICKS
    restoreNativeZoomSuppression(game)
  end
  maybeClearRawTwoFingerGesture(game)
end

local function installRawPinchZoomGuard(game)
  if state.rawZoomGuardInstalled or not game then return false end
  if type(game.touchpressed) ~= "function" or type(game.touchmoved) ~= "function"
      or type(game.touchreleased) ~= "function" then
    return false
  end

  installZoomGestureGuard(game)
  local pressed, moved, released = game.touchpressed, game.touchmoved, game.touchreleased
  state.rawZoomGuardOriginal = {
    touchpressed = pressed, touchmoved = moved, touchreleased = released,
  }

  -- Everything below the bottom-edge reservation goes through these three
  -- dispatchers. This lets a reserved contact be replayed into the SAME
  -- dialogue/battle/player-hold/native path once we know it was not an OS
  -- navigation swipe, without re-entering raw two-finger tracking twice.
  local function dispatchPress(self, id, x, y, dx, dy, pressure)
    state.rawDispatchedTouches = state.rawDispatchedTouches or {}
    state.rawDispatchedTouches[id] = true
    local battleOwned = id ~= nil and id ~= "mouse"
        and ControlsFree.battleTouchFeatureEnabled(self)
    if battleOwned then
      state.battleCameraOwnedTouches = state.battleCameraOwnedTouches or {}
      state.battleCameraOwnedTouches[id] = true
      state.stats.battleCameraTouchesSuppressed =
        (state.stats.battleCameraTouchesSuppressed or 0) + 1
    end

    if state.dialogTouches and state.dialogTouches[id] then return true end
    if state.battleTouches and state.battleTouches[id] then return true end
    if not state.twoFingerGesture and ControlsFree.beginDialogTouch(self, id, x, y) then
      return true
    end
    if not state.twoFingerGesture and ControlsFree.beginBattleTouch(self, id, x, y) then
      return true
    end

    if not (state.playerHoldTouches and state.playerHoldTouches[id]) then
      ControlsFree.beginPlayerHoldTouch(self, id, x, y)
    end
    if battleOwned then return true end
    return pressed(self, id, x, y, dx, dy, pressure)
  end

  local function dispatchMove(self, id, x, y, dx, dy, pressure)
    if ControlsFree.moveDialogTouch(id, x, y) then return true end
    if ControlsFree.moveBattleTouch(id, x, y) then return true end
    ControlsFree.movePlayerHoldTouch(id, x, y)
    if state.battleCameraOwnedTouches and state.battleCameraOwnedTouches[id] then
      return true
    end
    return moved(self, id, x, y, dx, dy, pressure)
  end

  local function dispatchRelease(self, id, x, y, dx, dy, pressure)
    if state.rawDispatchedTouches then state.rawDispatchedTouches[id] = nil end
    local battleOwned = state.battleCameraOwnedTouches
        and state.battleCameraOwnedTouches[id] == true

    if state.dialogTouches and state.dialogTouches[id] then
      ControlsFree.finishDialogTouch(self, id, x, y, false)
      if state.battleCameraOwnedTouches then state.battleCameraOwnedTouches[id] = nil end
      ControlsFree.finishPlayerHoldTouch(id)
      return true
    end
    if state.battleTouches and state.battleTouches[id] then
      ControlsFree.finishBattleTouch(self, id, x, y, false)
      if state.battleCameraOwnedTouches then state.battleCameraOwnedTouches[id] = nil end
      ControlsFree.finishPlayerHoldTouch(id)
      return true
    end

    if battleOwned then
      state.battleCameraOwnedTouches[id] = nil
      ControlsFree.finishPlayerHoldTouch(id)
      return true
    end

    local result = released(self, id, x, y, dx, dy, pressure)
    ControlsFree.finishPlayerHoldTouch(id)
    return result
  end

  -- Expose only these already-sanitized dispatch closures to the fixed-step
  -- grace promoter. They bypass THIS raw wrapper (so raw gesture bookkeeping
  -- is not counted twice) but still flow through TouchControls + input.pointer
  -- exactly as a normal single touch would have.
  state.rawTouchDispatchPress = dispatchPress
  state.rawTouchDispatchMove = dispatchMove
  state.rawTouchDispatchRelease = dispatchRelease

  game.touchpressed = function(self, id, x, y, dx, dy, pressure)
    -- The persistent top-right stock-controls toggle sits above every game/UI
    -- state and gets absolute first refusal, even while the native controls
    -- themselves are hidden.
    if id ~= nil and id ~= "mouse" and ControlsFree.nativeControlsToggleHit(x, y) then
      state.nativeControlsToggleTouches = state.nativeControlsToggleTouches or {}
      state.nativeControlsToggleTouches[id] = { startX = x, startY = y, x = x, y = y }
      return true
    end
    -- A lifecycle interruption can swallow the previous release. Any NEW press
    -- with the same host touch id is authoritative and retires stale ownership.
    if state.nativeControlOwnedTouches then state.nativeControlOwnedTouches[id] = nil end

    -- Absolute priority for Gen1Recomp's visible virtual controls. Ownership is
    -- decided only at touch-DOWN: a finger that starts on A/B/D-pad/START/SELECT
    -- bypasses every Tap-to-Move/dialog/battle/pinch/system-edge classifier and
    -- rides the native TouchControls lifecycle unchanged. A world finger that
    -- merely crosses over a control later remains a world/hold gesture.
    if id ~= nil and id ~= "mouse" and ControlsFree.rawTouchControlHit(self, x, y) then
      state.nativeControlOwnedTouches = state.nativeControlOwnedTouches or {}
      state.nativeControlOwnedTouches[id] = true
      state.stats.nativeControlTouchesBypassed =
        (state.stats.nativeControlTouchesBypassed or 0) + 1
      return pressed(self, id, x, y, dx, dy, pressure)
    end

    noteRawTouchPressed(self, id, x, y)

    -- The second finger can create the raw gesture before it ever reaches
    -- TouchControls/input.pointer. Once that happens, neither participant may
    -- leak a synthetic single-touch press into gameplay.
    local rawGesture = state.twoFingerGesture
    if rawGesture and rawGesture.raw
        and (id == rawGesture.id1 or id == rawGesture.id2) then
      restoreNativeZoomSuppression(self)
      return true
    end

    -- Reserve bottom-edge WORLD contacts before input.pointer. Visible native
    -- controls have already bypassed the mod above, and systemEdgeGuardEnabled
    -- limits this reservation to the bare overworld, so this suppresses only a
    -- possible false Tap-to-Move command rather than disabling app controls.
    if ControlsFree.beginSystemEdgeTouch(self, id, x, y) then
      -- Preserve HOLD PLAYER SPRITE: the edge guard suppresses only world
      -- movement. A stationary avatar hold may still intentionally fire START.
      ControlsFree.beginPlayerHoldTouch(self, id, x, y)
      restoreNativeZoomSuppression(self)
      return true
    end

    -- PINCH OR SPREAD needs a short first-finger pairing window on the free
    -- overworld. Tap to Move used to act on press immediately, so a human
    -- placing finger #2 a few frames later could get one walking step plus
    -- START/SELECT. During this grace the first touch is not forwarded at all.
    if ControlsFree.beginPinchGraceTouch(self, id, x, y, dx, dy, pressure) then
      restoreNativeZoomSuppression(self)
      return true
    end

    local result = dispatchPress(self, id, x, y, dx, dy, pressure)
    restoreNativeZoomSuppression(self)
    return result
  end

  game.touchmoved = function(self, id, x, y, dx, dy, pressure)
    local toggleTouch = state.nativeControlsToggleTouches and state.nativeControlsToggleTouches[id]
    if toggleTouch then
      toggleTouch.x, toggleTouch.y = x, y
      local ddx, ddy = x - toggleTouch.startX, y - toggleTouch.startY
      local slop = ControlsFree.NATIVE_CONTROLS_TOGGLE_SLOP * 1.5
      if ddx * ddx + ddy * ddy > slop * slop then toggleTouch.cancelled = true end
      return true
    end
    if state.nativeControlOwnedTouches and state.nativeControlOwnedTouches[id] then
      return moved(self, id, x, y, dx, dy, pressure)
    end

    noteRawTouchMoved(self, id, x, y)

    local rawGesture = state.twoFingerGesture
    if rawGesture and rawGesture.raw
        and (id == rawGesture.id1 or id == rawGesture.id2) then
      ControlsFree.movePinchGraceTouch(id, x, y, dx, dy, pressure)
      restoreNativeZoomSuppression(self)
      return true
    end

    if ControlsFree.movePinchGraceTouch(id, x, y, dx, dy, pressure) then
      restoreNativeZoomSuppression(self)
      return true
    end

    local edgeStatus = state.systemEdgeTouches and state.systemEdgeTouches[id]
        and "pending" or nil
    if edgeStatus then
      edgeStatus = ControlsFree.moveSystemEdgeTouch(self, id, x, y)
      ControlsFree.movePlayerHoldTouch(id, x, y)
      if edgeStatus == "promote" then
        local edge = state.systemEdgeTouches[id]
        state.systemEdgeTouches[id] = nil
        dispatchPress(self, id, edge.startX, edge.startY, 0, 0, pressure)
        local result = dispatchMove(self, id, x, y, dx, dy, pressure)
        restoreNativeZoomSuppression(self)
        return result
      end
      restoreNativeZoomSuppression(self)
      return true
    end

    local result = dispatchMove(self, id, x, y, dx, dy, pressure)
    restoreNativeZoomSuppression(self)
    return result
  end

  game.touchreleased = function(self, id, x, y, dx, dy, pressure)
    local toggleTouch = state.nativeControlsToggleTouches and state.nativeControlsToggleTouches[id]
    if toggleTouch then
      state.nativeControlsToggleTouches[id] = nil
      if not toggleTouch.cancelled and ControlsFree.nativeControlsToggleHit(x, y) then
        ControlsFree.toggleNativeControls(self)
      end
      return true
    end
    if state.nativeControlOwnedTouches and state.nativeControlOwnedTouches[id] then
      -- Keep the ownership flag set while the original Game path calls the
      -- TouchControls fallback wrapper, so that wrapper can forward the native
      -- release instead of mistaking it for battle-camera suppression.
      local result = released(self, id, x, y, dx, dy, pressure)
      state.nativeControlOwnedTouches[id] = nil
      return result
    end

    local rawGesture = state.twoFingerGesture
    if rawGesture and rawGesture.raw
        and (id == rawGesture.id1 or id == rawGesture.id2) then
      if state.pinchGraceTouches then state.pinchGraceTouches[id] = nil end
      -- If this finger had already left the grace window before finger #2
      -- arrived, it owns a real Game/TouchControls press that still requires
      -- its matching release for cleanup. Gesture suppression above guarantees
      -- that this release cannot start another route or A/D-pad action.
      if state.rawDispatchedTouches and state.rawDispatchedTouches[id] then
        dispatchRelease(self, id, x, y, dx, dy, pressure)
      else
        -- Grace/system-edge contacts were never sent into Game. Retire any
        -- provisional classifier state directly instead of manufacturing a
        -- release for a press that never existed.
        if state.systemEdgeTouches then state.systemEdgeTouches[id] = nil end
        if state.dialogTouches then state.dialogTouches[id] = nil end
        if state.battleTouches then state.battleTouches[id] = nil end
        ControlsFree.finishPlayerHoldTouch(id)
      end
      noteRawTouchReleased(self, id)
      restoreNativeZoomSuppression(self)
      return true
    end

    local grace = state.pinchGraceTouches and state.pinchGraceTouches[id]
    if grace then
      state.pinchGraceTouches[id] = nil
      local result
      if not grace.suppressed then
        -- A quick ordinary tap can end before the 0.20 s timer. Replay press +
        -- release now; this preserves normal Tap to Move semantics while still
        -- guaranteeing there was no press-time movement available to a pinch.
        dispatchPress(self, id, grace.startX, grace.startY, 0, 0, grace.pressure)
        result = dispatchRelease(self, id, x, y, dx, dy, pressure)
        state.stats.pinchGraceReleaseReplays =
          (state.stats.pinchGraceReleaseReplays or 0) + 1
      else
        result = true
      end
      noteRawTouchReleased(self, id)
      restoreNativeZoomSuppression(self)
      return result
    end

    local edge = state.systemEdgeTouches and state.systemEdgeTouches[id]
    if edge then
      local edgeStatus = ControlsFree.moveSystemEdgeTouch(self, id, x, y)
      edge = state.systemEdgeTouches[id]
      state.systemEdgeTouches[id] = nil
      local ph = state.playerHoldTouches and state.playerHoldTouches[id]

      if edgeStatus == "system" or (ph and ph.fired) then
        noteRawTouchReleased(self, id)
        ControlsFree.finishPlayerHoldTouch(id)
        restoreNativeZoomSuppression(self)
        return true
      end

      -- It was merely a tap/other gesture that happened to START near the
      -- system edge. Replay the deferred press at its original point, then
      -- release at the real endpoint so normal A/swipe/navigation semantics
      -- are preserved without any press-time false movement.
      dispatchPress(self, id, edge.startX, edge.startY, 0, 0, pressure)
      local result = dispatchRelease(self, id, x, y, dx, dy, pressure)
      noteRawTouchReleased(self, id)
      restoreNativeZoomSuppression(self)
      return result
    end

    local result = dispatchRelease(self, id, x, y, dx, dy, pressure)
    noteRawTouchReleased(self, id)
    restoreNativeZoomSuppression(self)
    return result
  end

  state.rawZoomGuardInstalled = true
  return true
end

local function suppressGesturePointer(id)
  local p = id and state.pointers[id]
  if not p then return end
  p.gestureSuppressed = "two_finger_gesture"
  p.manualSuppressed = true
end

local function beginTwoFingerGesture(game)
  if state.twoFingerGesture or not twoFingerFeatureEnabled() then return false end
  local ids = {}
  for id in pairs(state.gestureTouches or {}) do ids[#ids + 1] = id end
  if #ids < 2 then return false end
  table.sort(ids, function(a, b) return tostring(a) < tostring(b) end)
  local a, b = state.gestureTouches[ids[1]], state.gestureTouches[ids[2]]
  local dist = gestureDistance(a, b)
  if not dist then return false end

  installZoomGestureGuard(game)
  local gesture = {
    id1 = ids[1], id2 = ids[2], startDistance = dist, lastDistance = dist,
    direction = nil, fired = false, ended = false, blockZoom = true,
  }
  state.twoFingerGesture = gesture
  captureGestureZoom(game, gesture)
  suppressGesturePointer(gesture.id1)
  suppressGesturePointer(gesture.id2)
  if state.nav then cancelRoute("two_finger_gesture") end
  state.stats.twoFingerGestures = (state.stats.twoFingerGestures or 0) + 1
  return true
end

local function classifyTwoFingerGesture(game)
  local gesture = state.twoFingerGesture
  if not gesture or gesture.ended or gesture.direction then return end
  local a = state.gestureTouches[gesture.id1]
  local b = state.gestureTouches[gesture.id2]
  local dist = gestureDistance(a, b)
  if not dist then return end
  gesture.lastDistance = dist
  local threshold = math.max(TWO_FINGER_TRIGGER_UNITS,
                             (gesture.startDistance or dist) * TWO_FINGER_TRIGGER_RATIO)
  local delta = dist - (gesture.startDistance or dist)
  if math.abs(delta) < threshold then
    restoreGestureZoom(game, gesture)
    return
  end

  local direction = delta > 0 and "spread" or "pinch"
  gesture.direction = direction
  -- PINCH OR SPREAD owns the complete two-finger gesture. While selected,
  -- native pinch/spread zoom is disabled and the classified gesture is mapped
  -- directly to the corresponding Game Boy button.
  gesture.blockZoom = twoFingerFeatureEnabled()
  if state.nativeZoomSuppression then
    setNativeZoomSuppressionBlock(game, gesture.blockZoom)
  end
  if gesture.blockZoom then restoreGestureZoom(game, gesture) end

  if twoFingerFeatureEnabled() and direction == "spread" then
    mod.input:tap(game, "start")
    gesture.fired = true
    state.stats.gestureStartTriggers =
      (state.stats.gestureStartTriggers or 0) + 1
  elseif twoFingerFeatureEnabled() and direction == "pinch" then
    mod.input:tap(game, "select")
    gesture.fired = true
    state.stats.gestureSelectTriggers =
      (state.stats.gestureSelectTriggers or 0) + 1
  end
end

local function finishTwoFingerGesture(game, id)
  local gesture = state.twoFingerGesture
  if not gesture or (id ~= gesture.id1 and id ~= gesture.id2) then return end
  gesture.ended = true
  restoreGestureZoom(game, gesture)
  -- Do not drop the raw suppression latch here. Some platforms deliver the
  -- actual survey-zoom command after the touch release. raw touch tracking
  -- keeps the captured baseline alive for PINCH_ZOOM_GRACE_TICKS.
  gesture.blockZoom = false
end

local function maybeClearTwoFingerGesture(game)
  local gesture = state.twoFingerGesture
  if not gesture then return end
  if state.gestureTouches[gesture.id1] or state.gestureTouches[gesture.id2] then
    return
  end
  local suppression = state.nativeZoomSuppression
  if (gesture.zoomDirty or (suppression and suppression.dirty))
      and game and type(game.writeOptions) == "function" then
    pcall(function() game:writeOptions() end)
    if suppression then suppression.dirty = false end
  end
  state.twoFingerGesture = nil
end

local function trackTwoFingerPointer(game, ev)
  if not ev or ev.source ~= "touch" then return end
  -- Real mobile touches are already classified at Game:touch* before
  -- TouchControls can swallow either contact. Keep input.pointer only as a
  -- compatibility fallback if that raw bridge could not be installed.
  if state.rawZoomGuardInstalled then return end
  if not twoFingerFeatureEnabled() and not state.twoFingerGesture then return end
  state.gestureTouches = state.gestureTouches or {}
  local id = ev.id
  if ev.phase == "pressed" then
    state.gestureTouches[id] = { x = ev.x, y = ev.y }
    if state.twoFingerGesture then
      suppressGesturePointer(id)
    else
      beginTwoFingerGesture(game)
    end
  elseif ev.phase == "moved" then
    local t = state.gestureTouches[id]
    if t then t.x, t.y = ev.x, ev.y end
    if state.twoFingerGesture then
      suppressGesturePointer(id)
      classifyTwoFingerGesture(game)
      restoreGestureZoom(game, state.twoFingerGesture)
    end
  elseif ev.phase == "released" or ev.phase == "cancelled" then
    finishTwoFingerGesture(game, id)
    state.gestureTouches[id] = nil
    maybeClearTwoFingerGesture(game)
  end
end

-- Exact dialogue recognition. TextBox exposes isTextBox on its class, so this
-- does not guess from screen geometry or overworld lock state. An anchored
-- YES/NO ChoiceBox is also part of dialogue when a TextBox is immediately
-- underneath it on the stack.
function ControlsFree.dialogueActive(game)
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" then return false end
  local ok, top = pcall(stack.top, stack)
  if not ok or not top then return false end
  if top.isTextBox == true then return true end
  local states = stack.states
  if top.anchor == "bottom" and type(states) == "table" and #states >= 2 then
    local under = states[#states - 1]
    if under and under.isTextBox == true then return true end
  end
  return false
end

function ControlsFree.hostOS()
  -- Do not touch the LÖVE system module from a mod chunk: Gen1Recomp v0.1.84+ blocks the
  -- whole module in the mod sandbox. The engine's Platform module is the
  -- canonical compatibility boundary and is safe to query through the
  -- engine_internals permission this mod already needs for Gold/TILT support.
  if ControlsFree.hostOSCache ~= nil then
    return ControlsFree.hostOSCache or nil
  end
  local okPlatform, Platform = pcall(require, "src.core.Platform")
  if okPlatform and type(Platform) == "table" and type(Platform.detect) == "function" then
    local okDetect, info = pcall(Platform.detect)
    local name = okDetect and type(info) == "table" and info.os or nil
    if type(name) == "string" and name ~= "" then
      ControlsFree.hostOSCache = name
      return name
    end
  end
  -- Preserve the old graceful-degradation semantics if an older/future host
  -- does not expose Platform: mobile-only shortcuts stay off, while explicit
  -- mouse-source shortcuts remain usable through desktopHost().
  ControlsFree.hostOSCache = false
  return nil
end

function ControlsFree.mobileHost()
  local osName = ControlsFree.hostOS()
  return osName == "Android" or osName == "iOS"
end

function ControlsFree.desktopHost()
  local osName = ControlsFree.hostOS()
  return osName ~= "Android" and osName ~= "iOS" and osName ~= "NX"
end

-- PINCH OR SPREAD uses raw Game:touch* input so it can see both contacts before
-- TouchControls or input.pointer consume them. The first overworld finger is
-- therefore held briefly in a pairing grace window. This prevents the classic
-- race where Tap to Move starts walking on finger #1 and finger #2 then turns
-- the same physical gesture into START/SELECT.
function ControlsFree.rawTouchControlHit(game, x, y)
  local tc = game and game.touchControls
  if type(tc) ~= "table" or type(tc.hitTest) ~= "function" then return false end
  if type(tc.visible) == "function" then
    local okVisible, visible = pcall(tc.visible, tc)
    if okVisible and not visible then return false end
  end
  local ok, hit = pcall(tc.hitTest, tc, x, y)
  return ok and hit ~= nil
end

function ControlsFree.beginPinchGraceTouch(game, id, x, y, dx, dy, pressure)
  if id == nil or id == "mouse" or not ControlsFree.mobileHost()
      or not twoFingerFeatureEnabled() or state.twoFingerGesture
      or rawTouchCount() ~= 1 then
    return false
  end
  local free = overworldGate(game)
  if not free then return false end
  -- Do not add latency to the visible virtual D-pad/A/B/etc. Pinch tolerance is
  -- specifically for the world surface where Tap to Move would otherwise act
  -- immediately on the first finger.
  if ControlsFree.rawTouchControlHit(game, x, y) then return false end

  state.pinchGraceTouches = state.pinchGraceTouches or {}
  state.pinchGraceTouches[id] = {
    startX = x, startY = y, x = x, y = y,
    dx = dx or 0, dy = dy or 0, pressure = pressure,
    startedTick = state.tick, suppressed = false,
  }
  state.stats.pinchGraceCandidates = (state.stats.pinchGraceCandidates or 0) + 1
  return true
end

function ControlsFree.movePinchGraceTouch(id, x, y, dx, dy, pressure)
  local t = state.pinchGraceTouches and state.pinchGraceTouches[id]
  if not t then return false end
  t.x, t.y = x, y
  t.dx, t.dy = dx or t.dx or 0, dy or t.dy or 0
  if pressure ~= nil then t.pressure = pressure end
  return true
end

function ControlsFree.promotePinchGraceTouches(game)
  if not state.pinchGraceTouches or next(state.pinchGraceTouches) == nil then return end
  local press = state.rawTouchDispatchPress
  local move = state.rawTouchDispatchMove
  if type(press) ~= "function" then return end

  for id, t in pairs(state.pinchGraceTouches) do
    if t.suppressed then
      -- Keep the record until physical release so the raw wrapper knows this
      -- contact must stay swallowed for the whole two-finger gesture.
    elseif state.twoFingerGesture then
      t.suppressed = true
      t.suppressReason = "two_finger_gesture"
    elseif state.tick - (t.startedTick or state.tick) + 1
        >= ControlsFree.PINCH_FIRST_TOUCH_GRACE_TICKS then
      local free = overworldGate(game)
      if not free then
        t.suppressed = true
        t.suppressReason = "overworld_not_free"
      else
        state.pinchGraceTouches[id] = nil
        press(game, id, t.startX, t.startY, 0, 0, t.pressure)
        if type(move) == "function" and (t.x ~= t.startX or t.y ~= t.startY) then
          move(game, id, t.x, t.y, t.x - t.startX, t.y - t.startY, t.pressure)
        end
        state.stats.pinchGracePromotions =
          (state.stats.pinchGracePromotions or 0) + 1
      end
    end
  end
end

function ControlsFree.prunePinchGraceTouches()
  if not state.pinchGraceTouches or next(state.pinchGraceTouches) == nil then return end
  local touch = love and love.touch
  if type(touch) ~= "table" or type(touch.getTouches) ~= "function" then return end
  local ok, ids = pcall(touch.getTouches)
  if not ok or type(ids) ~= "table" then return end
  local active = {}
  for _, id in ipairs(ids) do active[id] = true end
  for id in pairs(state.pinchGraceTouches) do
    if not active[id] then
      state.pinchGraceTouches[id] = nil
      if state.rawZoomTouches then state.rawZoomTouches[id] = nil end
      state.stats.pinchGraceCancelled = (state.stats.pinchGraceCancelled or 0) + 1
    end
  end
end

-- There is no portable LÖVE callback that says "the OS has claimed this touch".
-- Instead, reserve only bare-overworld WORLD touches that START in the phone's
-- bottom system-gesture strip. A strongly upward, vertically dominant move is
-- discarded as a probable OS navigation gesture. Visible native controls are
-- detected earlier and bypass this guard entirely; UI/battle states do not enter
-- it. Other world contacts are promoted back into the normal Gen1Recomp path.
function ControlsFree.systemEdgeGuardEnabled(game)
  -- This guard exists only to prevent a probable phone Home/app-switch swipe
  -- from becoming a Tap-to-Move WORLD command. It must never reserve the
  -- application's own virtual controls or generic UI touches. Native controls
  -- are bypassed before this function is reached; overlays/battles fail the
  -- bare-overworld gate here and keep their normal touch stream.
  local free = overworldGate(game)
  return ControlsFree.mobileHost()
      and option("enabled", true) ~= false
      and free == true
end

function ControlsFree.touchWindowHeight()
  local h = state.frame and tonumber(state.frame.wh) or nil
  if (not h or h <= 0) and love and love.graphics
      and type(love.graphics.getDimensions) == "function" then
    local ok, _, gh = pcall(love.graphics.getDimensions)
    if ok then h = tonumber(gh) end
  end
  return h
end

function ControlsFree.beginSystemEdgeTouch(game, id, x, y)
  if id == nil or id == "mouse" or not ControlsFree.systemEdgeGuardEnabled(game) then
    return false
  end
  local h = ControlsFree.touchWindowHeight()
  if not h or h <= 0 then return false end
  local band = math.max(ControlsFree.SYSTEM_EDGE_START_BAND_MIN_UNITS,
    math.min(ControlsFree.SYSTEM_EDGE_START_BAND_MAX_UNITS,
      h * ControlsFree.SYSTEM_EDGE_START_BAND_RATIO))
  if y < h - band then return false end
  state.systemEdgeTouches = state.systemEdgeTouches or {}
  state.systemEdgeTouches[id] = {
    startX = x, startY = y, x = x, y = y, startedTick = state.tick,
    systemGesture = false,
  }
  state.stats.systemEdgeCandidates = (state.stats.systemEdgeCandidates or 0) + 1
  return true
end

-- Returns nil when this id is not reserved, otherwise "pending", "system"
-- or "promote". Promotion is intentionally conservative: a strong sideways
-- or downward move is clearly not the phone's bottom-up navigation gesture and
-- can be returned to gameplay immediately. Upward-ish motion stays reserved
-- until it either crosses the OS threshold or releases.
function ControlsFree.moveSystemEdgeTouch(game, id, x, y)
  local t = state.systemEdgeTouches and state.systemEdgeTouches[id]
  if not t then return nil end
  t.x, t.y = x, y
  if t.systemGesture then return "system" end
  local dx, dy = x - t.startX, y - t.startY
  local up = -dy
  local side = math.abs(dx)
  if up >= ControlsFree.SYSTEM_EDGE_UP_TRIGGER_UNITS
      and up >= side * ControlsFree.SYSTEM_EDGE_AXIS_RATIO then
    t.systemGesture = true
    local ph = state.playerHoldTouches and state.playerHoldTouches[id]
    if ph then ph.cancelled = true; ph.cancelReason = "system_edge_swipe" end
    state.stats.systemEdgeSwipesSuppressed =
      (state.stats.systemEdgeSwipesSuppressed or 0) + 1
    if state.nav then cancelRoute("system_edge_swipe") end
    return "system"
  end
  if dy >= ControlsFree.SYSTEM_EDGE_UP_TRIGGER_UNITS
      or (side >= ControlsFree.SYSTEM_EDGE_SIDE_ESCAPE_UNITS and side > math.max(0, up)) then
    state.stats.systemEdgeTouchesPromoted =
      (state.stats.systemEdgeTouchesPromoted or 0) + 1
    return "promote"
  end
  return "pending"
end

-- If the host/OS cancels a touch without routing a normal release callback,
-- LÖVE's active-touch list still lets us retire the reservation instead of
-- keeping stale state around. This is intentionally cleanup-only: disappearance
-- is treated as cancellation and never replays gameplay input.
function ControlsFree.pruneSystemEdgeTouches()
  if not state.systemEdgeTouches or next(state.systemEdgeTouches) == nil then return end
  local touch = love and love.touch
  if type(touch) ~= "table" or type(touch.getTouches) ~= "function" then return end
  local ok, ids = pcall(touch.getTouches)
  if not ok or type(ids) ~= "table" then return end
  local active = {}
  for _, id in ipairs(ids) do active[id] = true end
  for id in pairs(state.systemEdgeTouches) do
    if not active[id] then
      state.systemEdgeTouches[id] = nil
      local ph = state.playerHoldTouches and state.playerHoldTouches[id]
      if ph then ph.cancelled = true; ph.cancelReason = "touch_cancelled" end
      ControlsFree.finishPlayerHoldTouch(id)
    end
  end
end

-- DIALOG TOUCH CONTROL is intentionally broader than literal TextBox dialogue.
-- It is the mobile fallback controller for every game UI/state except the two
-- contexts that already have their own touch semantics:
--   * free overworld -> Tap to Move / Hold to Steer
--   * any BattleState in the stack -> BATTLE TOUCH CONTROL / native battle touch
-- This fail-open coverage means newly added menus, choice screens and overlays
-- automatically inherit release-A + swipe D-pad without needing a hard-coded
-- state-name allowlist.
function ControlsFree.stateIsBattle(st)
  if type(st) ~= "table" then return false end
  -- Gen 1 BattleState has carried isBattle=true since the baseline. Gold uses
  -- the generation-specific registry id because its battle screen does not
  -- expose that Gen 1 marker. Avoid a literal Gen 1 screen id so gen2check can
  -- correctly distinguish the two surfaces.
  return st.isBattle == true or st.screenId == "Gen2BattleState"
end

function ControlsFree.dialogTouchSurfaceActive(game)
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" then return false end

  -- A battle remains a battle even when a Party/Item/Choice/TextBox state is
  -- pushed above BattleState. DIALOG TOUCH CONTROL must never steal those.
  local states = stack.states
  if type(states) == "table" then
    for i = #states, 1, -1 do
      local st = states[i]
      if ControlsFree.stateIsBattle(st) then return false end
    end
  end

  local ok, top = pcall(stack.top, stack)
  if not ok or not top then return false end
  if ControlsFree.stateIsBattle(top) then return false end

  -- Only the bare overworld is excluded. Any overlay pushed above it is a UI
  -- surface and is deliberately covered by this catch-all control.
  if game.overworld and top == game.overworld then return false end
  return true
end

function ControlsFree.dialogTouchFeatureEnabled(game)
  return option("dialog_touch_control", false) == true
      and ControlsFree.mobileHost()
      and ControlsFree.dialogTouchSurfaceActive(game)
end


-- A BattleState can be covered by its own message box, choice box, party menu
-- or item screen.  The user is still "in battle" in all of those cases, so
-- inspect the complete state stack instead of only the top state.
function ControlsFree.battleActive(game)
  local stack = game and game.stack
  if not stack then return false end
  local states = stack.states
  if type(states) == "table" then
    for i = #states, 1, -1 do
      local st = states[i]
      if ControlsFree.stateIsBattle(st) then return true end
    end
  end
  if type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and ControlsFree.stateIsBattle(top) then return true end
  end
  return false
end

function ControlsFree.battleTouchFeatureEnabled(game)
  return option("battle_touch_control", false) == true
      and ControlsFree.mobileHost()
      and ControlsFree.battleActive(game)
end

local function voxelCanvasToWindow(voxel3d, p)
  if not p then return nil end
  local scene = VoxelAdapter.discover()
  if scene and scene.voxel3d == voxel3d then
    return VoxelAdapter.canvasToWindow(scene, p[1], p[2])
  end
  return nil
end

-- Hit the visible player rather than merely his world cell.  Flat rendering
-- uses the same live camera transform as tap targeting; Voxel mode projects a
-- short vertical segment through the player's cell so the whole billboard/body
-- is a practical one-second hold target, not only the feet pixel.
function ControlsFree.playerScreenHit(game, x, y)
  -- Hit-testing the avatar is useful beyond HOLD PLAYER SPRITE: short taps use
  -- the same visual hitbox to proxy the interaction surface directly in front
  -- of the player. The caller decides whether the hit means START-hold or tap.
  -- Keep this host-agnostic so desktop mouse Tap to Move gets the same occlusion
  -- fix; beginPlayerHoldTouch itself remains real-touch/mobile-only in practice.
  local free = overworldGate(game)
  if not free then return false end
  local cur = mod.world and mod.world:current()
  if not cur then return false end

  local scene = voxelContext()
  if scene and scene.voxel3d then
    -- The supported Voxel renderers do NOT draw the player as a vertical column above the
    -- cell centre. It draws the live 16x16 sprite as a billboard card whose
    -- feet pivot at (player.px+8, player.py+8) and whose card leans back by
    -- (VoxelState.angle - pi/2). Hit-test that actual projected card.
    local player = game and game.overworld and game.overworld.player
    local px, py = playerPixel(game, cur)
    local map = game and game.overworld and game.overworld.map
    local ground = VoxelAdapter.groundHeight(scene, map, cur.x, cur.y)

    local angle = scene.voxelState and tonumber(scene.voxelState.angle) or 0
    local lean = angle - math.pi / 2
    local ca, sa = math.cos(lean), math.sin(lean)
    local function cardPoint(lx, ly)
      -- billboardMatrix = T(px+8,ground,py+8) * Rx(lean) * T(-8,0,0)
      local wx = px + lx
      local wy = ground + ly * ca
      local wz = py + 8 + ly * sa
      local proj = projectedPoint(scene.voxel3d, wx, wz, wy)
      local sx, sy = voxelCanvasToWindow(scene.voxel3d, proj)
      if not sx then return nil end
      return { sx, sy }
    end

    local q = {
      cardPoint(0, 0), cardPoint(16, 0),
      cardPoint(16, 16), cardPoint(0, 16),
    }
    if q[1] and q[2] and q[3] and q[4] then
      if pointInQuad(x, y, q) then return true end
      -- A small thumb/mouse tolerance around the real card outline. This is
      -- deliberately much tighter than a whole gameplay cell, so nearby floor
      -- taps do not unexpectedly become avatar interactions.
      local pad2 = 10 * 10
      for i = 1, 4 do
        local a, b = q[i], q[i % 4 + 1]
        if pointSegmentDistance2(x, y, a[1], a[2], b[1], b[2]) <= pad2 then
          return true
        end
      end
    end
  end

  if WorldBackend.isGold(game) then
    local player = WorldBackend.player(game)
    local g = ControlsFree.goldFrameGeometry(game, cur.mapId)
    local scale = g and tonumber(g.scale) or nil
    if player and g and scale and scale > 0 then
      local originX = tonumber(g.originX) or 0
      local originY = tonumber(g.originY) or 0
      -- drawPeople positions the sprite body from the same integer-floored
      -- map origin as drawGround.  Use the sprite's cell centre for the flat
      -- hitbox; if TILT is active, translate that centre by the exact delta
      -- applied to the upright billboard's FOOT anchor (px+8, py+16).
      local px = tonumber(player.px) or cur.x * TILE_SIZE
      local py = tonumber(player.py) or cur.y * TILE_SIZE
      local cx = originX + (px + TILE_SIZE / 2) * scale
      local cy = originY + (py + TILE_SIZE / 2) * scale
      if g.tiltActive then
        local footX = originX + (px + TILE_SIZE / 2) * scale
        local footY = originY + (py + TILE_SIZE) * scale
        local projFootX, projFootY = ControlsFree.goldFrameFlatToScreen(
          game, footX, footY, cur.mapId)
        if not projFootX then return false end
        cx = cx + (projFootX - footX)
        cy = cy + (projFootY - footY)
      end
      -- People remain upright and unscaled by perspective, so hitbox size is
      -- controlled only by Gold zoom after the billboard translation.
      local tile = TILE_SIZE * scale
      cy = cy - tile * 0.35
      local halfW = math.max(16, tile * 0.85)
      local halfH = math.max(22, tile * 1.35)
      if math.abs(x - cx) <= halfW and math.abs(y - cy) <= halfH then
        return true
      end
    end
  end

  local view = state.view
  if view then
    local ppx, ppy = playerPixel(game, cur)
    local ow = game and game.overworld
    local cameraX = ow and ow.camera and tonumber(ow.camera.x)
      or (ppx - (view.worldW / 2 - 16))
    local cameraY = ow and ow.camera and tonumber(ow.camera.y)
      or (ppy - (view.worldH / 2 - 8))
    local canvasX = cur.x * TILE_SIZE + TILE_SIZE / 2 - cameraX
    local canvasY = cur.y * TILE_SIZE + TILE_SIZE / 2 - cameraY
    local cx = (view.ox + canvasX * view.scale) / math.max(view.dpiX or 1, 1e-6)
    local cy = (view.oy + canvasY * view.scale) / math.max(view.dpiY or 1, 1e-6)
    local tileW = TILE_SIZE * view.scale / math.max(view.dpiX or 1, 1e-6)
    local tileH = TILE_SIZE * view.scale / math.max(view.dpiY or 1, 1e-6)
    -- The sprite extends above its cell centre, so bias the hitbox upward.
    cy = cy - tileH * 0.35
    local halfW = math.max(16, tileW * 0.85)
    local halfH = math.max(22, tileH * 1.35)
    if math.abs(x - cx) <= halfW and math.abs(y - cy) <= halfH then return true end
  end

  -- Last compatibility fallback: if the renderer's exact screen transform is
  -- unavailable but the tap resolver still maps the contact to the player's
  -- current cell, treat it as the player.
  local tx, ty, tapCur = targetFromTap(game, x, y)
  return tapCur ~= nil and tapCur.mapId == cur.mapId and tx == cur.x and ty == cur.y
end

-- START-menu tap semantics: the menu is a generic Menu with startCloses=true
-- and an edge anchor. A release tap INSIDE its actually rendered box means A;
-- a tap OUTSIDE means B/close. Return nil for every other UI state so the
-- catch-all DIALOG behavior stays release-A there.
function ControlsFree.startMenuTapInside(game, x, y)
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" then return nil end
  local okTop, top = pcall(stack.top, stack)
  if not okTop or type(top) ~= "table" then return nil end

  if WorldBackend.isGold(game) and top.screenId == "Gen2StartMenu" then
    local ww, wh
    if love and love.graphics and type(love.graphics.getDimensions) == "function" then
      local okDims, w, h = pcall(love.graphics.getDimensions)
      if okDims then ww, wh = tonumber(w), tonumber(h) end
    end
    local frame = state.frame or {}
    ww, wh = ww or tonumber(frame.ww), wh or tonumber(frame.wh)
    if not (ww and wh and type(game.frameFit) == "function") then return nil end
    local okFit, scale, ox, oy = pcall(game.frameFit, game, ww, wh)
    if not okFit or not tonumber(scale) then return nil end
    scale, ox, oy = tonumber(scale), tonumber(ox) or 0, tonumber(oy) or 0
    -- Gold StartMenu: menu_coords 10,0,19,17 => right half of 160x144.
    local dx, dy = ox + 10 * 8 * scale, oy
    local bw, bh = 10 * 8 * scale, 18 * 8 * scale
    return x >= dx and y >= dy and x < dx + bw and y < dy + bh
  end

  if top.startCloses ~= true then return nil end
  local tx, ty, tw, th = tonumber(top.tx), tonumber(top.ty), tonumber(top.tw), tonumber(top.th)
  if not (tx and ty and tw and th and tw > 0 and th > 0) then return nil end

  local r = game.renderer
  local frame = state.frame or {}
  local ww, wh = tonumber(frame.ww), tonumber(frame.wh)
  if (not ww or not wh) and love and love.graphics
      and type(love.graphics.getDimensions) == "function" then
    local okDims, gw, gh = pcall(love.graphics.getDimensions)
    if okDims then ww, wh = tonumber(gw), tonumber(gh) end
  end
  if not (r and ww and wh and ww > 0 and wh > 0) then return nil end

  local dpiX, dpiY = tonumber(frame.dpiX) or 1, tonumber(frame.dpiY) or 1
  if dpiX <= 0 then dpiX = 1 end
  if dpiY <= 0 then dpiY = 1 end
  local up
  if type(r.uiScale) == "function" then
    local okScale, v = pcall(r.uiScale, r)
    if okScale then up = tonumber(v) end
  end
  if not up or up <= 0 then
    if type(r.fitScale) == "function" then
      local okScale, v = pcall(r.fitScale, r)
      if okScale then up = tonumber(v) end
    end
  end
  if not up or up <= 0 then return nil end

  local uiw, uih = 160, 144
  if type(r.uiSize) == "function" then
    local okSize, w, h = pcall(r.uiSize, r)
    if okSize and tonumber(w) and tonumber(h) then uiw, uih = tonumber(w), tonumber(h) end
  end
  local ux, uy = up / dpiX, up / dpiY
  local bx, by, bw, bh = tx * 8, ty * 8, tw * 8, th * 8
  local dx, dy
  if top.anchor == "topright" and not r.uiCentered and not r.uiAnchorHold then
    local gapR = (uiw - (bx + bw)) * ux
    dx = ww - gapR - bw * ux
    dy = by * uy
  else
    local pw = tonumber(frame.pw) or ww * dpiX
    local ph = tonumber(frame.ph) or wh * dpiY
    local uox = math.floor((pw - uiw * up) / 2) / dpiX
    local uoy = math.floor((ph - uih * up) / 2) / dpiY
    dx, dy = uox + bx * ux, uoy + by * uy
  end
  return x >= dx and y >= dy and x < dx + bw * ux and y < dy + bh * uy
end

function ControlsFree.beginDialogTouch(game, id, x, y)
  if id == nil or id == "mouse" or state.twoFingerGesture
      or not ControlsFree.dialogTouchFeatureEnabled(game) then
    return false
  end
  state.dialogTouches = state.dialogTouches or {}
  state.dialogTouches[id] = {
    startX = x, startY = y, x = x, y = y, startedTick = state.tick,
    suppressed = false, holdBCancelled = false, bFired = false,
  }
  return true
end

local function dialogSwipeDirection(dx, dy)
  if math.abs(dx) >= math.abs(dy) then
    return dx >= 0 and "right" or "left"
  end
  return dy >= 0 and "down" or "up"
end

function ControlsFree.moveDialogTouch(id, x, y)
  local t = state.dialogTouches and state.dialogTouches[id]
  if not t then return false end
  t.x, t.y = x, y
  if t.bFired then return true end
  local dx, dy = x - t.startX, y - t.startY
  if not t.holdBCancelled
      and dx * dx + dy * dy > ControlsFree.TOUCH_HOLD_B_MOVE_SLOP_UNITS * ControlsFree.TOUCH_HOLD_B_MOVE_SLOP_UNITS then
    -- Long-hold B is intentionally stricter than swipe. Once the finger has
    -- meaningfully wandered, returning near the origin later must not resurrect
    -- a B candidate.
    t.holdBCancelled = true
  end
  if not t.swipeDirection then
    if dx * dx + dy * dy >= DIALOG_SWIPE_TRIGGER_UNITS * DIALOG_SWIPE_TRIGGER_UNITS then
      -- Classification latches the instant a deliberate swipe is recognized.
      -- Returning the finger toward its start point later must never turn that
      -- already-recognized swipe back into an A tap on release.
      t.swipeDirection = dialogSwipeDirection(dx, dy)
    end
  end
  return true
end

function ControlsFree.finishDialogTouch(game, id, x, y, cancelled)
  local t = state.dialogTouches and state.dialogTouches[id]
  if not t then return false end
  state.dialogTouches[id] = nil
  t.x, t.y = x or t.x, y or t.y
  if cancelled or t.suppressed or not ControlsFree.dialogTouchFeatureEnabled(game) then return true end
  if t.bFired then return true end

  local dx, dy = (t.x or t.startX) - t.startX, (t.y or t.startY) - t.startY
  if not t.swipeDirection
      and dx * dx + dy * dy >= DIALOG_SWIPE_TRIGGER_UNITS * DIALOG_SWIPE_TRIGGER_UNITS then
    -- Some hosts can coalesce touch-move events; classify from the release
    -- displacement too so a fast swipe is not mistaken for a tap.
    t.swipeDirection = dialogSwipeDirection(dx, dy)
  end
  if t.swipeDirection then
    local btn = t.swipeDirection
    mod.input:tap(game, btn)
    state.stats.dialogSwipes = (state.stats.dialogSwipes or 0) + 1
    local statKey = "dialogSwipe" .. btn:sub(1, 1):upper() .. btn:sub(2)
    state.stats[statKey] = (state.stats[statKey] or 0) + 1
    return true
  end

  local insideStartMenu = ControlsFree.startMenuTapInside(game, t.startX, t.startY)
  if insideStartMenu == false then
    mod.input:tap(game, "b")
    state.stats.startMenuOutsideBTaps = (state.stats.startMenuOutsideBTaps or 0) + 1
    return true
  end
  mod.input:tap(game, "a")
  state.stats.dialogATaps = (state.stats.dialogATaps or 0) + 1
  if insideStartMenu == true then
    state.stats.startMenuInsideATaps = (state.stats.startMenuInsideATaps or 0) + 1
  end
  return true
end


-- BATTLE TOUCH CONTROL intentionally mirrors DIALOG TOUCH CONTROL: no Game
-- Boy input on touch-down, a stationary one-second hold can fire B, otherwise
-- sticky swipe/tap classification resolves exactly one action on release.  The raw Game:touch* bridge additionally owns the whole
-- contact while the battle is present, which is what prevents a 3D camera
-- drag from receiving the same swipe.
function ControlsFree.beginBattleTouch(game, id, x, y)
  if id == nil or id == "mouse" or state.twoFingerGesture
      or not ControlsFree.battleTouchFeatureEnabled(game) then
    return false
  end
  -- DIALOG TOUCH CONTROL excludes BattleState by contract, so there is no
  -- semantic overlap here. Keep this guard as a defensive single-owner check.
  if ControlsFree.dialogTouchFeatureEnabled(game) then return false end
  state.battleTouches = state.battleTouches or {}
  state.battleTouches[id] = {
    startX = x, startY = y, x = x, y = y, startedTick = state.tick,
    suppressed = false, holdBCancelled = false, bFired = false,
  }
  return true
end

function ControlsFree.moveBattleTouch(id, x, y)
  local t = state.battleTouches and state.battleTouches[id]
  if not t then return false end
  t.x, t.y = x, y
  if t.bFired then return true end
  local dx, dy = x - t.startX, y - t.startY
  if not t.holdBCancelled
      and dx * dx + dy * dy > ControlsFree.TOUCH_HOLD_B_MOVE_SLOP_UNITS * ControlsFree.TOUCH_HOLD_B_MOVE_SLOP_UNITS then
    t.holdBCancelled = true
  end
  if not t.swipeDirection then
    if dx * dx + dy * dy >= DIALOG_SWIPE_TRIGGER_UNITS * DIALOG_SWIPE_TRIGGER_UNITS then
      t.swipeDirection = dialogSwipeDirection(dx, dy)
    end
  end
  return true
end

function ControlsFree.finishBattleTouch(game, id, x, y, cancelled)
  local t = state.battleTouches and state.battleTouches[id]
  if not t then return false end
  state.battleTouches[id] = nil
  t.x, t.y = x or t.x, y or t.y
  if cancelled or t.suppressed or not ControlsFree.battleActive(game) then return true end
  if t.bFired then return true end

  local dx, dy = (t.x or t.startX) - t.startX, (t.y or t.startY) - t.startY
  if not t.swipeDirection
      and dx * dx + dy * dy >= DIALOG_SWIPE_TRIGGER_UNITS * DIALOG_SWIPE_TRIGGER_UNITS then
    t.swipeDirection = dialogSwipeDirection(dx, dy)
  end
  if t.swipeDirection then
    local btn = t.swipeDirection
    mod.input:tap(game, btn)
    state.stats.battleSwipes = (state.stats.battleSwipes or 0) + 1
    local statKey = "battleSwipe" .. btn:sub(1, 1):upper() .. btn:sub(2)
    state.stats[statKey] = (state.stats[statKey] or 0) + 1
    return true
  end

  mod.input:tap(game, "a")
  state.stats.battleATaps = (state.stats.battleATaps or 0) + 1
  return true
end

-- A stationary one-finger hold is the B counterpart to release-A. The two
-- contexts keep separate touch tables and counters, so enabling DIALOG does
-- not affect battles and enabling BATTLE does not affect non-battle UI.
function ControlsFree.fireHoldBForTouches(game, touches, active, statKey)
  for _, t in pairs(touches or {}) do
    if not t.bFired and not t.suppressed and not t.holdBCancelled then
      if not active(game) or state.twoFingerGesture then
        t.holdBCancelled = true
      elseif state.tick - (t.startedTick or state.tick) + 1 >= ControlsFree.TOUCH_HOLD_B_TICKS then
        mod.input:tap(game, "b")
        t.bFired = true
        state.stats[statKey] = (state.stats[statKey] or 0) + 1
      end
    end
  end
end

function ControlsFree.holdBTouchTick(game)
  ControlsFree.fireHoldBForTouches(game, state.dialogTouches,
    ControlsFree.dialogTouchFeatureEnabled, "dialogBHoldTriggers")
  ControlsFree.fireHoldBForTouches(game, state.battleTouches,
    ControlsFree.battleTouchFeatureEnabled, "battleBHoldTriggers")
end

function ControlsFree.beginPlayerHoldTouch(game, id, x, y)
  if ControlsFree.simpleTouchEnabled and ControlsFree.simpleTouchEnabled() then
    return false
  end
  if id == nil or id == "mouse"
      or startSelectTouchMode() ~= "hold_player_sprite"
      or ControlsFree.dialogueActive(game) or state.twoFingerGesture then
    return false
  end
  local hitPlayer
  if ControlsFree.simpleTouchEnabled and ControlsFree.simpleTouchEnabled()
      and ControlsFree.simpleTouchComponents then
    local comps = ControlsFree.simpleTouchComponents({ x = x, y = y })
    hitPlayer = comps and #comps == 0 or false
  else
    hitPlayer = ControlsFree.playerScreenHit(game, x, y) == true
  end
  if not hitPlayer then return false end
  state.playerHoldTouches = state.playerHoldTouches or {}
  state.playerHoldTouches[id] = {
    startX = x, startY = y, x = x, y = y, pressTick = state.tick,
    cancelled = false, fired = false,
  }
  return true
end

function ControlsFree.movePlayerHoldTouch(id, x, y)
  local t = state.playerHoldTouches and state.playerHoldTouches[id]
  if not t then return false end
  t.x, t.y = x, y
  if not t.cancelled and not t.fired then
    local dx, dy = x - t.startX, y - t.startY
    if dx * dx + dy * dy > PLAYER_HOLD_MOVE_SLOP_UNITS * PLAYER_HOLD_MOVE_SLOP_UNITS then
      t.cancelled = true
      t.cancelReason = "moved"
    end
  end
  return true
end

function ControlsFree.finishPlayerHoldTouch(id)
  local t = state.playerHoldTouches and state.playerHoldTouches[id]
  if not t then return false end
  state.playerHoldTouches[id] = nil
  return true
end

function ControlsFree.playerHoldStartTick(game)
  if startSelectTouchMode() ~= "hold_player_sprite" then return end
  for id, t in pairs(state.playerHoldTouches or {}) do
    if not t.cancelled and not t.fired
        and state.tick - (t.pressTick or state.tick) + 1 >= PLAYER_HOLD_START_TICKS then
      local free = overworldGate(game)
      if not free or state.twoFingerGesture then
        t.cancelled = true
        t.cancelReason = "busy"
      else
        mod.input:tap(game, "start")
        t.fired = true
        state.stats.playerHoldStartTriggers =
          (state.stats.playerHoldStartTriggers or 0) + 1
        local p = state.pointers and state.pointers[id]
        if p then
          p.playerHoldCandidate = false
          p.gestureSuppressed = "player_hold_start"
          p.manualSuppressed = true
        end
        if state.nav then cancelRoute("player_hold_start") end
      end
    end
  end
end

-- Compatibility fallback for builds where the raw Game:touch* bridge cannot
-- be installed. Current Gen1Recomp is handled earlier by installRawPinchZoomGuard;
-- this TouchControls seam preserves the same release-only tap/swipe semantics
-- for catch-all non-overworld UI and battle control if a future/older host
-- routes a virtual-control-zone touch here first.
function ControlsFree.installTouchDialogueBridge(game)
  if state.touchDialogueBridgeInstalled or not game then return false end
  local tc = game.touchControls
  if type(tc) ~= "table" or type(tc.touchpressed) ~= "function"
      or type(tc.touchmoved) ~= "function" or type(tc.touchreleased) ~= "function" then
    return false
  end
  local pressed0, moved0, released0 = tc.touchpressed, tc.touchmoved, tc.touchreleased
  state.touchDialogueBridgeOriginal = {
    touchpressed = pressed0, touchmoved = moved0, touchreleased = released0,
  }
  tc.touchpressed = function(self, id, x, y)
    -- Fallback parity with the raw Game bridge: a contact that STARTS on a
    -- visible virtual control belongs to native TouchControls, never this mod.
    if ControlsFree.rawTouchControlHit(game, x, y) then
      state.nativeControlOwnedTouches = state.nativeControlOwnedTouches or {}
      if id ~= nil then state.nativeControlOwnedTouches[id] = true end
      return pressed0(self, id, x, y)
    end
    if ControlsFree.beginDialogTouch(game, id, x, y) then return true end
    if ControlsFree.beginBattleTouch(game, id, x, y) then return true end
    if ControlsFree.battleTouchFeatureEnabled(game) and id ~= nil and id ~= "mouse" then
      return true
    end
    return pressed0(self, id, x, y)
  end
  tc.touchmoved = function(self, id, x, y)
    if state.nativeControlOwnedTouches and state.nativeControlOwnedTouches[id] then
      return moved0(self, id, x, y)
    end
    if ControlsFree.moveDialogTouch(id, x, y) then return true end
    if ControlsFree.moveBattleTouch(id, x, y) then return true end
    if ControlsFree.battleTouchFeatureEnabled(game) and id ~= nil and id ~= "mouse" then
      return true
    end
    return moved0(self, id, x, y)
  end
  tc.touchreleased = function(self, id, x, y)
    if state.nativeControlOwnedTouches and state.nativeControlOwnedTouches[id] then
      local result = released0(self, id, x, y)
      state.nativeControlOwnedTouches[id] = nil
      return result
    end
    if state.dialogTouches and state.dialogTouches[id] then
      ControlsFree.finishDialogTouch(game, id, x, y, false)
      return true
    end
    if state.battleTouches and state.battleTouches[id] then
      ControlsFree.finishBattleTouch(game, id, x, y, false)
      return true
    end
    if ControlsFree.battleTouchFeatureEnabled(game) and id ~= nil and id ~= "mouse" then
      return true
    end
    return released0(self, id, x, y)
  end
  state.touchDialogueBridgeInstalled = true
  return true
end

local function pointerOverTouchControl(game, x, y)
  local tc = game and game.touchControls
  if not tc or type(tc.hitTest) ~= "function" then return false end
  if type(tc.visible) == "function" then
    local okVisible, visible = pcall(tc.visible, tc)
    if okVisible and not visible then return false end
  end
  local ok, hit = pcall(tc.hitTest, tc, x, y)
  return ok and hit ~= nil
end

local function suppressCurrentGesture(reason)
  local id = state.tapOwner
  local p = id and state.pointers[id]
  if not p or p.ignored then return false end
  p.gestureSuppressed = reason or true
  p.manualSuppressed = true
  return true
end

pointerForGesture = function(gestureId)
  if gestureId == nil then return nil end
  for _, p in pairs(state.pointers) do
    if p and not p.ignored and p.gestureId == gestureId then return p end
  end
  return nil
end

gestureIsDown = function(gestureId)
  return pointerForGesture(gestureId) ~= nil
end

-- An interaction may be selected on the initial press so movement begins
-- immediately. Hold promotion keeps NPC interactions armed (A is release-gated)
-- but converts fixed surfaces such as PCs/signs into movement-only approaches.
-- Subsequent continuous samples can still select an NPC as a semantic target.
local function disarmInteractionForGesture(gestureId, reason)
  local nav = state.nav
  if not nav or gestureId == nil or nav.interactionGestureId ~= gestureId then
    return false
  end

  local changed = false
  -- NPCs are now valid semantic Hold-to-Steer targets. Reaching one while
  -- the finger is down waits for release, so there is no risk of an unwanted
  -- A press. Fixed surfaces (PC/sign/etc.) keep the old movement-only hold
  -- behavior.
  if nav.interaction and nav.interaction.kind == "entity" then
    return false
  end
  if nav.interaction then
    nav.interaction = nil
    nav.goalKind = "move"
    -- buildInteractionPath already chose a legal approach cell as targetX/Y.
    -- Keep walking there; the actual entity/surface is no longer an A target.
    nav.requestedMapId = nav.mapId
    nav.requestedX, nav.requestedY = nav.targetX, nav.targetY
    changed = true
  end
  if nav.crossInteraction then
    if nav.crossInteraction.kind == "entity" then return false end
    nav.crossInteraction = nil
    if nav.goalKind == "cross_interact" then nav.goalKind = "cross_move" end
    changed = true
  end

  nav.interactionGestureId = nil
  nav.interactionRequiresRelease = nil
  if changed then
    state.stats.interactionHoldDisarms =
      (state.stats.interactionHoldDisarms or 0) + 1
    if nav.phase == "WAITING_INTERACTION_RELEASE" then
      setPhase(nav, "WALKING", reason or "interaction_disarmed")
    end
  end
  return changed
end

-- ALWAYS-AVAILABLE NATIVE TOUCH-CONTROLS TOGGLE ---------------------------
--
-- A tiny top-right overlay remains visible even when the stock Gen1Recomp
-- D-pad/A/B/START/SELECT overlay is hidden. It is intentionally runtime-only:
-- it does not rewrite the player's persistent launcher layout/options.
function ControlsFree.nativeControlsToggleRect()
  local w, h = ControlsFree.simpleTouchWindowSize and ControlsFree.simpleTouchWindowSize() or nil
  if not w or not h then
    if love and love.graphics and type(love.graphics.getDimensions) == "function" then
      local ok, gw, gh = pcall(love.graphics.getDimensions)
      if ok then w, h = tonumber(gw), tonumber(gh) end
    end
  end
  if not w or not h then return nil end
  local size = math.max(ControlsFree.NATIVE_CONTROLS_TOGGLE_MIN_SIZE,
    math.min(ControlsFree.NATIVE_CONTROLS_TOGGLE_MAX_SIZE, math.min(w, h) * 0.075))
  local margin = ControlsFree.NATIVE_CONTROLS_TOGGLE_MARGIN
  return w - margin - size, margin, size, size
end

function ControlsFree.nativeControlsToggleHit(x, y)
  local rx, ry, rw, rh = ControlsFree.nativeControlsToggleRect()
  if not rx then return false end
  local slop = ControlsFree.NATIVE_CONTROLS_TOGGLE_SLOP
  x, y = tonumber(x), tonumber(y)
  return x and y and x >= rx - slop and x <= rx + rw + slop
    and y >= ry - slop and y <= ry + rh + slop or false
end

function ControlsFree.nativeControlsVisible(game)
  if state.nativeControlsVisibleOverride ~= nil then
    return state.nativeControlsVisibleOverride == true
  end
  local tc = game and game.touchControls
  if tc and type(tc.visible) == "function" then
    local ok, visible = pcall(tc.visible, tc)
    if ok then return visible == true end
  end
  return tc and tc.enabled ~= false and not tc.controllerHidden or false
end

function ControlsFree.applyNativeControlsVisibility(game)
  local tc = game and game.touchControls
  if not tc or state.nativeControlsVisibleOverride == nil then return end
  local show = state.nativeControlsVisibleOverride == true
  if show then
    tc.enabled = true
    tc.controllerHidden = false
    if not tc.img and type(tc.ensureImages) == "function" then pcall(tc.ensureImages, tc) end
  else
    if tc.enabled ~= false and type(tc.reset) == "function" then pcall(tc.reset, tc) end
    tc.enabled = false
    tc.controllerHidden = false
  end
end

function ControlsFree.toggleNativeControls(game)
  local show = not ControlsFree.nativeControlsVisible(game)
  state.nativeControlsVisibleOverride = show
  ControlsFree.applyNativeControlsVisibility(game)
  state.stats.nativeControlsTogglePresses =
    (state.stats.nativeControlsTogglePresses or 0) + 1
  if show then
    state.stats.nativeControlsShown = (state.stats.nativeControlsShown or 0) + 1
  else
    state.stats.nativeControlsHidden = (state.stats.nativeControlsHidden or 0) + 1
  end
  return show
end

function ControlsFree.drawNativeControlsToggle(game)
  if not (love and love.graphics) then return end
  local x, y, w, h = ControlsFree.nativeControlsToggleRect()
  if not x then return end
  local visible = ControlsFree.nativeControlsVisible(game)
  local pressed = false
  for _, t in pairs(state.nativeControlsToggleTouches or {}) do
    if not t.cancelled then pressed = true break end
  end
  local a = pressed and 0.78 or 0.48
  love.graphics.push("all")
  love.graphics.origin()
  love.graphics.setColor(0, 0, 0, a * 0.72)
  love.graphics.rectangle("fill", x, y, w, h, w * 0.22, h * 0.22)
  love.graphics.setColor(1, 1, 1, a)
  love.graphics.setLineWidth(math.max(1.5, w * 0.055))
  -- Compact controller glyph: d-pad on the left, A/B dots on the right.
  local cx, cy = x + w * 0.34, y + h * 0.52
  local arm = w * 0.11
  love.graphics.line(cx - arm, cy, cx + arm, cy)
  love.graphics.line(cx, cy - arm, cx, cy + arm)
  love.graphics.circle("fill", x + w * 0.67, y + h * 0.45, w * 0.055)
  love.graphics.circle("fill", x + w * 0.78, y + h * 0.59, w * 0.055)
  if not visible then
    -- Slash means the stock overlay is currently hidden; the icon itself stays.
    love.graphics.setLineWidth(math.max(2, w * 0.07))
    love.graphics.line(x + w * 0.20, y + h * 0.18, x + w * 0.82, y + h * 0.82)
  end
  love.graphics.pop()
end

function ControlsFree.installNativeControlsToggle(game)
  if state.nativeControlsToggleInstalled or not game or not game.touchControls then
    return false
  end
  local tc = game.touchControls
  if type(tc.draw) ~= "function" then return false end
  local draw0 = tc.draw
  state.nativeControlsToggleOriginalDraw = draw0
  tc.draw = function(self, ...)
    ControlsFree.applyNativeControlsVisibility(game)
    local result = draw0(self, ...)
    ControlsFree.drawNativeControlsToggle(game)
    return result
  end
  state.nativeControlsToggleInstalled = true
  return true
end

-- SIMPLE TOUCH MOVEMENT -----------------------------------------------------
--
-- This deliberately lives completely outside targetFromTap()/Voxel/pathfinding.
-- It is the compatibility mode for renderers whose visual geometry Tap to Move
-- cannot understand.  The only screen-space assumption is the one the user can
-- rely on across those renderers: the player is framed around the screen centre.
function ControlsFree.simpleTouchEnabled()
  return option("enabled", true) ~= false
      and option("simple_touch_movement", false) == true
end

function ControlsFree.releaseSimpleHold()
  local h = state.simpleHold
  if h and h.handle then mod.input:release(h.handle) end
  state.simpleHold = nil
end

function ControlsFree.simpleTouchWindowSize()
  -- input.pointer coordinates are LOVE window units, so getDimensions is the
  -- renderer-independent source of truth.  render.compose data is fallback only.
  if love and love.graphics and type(love.graphics.getDimensions) == "function" then
    local ok, w, h = pcall(love.graphics.getDimensions)
    if ok and tonumber(w) and tonumber(h) and w > 0 and h > 0 then
      return tonumber(w), tonumber(h)
    end
  end
  local f = state.frame or {}
  local w, h = tonumber(f.ww), tonumber(f.wh)
  if w and h and w > 0 and h > 0 then return w, h end
  local dx, dy = tonumber(f.dpiX) or 1, tonumber(f.dpiY) or 1
  if tonumber(f.pw) and tonumber(f.ph) then
    return tonumber(f.pw) / math.max(dx, 1e-6),
           tonumber(f.ph) / math.max(dy, 1e-6)
  end
  return nil
end

function ControlsFree.clampUnit(v)
  if v < -1 then return -1 end
  if v > 1 then return 1 end
  return v
end

function ControlsFree.simpleCenterDeadzone()
  local fallback = math.floor((ControlsFree.SIMPLE_TOUCH_DEADZONE or 0.10) * 100 + 0.5)
  local pct = tonumber(option("simple_center_deadzone_pct", tostring(fallback))) or fallback
  return math.max(0, math.min(50, pct)) / 100
end

function ControlsFree.simpleAxisDeadzone()
  local fallback = math.floor((ControlsFree.SIMPLE_TOUCH_AXIS_DEADZONE or 0.06) * 100 + 0.5)
  local pct = tonumber(option("simple_axis_deadzone_pct", tostring(fallback))) or fallback
  return math.max(0, math.min(50, pct)) / 100
end

function ControlsFree.simpleDominanceRatio()
  local raw = tostring(option("simple_dominance_ratio",
    tostring(ControlsFree.SIMPLE_TOUCH_DOMINANCE_RATIO or 4.0)) or "4")
  if raw == "off" then return math.huge end
  local ratio = tonumber(raw) or ControlsFree.SIMPLE_TOUCH_DOMINANCE_RATIO or 4.0
  return math.max(1.0, math.min(100.0, ratio))
end

-- Return the two directional components represented by a pointer.  Magnitudes
-- are literal percentages of centre->screen-edge distance on each axis: e.g.
-- 70% up + 30% left becomes weights 0.70/0.30.
function ControlsFree.simpleTouchComponents(p)
  local w, h = ControlsFree.simpleTouchWindowSize()
  if not p or not w or not h then return nil end
  local cx, cy = w * 0.5, h * 0.5
  local nx = ControlsFree.clampUnit(((tonumber(p.x) or cx) - cx) / math.max(w * 0.5, 1))
  local ny = ControlsFree.clampUnit(((tonumber(p.y) or cy) - cy) / math.max(h * 0.5, 1))
  local ax, ay = math.abs(nx), math.abs(ny)
  local centerDeadzone = ControlsFree.simpleCenterDeadzone()
  local axisDeadzone = ControlsFree.simpleAxisDeadzone()
  if math.sqrt(nx * nx + ny * ny) < centerDeadzone then return {} end
  if ax < axisDeadzone then ax = 0 end
  if ay < axisDeadzone then ay = 0 end
  local out = {}
  if ay > 0 then
    out[#out + 1] = { dir = ny < 0 and "up" or "down", weight = ay, axis = "v" }
  end
  if ax > 0 then
    out[#out + 1] = { dir = nx < 0 and "left" or "right", weight = ax, axis = "h" }
  end
  table.sort(out, function(a, b)
    if a.weight ~= b.weight then return a.weight > b.weight end
    return a.axis == "v" -- deterministic tie: vertical first
  end)
  if #out >= 2 and out[2].weight > 0
      and out[1].weight >= out[2].weight * ControlsFree.simpleDominanceRatio() then
    -- Preserve raw nx/ny for diagnostics, but make the movement decision truly
    -- cardinal: a blocked primary does NOT fall through to tiny thumb drift.
    out[1].dominant = true
    out[2] = nil
  end
  return out, nx, ny
end

function ControlsFree.simplePairBlocked(game, map, player, sx, sy, tx, ty)
  if WorldBackend.isGold(game) then return false end
  local pairs = game and game.data and game.data.field and game.data.field.tilePairs
  local list = pairs and (player and player.surfing and pairs.water or pairs.land)
  if not list or type(map.cellTile) ~= "function" then return false end
  local okA, a = pcall(map.cellTile, map, sx, sy)
  local okB, b = pcall(map.cellTile, map, tx, ty)
  if not (okA and okB) then return false end
  local tileset = map.def and map.def.tileset
  for _, pair in ipairs(list) do
    if pair.tileset == tileset
        and ((pair.a == a and pair.b == b) or (pair.a == b and pair.b == a)) then
      return true
    end
  end
  return false
end

function ControlsFree.simplePushableLegal(game, ow, map, tx, ty, dir)
  if WorldBackend.isGold(game) then return false end
  if not (ow and ow.strengthActive and type(ow.pushableAtCell) == "function") then
    return false
  end
  local ok, boulder = pcall(ow.pushableAtCell, ow, tx, ty)
  if not (ok and boulder) then return false end
  local d = DIR_BY_NAME[dir]
  local bx, by = tx + d.dx, ty + d.dy
  if not map:inBounds(bx, by) or not map:isWalkableCell(bx, by) then return false end
  for _, e in ipairs(ow.npcs or {}) do
    if e ~= boulder and not e.passable
        and ((e.cellX == bx and e.cellY == by)
          or (e.targetX == bx and e.targetY == by)) then
      return false
    end
  end
  return true
end

-- A cheap *preference* legality check, not a replacement for engine collision.
-- The real movement still goes through Gen1Recomp.  We only use this to avoid
-- repeatedly choosing an obviously blocked primary component when the finger
-- also points toward a legal secondary component.
function ControlsFree.simpleDirectionLikelyLegal(game, p, dirName)
  local free = overworldGate(game)
  if not free then return false end

  if WorldBackend.isGold(game) then
    local world, player, map = WorldBackend.owner(game), WorldBackend.player(game),
      WorldBackend.map(game)
    local d = DIR_BY_NAME[dirName]
    if not (world and map and player and d) then return false end
    local sx, sy = player.cellX, player.cellY
    local cellK = key(sx, sy)
    local failed = p and p.simpleFailed
    if failed and failed.cell == cellK and failed.dir == dirName
        and state.tick <= (failed.untilTick or -1) then return false end

    local dirs = warpActivationDirections(game, map, sx, sy)
    if listHas(dirs, dirName) and WorldBackend.gold.warpFiresAt(game, map, sx, sy) then
      return true
    end

    local tx, ty = sx + d.dx, sy + d.dy
    if not map:inBounds(tx, ty) then
      local compass = ControlsFree.SIMPLE_DIR_COMPASS[dirName]
      local conn = map.def and map.def.connections and map.def.connections[compass]
      return conn ~= nil
    end

    local overview = WorldBackend.overview(game) or overviewFromLoadedMap(map)
    if not overview then return false end
    local topo = ledgeTopology(game, map, overview)
    for _, jump in ipairs((topo.jumps and topo.jumps[cellK]) or {}) do
      if jump.dir == dirName then return true end
    end
    if topo.blockedEdges and topo.blockedEdges[edgeKey(sx, sy, tx, ty)] then
      return false
    end
    local ch = cellChar(overview, tx, ty)
    if ch ~= "." and not (ch == "~" and ControlsFree.playerIsSurfing(game)) then
      return false
    end
    local occupied = select(1, liveOccupancy(game))
    if occupied[key(tx, ty)] then return false end
    return true
  end

  local ow, player = game.overworld, game.overworld.player
  local map = ow and ow.map
  local d = DIR_BY_NAME[dirName]
  if not map or not player or not d then return false end
  local sx, sy = player.cellX, player.cellY
  local cellK = key(sx, sy)
  local failed = p and p.simpleFailed
  if failed and failed.cell == cellK and failed.dir == dirName
      and state.tick <= (failed.untilTick or -1) then
    return false
  end

  -- A directional warp under the player is a legal manual input even when the
  -- cell in front is solid/out-of-bounds (exit carpets, wall openings, edges).
  local dirs = warpActivationDirections(game, map, sx, sy)
  if listHas(dirs, dirName) and type(map.warpAtCell) == "function"
      and map:warpAtCell(sx, sy) then return true end

  local tx, ty = sx + d.dx, sy + d.dy
  if not map:inBounds(tx, ty) then
    local compass = ControlsFree.SIMPLE_DIR_COMPASS[dirName]
    local conn = map.def and map.def.connections and map.def.connections[compass]
    return conn ~= nil -- engine remains authoritative for exact seam landing
  end

  local overview = WorldBackend.overview(game) or overviewFromLoadedMap(map)
  if overview then
    local topo = ledgeTopology(game, map, overview)
    for _, jump in ipairs((topo.jumps and topo.jumps[cellK]) or {}) do
      if jump.dir == dirName then return true end
    end
    if topo.blockedEdges and topo.blockedEdges[edgeKey(sx, sy, tx, ty)] then
      return false
    end
  end

  if ControlsFree.simplePushableLegal(game, ow, map, tx, ty, dirName) then return true end

  if not map:isWalkableCell(tx, ty) then
    if not (player.surfing and type(map.isWaterCell) == "function"
        and map:isWaterCell(tx, ty)) then
      return false
    end
  end
  if ControlsFree.simplePairBlocked(game, map, player, sx, sy, tx, ty) then return false end
  for _, e in ipairs(ow.npcs or {}) do
    if not e.passable
        and ((e.cellX == tx and e.cellY == ty)
          or (e.targetX == tx and e.targetY == ty)) then
      return false
    end
  end
  return true
end

-- Bresenham-like weighted mixer. With 0.70 UP / 0.30 LEFT it yields seven UP
-- decisions and three LEFT decisions per ten opportunities, distributed across
-- the sequence. If the primary component is blocked, the legal secondary wins
-- immediately instead of wasting presses against the wall.
function ControlsFree.chooseSimpleDirection(game, p)
  local comps, nx, ny = ControlsFree.simpleTouchComponents(p)
  p.simpleNX, p.simpleNY = nx or 0, ny or 0
  if not comps or #comps == 0 then
    state.stats.simpleTouchDeadzone = (state.stats.simpleTouchDeadzone or 0) + 1
    return nil
  end
  local primary, secondary = comps[1], comps[2]
  if primary and primary.dominant then
    state.stats.simpleTouchDominantCardinals =
      (state.stats.simpleTouchDominantCardinals or 0) + 1
  end
  local pOK = primary and ControlsFree.simpleDirectionLikelyLegal(game, p, primary.dir)
  local sOK = secondary and ControlsFree.simpleDirectionLikelyLegal(game, p, secondary.dir)
  if primary and not pOK and secondary and sOK then
    state.stats.simpleTouchFallbacks = (state.stats.simpleTouchFallbacks or 0) + 1
    p.simpleMixAcc = 0
    return secondary.dir
  end
  if primary and pOK and (not secondary or not sOK) then return primary.dir end
  if not pOK and not sOK then
    state.stats.simpleTouchBlocked = (state.stats.simpleTouchBlocked or 0) + 1
    -- Return the strongest intended direction as metadata. The movement tick
    -- uses it only to turn the avatar toward the finger; it never invents a
    -- step through the blocked collision.
    return nil, primary and primary.dir or nil
  end

  local total = primary.weight + secondary.weight
  local pairKey = primary.dir .. "/" .. secondary.dir
  if p.simpleMixPair ~= pairKey then
    p.simpleMixPair, p.simpleMixAcc = pairKey, 0
  end
  p.simpleMixAcc = (p.simpleMixAcc or 0) + secondary.weight
  if p.simpleMixAcc + 1e-9 >= total then
    p.simpleMixAcc = p.simpleMixAcc - total
    return secondary.dir
  end
  return primary.dir
end

function ControlsFree.simpleLongPressTicks(game)
  -- input.step runs once per fixed logic step, and fast-forward runs N of
  -- those per real frame. Scale the one-second gesture threshold by the same
  -- live multiplier so START/B still take roughly one wall-clock second.
  local speed = ControlsFree.overworldSpeedMultiplier and
    ControlsFree.overworldSpeedMultiplier(game) or 1
  return math.max(1, math.floor(FIXED_TICKS_PER_SECOND
    * ControlsFree.SIMPLE_TOUCH_LONG_PRESS_SECONDS * math.max(1, speed) + 0.5))
end

function ControlsFree.simplePointerMovedTooFar(p)
  if not p then return false end
  local dx, dy = (p.x or p.startX) - p.startX, (p.y or p.startY) - p.startY
  local slop = ControlsFree.SIMPLE_TOUCH_LONG_PRESS_MOVE_SLOP_UNITS
  return dx * dx + dy * dy > slop * slop
end

function ControlsFree.simpleGestureTick(game, p)
  if not p or p.simpleLongPressAction or p.ignored or p.gestureSuppressed then
    return false
  end
  local age = state.tick - (p.pressTick or state.tick)
  if age < ControlsFree.simpleLongPressTicks(game) then return false end
  if p.startedOnPlayer then
    if p.simpleAvatarHoldCancelled or ControlsFree.simplePointerMovedTooFar(p) then
      return false
    end
    ControlsFree.releaseSimpleHold()
    mod.input:tap(game, "start")
    p.simpleLongPressAction = "start"
    p.manualSuppressed = true
    state.stats.simpleTouchStartHolds = (state.stats.simpleTouchStartHolds or 0) + 1
    return true
  end

  -- A world hold remains a movement gesture as well; B is a one-shot overlay
  -- action and does not steal the held directional input. This keeps long
  -- renderer-agnostic walks usable while still making B universally available.
  if overworldGate(game) then
    mod.input:tap(game, "b")
    p.simpleLongPressAction = "b"
    state.stats.simpleTouchBHolds = (state.stats.simpleTouchBHolds or 0) + 1
    return true
  end
  return false
end

function ControlsFree.finishSimpleGesture(game, p)
  if not p then return false end
  if p.simpleLongPressAction then return true end
  if p.startedOnPlayer and not p.simpleAvatarHoldCancelled
      and not ControlsFree.simplePointerMovedTooFar(p) then
    mod.input:tap(game, "a")
    state.stats.simpleTouchAvatarInteractions =
      (state.stats.simpleTouchAvatarInteractions or 0) + 1
    return true
  end
  return false
end

function ControlsFree.simpleTurnTowardBlocked(game, p, dir)
  local player = WorldBackend.player(game)
  if not player or not dir or player.moving or player.facing == dir then return false end
  -- The direction was already proven non-walkable by the simple legality
  -- filter, so one fixed-step hold can only turn/bonk; it cannot move through
  -- the obstacle. The real engine remains authoritative for the turn.
  state.simpleHold = {
    dir = dir, handle = mod.input:press(game, dir),
    startX = player.cellX, startY = player.cellY, startedTick = state.tick,
    turnOnly = true,
  }
  state.stats.simpleTouchBlockedTurns = (state.stats.simpleTouchBlockedTurns or 0) + 1
  return true
end

function ControlsFree.simpleMovementTick(game)
  if not ControlsFree.simpleTouchEnabled() then
    ControlsFree.releaseSimpleHold()
    return
  end
  local id = state.tapOwner
  local p = id and state.pointers[id]
  if not p or not p.simpleMode or p.ignored or p.manualSuppressed
      or p.gestureSuppressed or p.playerHoldCandidate then
    ControlsFree.releaseSimpleHold()
    return
  end
  if pointerOverTouchControl(game, p.x, p.y) then
    ControlsFree.releaseSimpleHold()
    return
  end
  ControlsFree.simpleGestureTick(game, p)
  if p.simpleLongPressAction == "start" then
    ControlsFree.releaseSimpleHold()
    return
  end
  local free = overworldGate(game)
  local player = WorldBackend.player(game)
  if not free or not player then
    ControlsFree.releaseSimpleHold()
    return
  end
  if WorldBackend.isGold(game) then
    local world, map = WorldBackend.owner(game), WorldBackend.map(game)
    local Permissions = WorldBackend.gold.permissionsModule()
    if world and map and Permissions and type(map.cellCollision) == "function" then
      local forced = ControlsFree.goldNativeForcedDirection(game)
      if forced then
        ControlsFree.releaseSimpleHold()
        return
      end
    end
  end
  -- Never queue a second weighted direction in the middle of an engine-owned
  -- walking animation. A new mix decision belongs to the next idle cell.
  if player.moving then
    if state.simpleHold then
      state.stats.simpleTouchSteps = (state.stats.simpleTouchSteps or 0) + 1
      p.simpleFailed = nil
    end
    ControlsFree.releaseSimpleHold()
    return
  end

  local h = state.simpleHold
  if h then
    if h.turnOnly then
      if state.tick > (h.startedTick or state.tick) then
        mod.input:release(h.handle)
        state.simpleHold = nil
      end
      return
    end
    if player.cellX ~= h.startX or player.cellY ~= h.startY then
      mod.input:release(h.handle)
      state.simpleHold = nil
      p.simpleFailed = nil
      state.stats.simpleTouchSteps = (state.stats.simpleTouchSteps or 0) + 1
      return
    end
    if state.tick - (h.startedTick or state.tick) >= ControlsFree.SIMPLE_TOUCH_PRESS_FAIL_TICKS then
      mod.input:release(h.handle)
      state.simpleHold = nil
      p.simpleFailed = {
        cell = key(player.cellX, player.cellY), dir = h.dir,
        untilTick = state.tick + ControlsFree.SIMPLE_TOUCH_RETRY_BLOCK_TICKS,
      }
      state.stats.simpleTouchBlocked = (state.stats.simpleTouchBlocked or 0) + 1
    else
      return -- keep the same direction through turn-in-place + move attempt
    end
  end

  local dir, blockedDir = ControlsFree.chooseSimpleDirection(game, p)
  if not dir then
    if blockedDir then ControlsFree.simpleTurnTowardBlocked(game, p, blockedDir) end
    return
  end
  state.stats.simpleTouchDecisions = (state.stats.simpleTouchDecisions or 0) + 1
  state.stats["simpleTouch" .. dir:sub(1,1):upper() .. dir:sub(2)] =
    (state.stats["simpleTouch" .. dir:sub(1,1):upper() .. dir:sub(2)] or 0) + 1
  state.simpleHold = {
    dir = dir, handle = mod.input:press(game, dir),
    startX = player.cellX, startY = player.cellY, startedTick = state.tick,
  }
end

-- Gameplay touch/mouse outside virtual controls. TouchControls has first
-- refusal in Game before input.pointer, so its D-pad/A/B/START/SELECT cannot
-- become destinations. One world pointer owns navigation at a time.
--
-- test11 changes the gesture model fundamentally: PRESS starts navigation
-- immediately. The old TAP/HOLD delay no longer postpones movement; it only
-- decides when a still-held pointer starts continuous screen-space retargeting.
-- Interactive destinations are armed on press but may fire A only after this
-- exact gesture has been released.
mod.hooks:wrap("input.pointer", function(nextFn, game, ev)
  state.game = game or state.game

  -- Desktop parity for the always-visible controller toggle. Touch reaches the
  -- raw Game bridge above; LMB reaches this public pointer seam, and must be
  -- claimed BEFORE the underlying UI can treat the top-right icon as a menu
  -- click.
  if ev and ev.source == "mouse" and (ev.button == nil or ev.button == 1) then
    local mt = state.nativeControlsToggleTouches and state.nativeControlsToggleTouches.mouse
    if ev.phase == "pressed" and ControlsFree.nativeControlsToggleHit(ev.x, ev.y) then
      state.nativeControlsToggleTouches = state.nativeControlsToggleTouches or {}
      state.nativeControlsToggleTouches.mouse = {
        startX = ev.x, startY = ev.y, x = ev.x, y = ev.y,
      }
      return true
    elseif mt and ev.phase == "moved" then
      mt.x, mt.y = ev.x, ev.y
      local dx, dy = ev.x - mt.startX, ev.y - mt.startY
      local slop = ControlsFree.NATIVE_CONTROLS_TOGGLE_SLOP * 1.5
      if dx * dx + dy * dy > slop * slop then mt.cancelled = true end
      return true
    elseif mt and (ev.phase == "released" or ev.phase == "cancelled") then
      state.nativeControlsToggleTouches.mouse = nil
      if ev.phase == "released" and not mt.cancelled
          and ControlsFree.nativeControlsToggleHit(ev.x, ev.y) then
        ControlsFree.toggleNativeControls(game)
      end
      return true
    end
  end

  local result = nextFn(game, ev)
  if not ev then return result end
  -- Respect another pointer consumer deeper in the chain. If it claims this
  -- contact, retire any local gesture record rather than responding as well.
  if result == true then
    -- A claimed non-left mouse button is unrelated to an LMB navigation
    -- gesture even though Gen1Recomp reports both under id "mouse".
    if ev.source == "mouse" and ev.button and ev.button ~= 1 then
      return result
    end
    -- If another pointer consumer takes over mid-gesture, retire our
    -- two-finger bookkeeping too. Otherwise a swallowed release could leave
    -- the zoom guard armed after the contact belongs to somebody else.
    if state.gestureTouches and state.gestureTouches[ev.id] then
      finishTwoFingerGesture(game, ev.id)
      state.gestureTouches[ev.id] = nil
      maybeClearTwoFingerGesture(game)
    end
    state.pointers[ev.id] = nil
    if state.tapOwner == ev.id then state.tapOwner = nil end
    return result
  end
  if option("enabled", true) == false then return result end

  -- Mouse shortcuts are independent from mouse walking. Only LMB is ever
  -- allowed into navigation pointer state. Gen1Recomp exposes every physical
  -- mouse button under the same pointer id ("mouse"), so non-left releases
  -- must return before generic pointer cleanup or they could cancel an LMB walk.
  if ev.source == "mouse" and ev.button and ev.button ~= 1 then
    if ev.button == 4 or ev.button == 5 then
      local mode = tostring(option("mouse_side_buttons", "off") or "off")
      if mode ~= "off" then
        if ev.phase == "pressed" then
          local mapped
          if mode == "on_flipped" then
            mapped = ev.button == 5 and "select" or "start"
          else
            -- Normal: MOUSE 5 = START, MOUSE 4 = SELECT.
            mapped = ev.button == 5 and "start" or "select"
          end
          mod.input:tap(game, mapped)
          state.stats.mouseSideButtonTaps =
            (state.stats.mouseSideButtonTaps or 0) + 1
          state.stats["mouseSide_" .. mapped] =
            (state.stats["mouseSide_" .. mapped] or 0) + 1
          return true
        elseif ev.phase == "released" then
          return true
        end
      end
      return result
    end

    if ev.button == 2 and ControlsFree.desktopHost()
        and option("desktop_mouse_ab", false) == true then
      if ev.phase == "pressed" then
        mod.input:tap(game, "b")
        state.stats.desktopBTaps = (state.stats.desktopBTaps or 0) + 1
        return true
      elseif ev.phase == "released" then
        return true
      end
    end
    return result
  end

  -- Optional desktop click mapping: LMB=A on UI; bare-overworld LMB remains
  -- independently controlled by MOUSE WALK CONTROL.
  if ev.phase == "pressed" and ev.source == "mouse" and ev.button == 1
      and ControlsFree.desktopHost()
      and option("desktop_mouse_ab", false) == true then
    local stack = game and game.stack
    local top = stack and type(stack.top) == "function" and stack:top() or nil
    if top and top ~= game.overworld then
      mod.input:tap(game, "a")
      state.stats.desktopATaps = (state.stats.desktopATaps or 0) + 1
      return true
    end
  end

  local eligible = ev.source == "touch"
    or (ev.source == "mouse" and ev.button == 1 and option("mouse", false) == true)
  local id = ev.id
  local simpleMode = ControlsFree.simpleTouchEnabled()

  if ev.phase == "pressed" then
    if eligible then
      local owns = state.tapOwner == nil and state.twoFingerGesture == nil
      if owns then state.tapOwner = id end
      if owns then state.gestureSerial = (state.gestureSerial or 0) + 1 end
      local simpleStartCentered = false
      if owns and simpleMode then
        local comps = ControlsFree.simpleTouchComponents({ x = ev.x, y = ev.y })
        simpleStartCentered = comps and #comps == 0 or false
      end
      local p = {
        startX = ev.x, startY = ev.y,
        x = ev.x, y = ev.y,
        pressTick = state.tick,
        lastRetargetTick = state.tick,
        holdActive = false,
        feedbackShown = owns,
        ignored = not owns,
        gestureId = owns and state.gestureSerial or nil,
        simpleMode = simpleMode and true or false,
        simpleMixAcc = 0,
        simpleLongPressAction = nil,
        simpleAvatarHoldCancelled = false,
        -- Snapshot avatar ownership at pointer-DOWN. Camera motion and Voxel
        -- reprojection later in the gesture must not change what was clicked.
        startedOnPlayer = owns and (simpleMode and simpleStartCentered
          or (ControlsFree.playerScreenHit
            and ControlsFree.playerScreenHit(game, ev.x, ev.y) == true)) or false,
      }
      state.pointers[id] = p
      local playerHold = state.playerHoldTouches and state.playerHoldTouches[id]
      if playerHold and not playerHold.cancelled and not playerHold.fired then
        p.playerHoldCandidate = true
        p.feedbackShown = false
      end
      trackTwoFingerPointer(game, ev)
      if state.twoFingerGesture then
        suppressGesturePointer(id)
        owns = false
        p.ignored = true
      end

      -- The first route is acquired NOW, not after TAP/HOLD delay or release,
      -- except for a touch that began on the visible player: that one reserves
      -- one second for HOLD PLAYER -> START and becomes normal navigation only
      -- if the finger moves far enough to cancel the hold candidate.
      -- A target may carry an interaction, but interactionAtDestination gates
      -- A on this gesture no longer being down.
      if owns and not p.playerHoldCandidate
          and not pointerOverTouchControl(game, ev.x, ev.y) then
        if simpleMode then
          -- Mutual exclusion: no world target acquisition, Voxel picking or A*.
          if state.nav then cancelRoute("simple_touch_enabled") end
          state.exitJourney = nil
          state.pendingRemoteGoal = nil
          p.simpleMode = true
          p.initialAccepted = true
        else
          -- Avatar taps are semantic interactions, not urgent locomotion.
          -- Defer avatar A to RELEASE so a drag can still promote back into
          -- ordinary navigation instead of firing A on touch-down. A drag
          -- that leaves the avatar slop below promotes
          -- back into ordinary immediate navigation in the moved branch.
          if p.startedOnPlayer then
            p.avatarTapDeferred = true
            p.initialAccepted = true
          else
            local accepted = startRoute(game, ev.x, ev.y, false, true, p.gestureId)
            p.initialAccepted = accepted and true or false
            if accepted then
              state.stats.immediatePressRoutes =
                (state.stats.immediatePressRoutes or 0) + 1
            end
          end
        end
      end
    end
  elseif ev.phase == "moved" then
    local p = state.pointers[id]
    if p then
      p.x, p.y = ev.x, ev.y
      if p.simpleMode and p.startedOnPlayer and not p.simpleLongPressAction
          and ControlsFree.simplePointerMovedTooFar(p) then
        p.simpleAvatarHoldCancelled = true
      end
    end
    trackTwoFingerPointer(game, ev)
    if p and p.avatarTapDeferred then
      local adx, ady = ev.x - p.startX, ev.y - p.startY
      if adx * adx + ady * ady
          > PLAYER_HOLD_MOVE_SLOP_UNITS * PLAYER_HOLD_MOVE_SLOP_UNITS then
        p.avatarTapDeferred = false
        p.pressTick = state.tick
        p.lastRetargetTick = state.tick
        if not p.ignored and not p.gestureSuppressed
            and not pointerOverTouchControl(game, ev.x, ev.y) then
          local accepted = startRoute(game, ev.x, ev.y, false, true, p.gestureId)
          p.initialAccepted = accepted and true or false
          if accepted then
            state.stats.immediatePressRoutes =
              (state.stats.immediatePressRoutes or 0) + 1
          end
        end
      end
    end
    if p and p.playerHoldCandidate then
      local ph = state.playerHoldTouches and state.playerHoldTouches[id]
      if not ph or ph.cancelled then
        p.playerHoldCandidate = false
        p.pressTick = state.tick
        p.lastRetargetTick = state.tick
        if not p.ignored and not p.gestureSuppressed
            and not pointerOverTouchControl(game, ev.x, ev.y) then
          if simpleMode then
            p.simpleMode = true
            p.initialAccepted = true
          else
            local accepted = startRoute(game, ev.x, ev.y, false, true, p.gestureId)
            p.initialAccepted = accepted and true or false
            if accepted then
              state.stats.immediatePressRoutes =
                (state.stats.immediatePressRoutes or 0) + 1
            end
          end
        end
      end
    end
  elseif ev.phase == "released" then
    local p = state.pointers[id]
    if p then p.x, p.y = ev.x, ev.y end
    trackTwoFingerPointer(game, ev)
    if p and not p.ignored and not p.gestureSuppressed then
      if simpleMode then
        ControlsFree.releaseSimpleHold()
        ControlsFree.finishSimpleGesture(game, p)
      else
      -- Ordinary avatar taps were deliberately deferred at pointer-down so
      -- native hidden-object rescue stays release-gated. Resolve them now.
      if p.avatarTapDeferred then
        p.avatarTapDeferred = false
        if not pointerOverTouchControl(game, p.startX, p.startY) then
          local accepted = startRoute(game, p.startX, p.startY, false, true, p.gestureId)
          p.initialAccepted = accepted and true or false
          if accepted then
            state.stats.immediatePressRoutes =
              (state.stats.immediatePressRoutes or 0) + 1
          end
        end
      -- HOLD PLAYER SPRITE reserves a stationary avatar touch for START. If it
      -- is released before the one-second START threshold, reinterpret that
      -- short touch now as an ordinary avatar tap. startRoute's avatar proxy
      -- can then target the interaction/door directly in front of the player.
      elseif p.playerHoldCandidate then
        local ph = state.playerHoldTouches and state.playerHoldTouches[id]
        if ph and not ph.fired and not ph.cancelled
            and not pointerOverTouchControl(game, p.startX, p.startY) then
          local accepted = startRoute(game, p.startX, p.startY, false, true, p.gestureId)
          p.initialAccepted = accepted and true or false
          if accepted then
            state.stats.immediatePressRoutes =
              (state.stats.immediatePressRoutes or 0) + 1
          end
        end
      elseif p.holdActive and not state.exitJourney and not p.stickySemantic then
        -- Pin an ordinary steering gesture to its final screen position.
        -- A semantic door/NPC selection is different: RELEASE is not another
        -- steering sample, it only ends the gesture (and for NPCs authorizes
        -- the already-armed interaction). Periodic held-input ticks are what
        -- may replace a sticky door with a genuinely legal movement target.
        if not pointerOverTouchControl(game, ev.x, ev.y) then
          startRoute(game, ev.x, ev.y, true, false, p.gestureId)
        end
      end
      -- Non-hold release intentionally does NOT start a second route. The
      -- press already did that; removing the pointer is itself the signal that
      -- an armed interaction may execute when its approach cell is reached.
      end -- not SIMPLE TOUCH MOVEMENT
    end
    state.pointers[id] = nil
    if state.tapOwner == id then state.tapOwner = nil end
  elseif ev.phase == "cancelled" then
    local p = state.pointers[id]
    if p and p.simpleMode then ControlsFree.releaseSimpleHold() end
    trackTwoFingerPointer(game, ev)
    if state.playerHoldTouches and state.playerHoldTouches[id] then
      state.playerHoldTouches[id] = nil
    end
    state.pointers[id] = nil
    if state.tapOwner == id then state.tapOwner = nil end
    -- A cancelled OS gesture is neither a tap nor a deliberate hold release.
    -- Do not let disappearing pointer state accidentally authorize A.
    if p and not p.ignored and state.nav then
      cancelRoute("pointer_cancelled")
    end
  end

  return result
end)

local function pointerSteeringTick(game)
  if ControlsFree.simpleTouchEnabled() then return end
  if not ControlsFree.mapRuntimeReady(game) then return end
  -- A semantic "leave this interior" command owns its route across internal
  -- floors. The original held finger must not reinterpret the new room camera
  -- every performance tick and accidentally replace that journey. A fresh
  -- pointer press still supersedes it immediately in startRoute.
  if state.exitJourney then return end
  if option("hold_steer", true) == false then return end
  local id = state.tapOwner
  local p = id and state.pointers[id]
  if not p or p.ignored or p.manualSuppressed or p.gestureSuppressed then return end
  if p.playerHoldCandidate then return end
  if pointerOverTouchControl(game, p.x, p.y) then return end
  local age = state.tick - (p.pressTick or state.tick)
  local startTicks = holdSteerDelayTicks(game)
  if age < startTicks then return end

  -- HOLD STEER DELAY controls only when continuous steering begins. The
  -- initial destination has already been walking since pointer press.
  if p.holdActive then
    if state.tick - (p.lastRetargetTick or p.pressTick or 0)
        < holdRefreshTicks() then
      return
    end
  else
    p.holdActive = true
    disarmInteractionForGesture(p.gestureId, "hold_steer")
  end

  -- A stationary held pointer can hit the retarget timer repeatedly while
  -- absolutely nothing in the navigation state has changed (e.g. standing
  -- still against a temporary blocker). In that exact case re-projecting the
  -- same pointer and rebuilding the same A* request is pure duplicate work.
  -- Do NOT skip while the player changes cell/map or the route needs a replan.
  local cur = mod.world and mod.world:current()
  local sameRetargetState = p.lastRetargetScreenX == p.x
    and p.lastRetargetScreenY == p.y
    and cur
    and p.lastRetargetMapId == cur.mapId
    and p.lastRetargetPlayerX == cur.x
    and p.lastRetargetPlayerY == cur.y
    and state.nav
    and not state.nav.needsReplan
    and not state.exitJourney
  if sameRetargetState then
    p.lastRetargetTick = state.tick
    state.stats.holdRetargetSkips =
      (state.stats.holdRetargetSkips or 0) + 1
    return
  end

  p.lastRetargetTick = state.tick
  if cur then
    p.lastRetargetScreenX, p.lastRetargetScreenY = p.x, p.y
    p.lastRetargetMapId = cur.mapId
    p.lastRetargetPlayerX, p.lastRetargetPlayerY = cur.x, cur.y
  end
  local accepted = startRoute(game, p.x, p.y, true, false, p.gestureId)
  if accepted then
    state.stats.holdRetargets = state.stats.holdRetargets + 1
  end
end

-- Fixed-step input seam: directions pressed here affect the same gameplay tick.
mod.hooks:wrap("input.step", function(nextFn, game, dt)
  restoreNativeZoomSuppression(game)
  if state.twoFingerGesture then
    restoreGestureZoom(game, state.twoFingerGesture)
  end
  -- Clean up raw reservations if the mobile OS consumed/cancelled a physical
  -- touch without a normal release callback.
  ControlsFree.pruneSystemEdgeTouches()
  ControlsFree.prunePinchGraceTouches()
  -- Let an ordinary first world touch through once the PINCH OR SPREAD pairing
  -- tolerance expires. If a second finger arrived, beginRawTwoFingerGesture has
  -- already marked the candidate suppressed and nothing is replayed.
  ControlsFree.promotePinchGraceTouches(game)
  -- DIALOG/BATTLE TOUCH CONTROL each include their own stationary 1-second
  -- hold -> B gesture. This is independent from overworld Tap to Move.
  ControlsFree.holdBTouchTick(game)
  -- START/SELECT TOUCH CONTROL is independent from the TAP TO MOVE switch.
  -- Its own OFF/HOLD/PINCH-SPREAD choice is authoritative.
  ControlsFree.playerHoldStartTick(game)

  local simpleNow = ControlsFree.simpleTouchEnabled()
  if simpleNow ~= state.simpleModeLast then
    if simpleNow then
      if state.nav then cancelRoute("simple_touch_enabled") end
      state.exitJourney = nil
      state.pendingRemoteGoal = nil
      state.battleResume = nil
    else
      ControlsFree.releaseSimpleHold()
      state.simpleInteraction = nil
    end
    state.simpleModeLast = simpleNow
  end
  if simpleNow then
    -- navigationTick owns the normal-mode clock. SIMPLE bypasses that entire
    -- pathfinder, so advance the shared fixed-step clock here instead; without
    -- this, long-press timing and blocked-direction retry windows never age.
    state.tick = state.tick + 1
    state.game = game
    ControlsFree.simpleMovementTick(game)
  else
    ControlsFree.releaseSimpleHold()
    pointerSteeringTick(game)
    navigationTick(game)
  end
  return nextFn(game, dt)
end)

-- Observe the FINAL collision verdict.  Dynamic NPCs are temporary obstacles;
-- stationary entities become blocked cells; static tile/elevation failures are
-- learned as directed edges.  Every case replans instead of repeatedly bonking.
mod.hooks:wrap("movement.collision", function(nextFn, allowed, ctx)
  local result = nextFn(allowed, ctx)
  local nav = state.nav
  local game = state.game
  if not nav or not ctx or not game then return result end

  local player = WorldBackend.player(game)
  if not player or ctx.mover ~= player then return result end

  -- A different direction reaching the player's collision path means another
  -- input source won.  Manual control always has priority over autowalk.
  if nav.holdDir and ctx.dir ~= nav.holdDir then
    cancelRoute("manual_override")
    return result
  end

  -- Some Gen I exit warp records sit on collision cells that are not in the
  -- tileset's ordinary walkable list. mapOverview therefore reports them as
  -- blank/solid and vanilla Collision.canMove returns reason="tile" when the
  -- player tries to WALK BACK onto the source after leaving it. A validated
  -- Tap-to-Move EXIT route may override only that exact final step.
  --
  -- Safety constraints:
  --   * exact active EXIT goal only (never an intermediate node),
  --   * an actual warp record must exist on the destination cell,
  --   * only the engine's non-walkable-tile rejection is bypassed,
  --   * entity/bounds failures and tile-pair/elevation failures remain final.
  if not WorldBackend.isGold(game)
      and result == false and ctx.reason == "tile"
      and nav.goalKind == "exit" and nav.exitIntent ~= nil
      and nav.exitDir ~= nil
      and nav.holdDir == ctx.dir
      and nav.targetX == ctx.toX and nav.targetY == ctx.toY
      and nav.expectedX == ctx.toX and nav.expectedY == ctx.toY then
    local map = WorldBackend.map(game)
    local hasWarp = map and type(map.warpAtCell) == "function"
      and map:warpAtCell(ctx.toX, ctx.toY) ~= nil
    local ordinaryWalkable = map and type(map.isWalkableCell) == "function"
      and map:isWalkableCell(ctx.toX, ctx.toY) == true
    if hasWarp and not ordinaryWalkable then
      state.stats.exitGoalCollisionOverrides =
        (state.stats.exitGoalCollisionOverrides or 0) + 1
      ctx.reason = "tap_to_move_exit_goal"
      return true
    end
  end

  if result == false and nav.holdDir == ctx.dir
      and nav.expectedX == ctx.toX and nav.expectedY == ctx.toY then
    state.stats.collisions = state.stats.collisions + 1
    releaseHold(nav)

    if ctx.reason == "entity" then
      local _, dynamic = liveOccupancy(game)
      local targetKey = key(ctx.toX, ctx.toY)
      if dynamic[targetKey] then
        nav.tempBlocked[targetKey] = state.tick + ENTITY_BLOCK_TICKS
      else
        nav.blockedCells[targetKey] = true
      end
    else
      nav.blockedEdges[edgeKey(ctx.fromX, ctx.fromY, ctx.toX, ctx.toY)] = true
    end
    requestReplan(nav, "collision_" .. tostring(ctx.reason or "unknown"))
  end

  return result
end)

-- Gen1Recomp normally maps the vertical mouse wheel to survey zoom. OFF
-- preserves that native behavior. Horizontal wheel tilt arrives through the
-- same LÖVE wheel callback as dx when the mouse + driver actually expose it.
-- Keep the two axes independently configurable and choose the dominant axis
-- for mixed/trackpad events so one gesture never emits two D-pad taps.
function ControlsFree.installMouseWheelBridge(game)
  if state.mouseWheelBridgeInstalled or not game
      or type(game.wheelmoved) ~= "function" then
    return false
  end
  state.mouseWheelOriginal = game.wheelmoved
  game.wheelmoved = function(self, dx, dy, direction)
    local wheelMode = tostring(option("mouse_wheel_control", "off") or "off")
    local tiltMode = tostring(option("mouse_wheel_tilt", "off") or "off")
    local enabled = option("enabled", true) ~= false
    local nx = type(dx) == "number" and dx or 0
    local ny = type(dy) == "number" and dy or 0
    local ax, ay = math.abs(nx), math.abs(ny)

    if enabled and ax > ay and nx ~= 0 and tiltMode ~= "off" then
      local mapped = nx > 0 and "right" or "left"
      if tiltMode == "on_flipped" then
        mapped = mapped == "right" and "left" or "right"
      end
      mod.input:tap(self, mapped)
      state.stats.mouseWheelTiltTaps = (state.stats.mouseWheelTiltTaps or 0) + 1
      state.stats["mouseWheelTilt_" .. mapped] =
        (state.stats["mouseWheelTilt_" .. mapped] or 0) + 1
      return true
    end

    if enabled and ay >= ax and ny ~= 0 and wheelMode ~= "off" then
      local mapped = ny > 0 and "up" or "down"
      if wheelMode == "on_flipped" then
        mapped = mapped == "up" and "down" or "up"
      end
      mod.input:tap(self, mapped)
      state.stats.mouseWheelTaps = (state.stats.mouseWheelTaps or 0) + 1
      state.stats["mouseWheel_" .. mapped] =
        (state.stats["mouseWheel_" .. mapped] or 0) + 1
      return true
    end

    return state.mouseWheelOriginal(self, dx, dy, direction)
  end
  state.mouseWheelBridgeInstalled = true
  return true
end

-- Immediate lifecycle release, before the next fixed input tick.  These public
-- events close the two most important transition races: entering a new map
-- while a direction is held, and a battle beginning from a walking step.
mod.events:on("game.ready", function(ev)
  local game = ev and ev.game or nil
  if game then
    state.game = game
    installRawPinchZoomGuard(game)
    ControlsFree.installTouchDialogueBridge(game)
    ControlsFree.installMouseWheelBridge(game)
    ControlsFree.installNativeControlsToggle(game)
  end
end)

mod.events:on("world.interacted", function(ev)
  local pending = state.pendingInteraction
  if not pending then return end
  if state.tick - pending.tick <= 3 then
    state.stats.interactionsConfirmed = state.stats.interactionsConfirmed + 1
    state.lastStop = {
      reason = "interaction_confirmed", tick = state.tick,
      mapId = ev and ev.mapId or pending.mapId,
      targetX = pending.x, targetY = pending.y,
    }
    state.pendingInteraction = nil
  end
end)

local function mapDefIsOutdoor(game, def)
  if type(def) ~= "table" then return nil end
  return defLooksOutdoor(game, def)
end

-- "Non-outdoor" is much broader than "entered a building" in Gen I. Route
-- gates, forest gates, caves, tunnels, ship ports and other technical map
-- segments are separate mapIds too, but a held destination should continue
-- through those transitions. Only room-style building tilesets get the
-- release-and-press-again safety boundary.
local BUILDING_INTERIOR_TILESETS = {
  REDS_HOUSE_1 = true, REDS_HOUSE_2 = true,
  MART = true, POKECENTER = true, GYM = true, HOUSE = true,
  DOJO = true, MUSEUM = true, CEMETERY = true, INTERIOR = true,
  LOBBY = true, MANSION = true, LAB = true, CLUB = true,
  FACILITY = true,
}

function ControlsFree.mapDefIsBuildingInterior(def)
  if type(def) ~= "table" then return false end
  if def.environment ~= nil then
    return tostring(def.environment) == "INDOOR"
  end
  -- Mod-authored maps can opt in explicitly instead of borrowing a vanilla
  -- tileset merely to communicate semantics.
  if def.building ~= nil then return def.building == true end
  if def.indoorBuilding ~= nil then return def.indoorBuilding == true end
  return BUILDING_INTERIOR_TILESETS[tostring(def.tileset or "")] == true
end

-- A held screen-space destination is meaningful across route/town seams and
-- across technical map segmentation. A real doorway from outside into a
-- room-style building is different: the camera snaps to a new room while the
-- old finger is still down, and reusing that coordinate commonly sends the
-- player straight back to the exit. Consume the gesture ONLY for that case.
local function enteringBuildingInterior(ev)
  if not ev or ev.via ~= "warp" or not ev.fromMapId then return false end
  local game = state.game
  local maps = WorldBackend.mapDefinitions(game)
  local fromDef = maps and maps[ev.fromMapId] or nil
  local toDef = ev.map and ev.map.def or (maps and maps[ev.mapId])
  return mapDefIsOutdoor(game, fromDef) == true
    and ControlsFree.mapDefIsBuildingInterior(toDef)
end

function ControlsFree.flushMapSensitiveRuntimeCaches()
  -- These caches are deliberately cheap to rebuild and are tied to the live
  -- contents of the current overworld/map. Flush them explicitly at the map
  -- boundary instead of relying only on table-identity changes; Gen1Recomp may
  -- repopulate some live tables in place.
  ControlsFree.occupancyCache = nil
  ControlsFree.neighborLookupCache = nil
  state.previewCache = nil
  state.frame = nil
  state.lastVoxelPick = nil
  state.stats.mapTransitionFlushes =
    (state.stats.mapTransitionFlushes or 0) + 1
end

function ControlsFree.beginMapTransition(ev)
  ControlsFree.flushMapSensitiveRuntimeCaches()
  state.mapTransition = {
    mapId = ev and ev.mapId or nil,
    enteredTick = state.tick,
    via = ev and ev.via or nil,
  }
end

function ControlsFree.mapRuntimeReady(game)
  local pending = state.mapTransition
  if not pending then return true end

  local cur = mod.world and mod.world:current()
  local overview = WorldBackend.overview(game)
  local liveMap = WorldBackend.map(game)
  local expected = pending.mapId

  -- Do not perform path/retarget work against a half-switched world. The
  -- transition is ready only after every public/live authority that carries a
  -- map id agrees on the destination.
  local ready = cur and overview and liveMap
    and (expected == nil or cur.mapId == expected)
    and (expected == nil or overview.mapId == expected)
    and (expected == nil or liveMap.id == expected)

  if not ready then
    state.stats.mapTransitionWaitTicks =
      (state.stats.mapTransitionWaitTicks or 0) + 1
    return false
  end

  state.mapTransition = nil
  state.stats.mapTransitionReady =
    (state.stats.mapTransitionReady or 0) + 1
  return true
end

mod.events:on("map.entered", function(ev)
  ControlsFree.beginMapTransition(ev)
  ControlsFree.releaseSimpleHold()
  state.simpleInteraction = nil
  state.view = nil
  invalidateLoadedMapOverviewCache()
  invalidateVoxelCandidateCache()
  if ev and ev.via ~= "connection" then invalidateLedgeTopologyCache() end
  if enteringBuildingInterior(ev) and suppressCurrentGesture("building_entry") then
    state.stats.entryGestureSuppressions = state.stats.entryGestureSuppressions + 1
  end
  local nav = state.nav
  if nav and nav.cross and not nav.cross.crossed and ev
      and ev.via == "connection" and ev.mapId == nav.cross.destMapId then
    releaseHold(nav)
    nav.cross.crossed = true
    nav.mapId = ev.mapId
    nav.targetX, nav.targetY = nav.cross.targetX, nav.cross.targetY
    nav.path, nav.index = nil, 1
    nav.lastX, nav.lastY = nav.cross.entryX, nav.cross.entryY
    nav.connectionEnteredTick = state.tick
    setPhase(nav, "WAITING_CONNECTION_STEP", "seam_step")
  elseif nav and nav.exitJourney and ev and ev.via == "warp" then
    -- An off-map exit request is one semantic command even when the building
    -- spans several mapIds/floors. Internal stairs/doors therefore retire only
    -- the current leg; once the warp transition clears, navigationTick plans
    -- the next leg automatically. Reaching an outdoor map ends the journey.
    releaseHold(nav)
    state.nav = nil
    local game = state.game
    local maps = WorldBackend.mapDefinitions(game)
    local toDef = ev.map and ev.map.def or (maps and maps[ev.mapId])
    local journey = state.exitJourney or { startedTick = state.tick, legs = 1, visited = {} }
    if defLooksOutdoor(game, toDef) then
      if journey.remoteGoal then
        state.pendingRemoteGoal = copyFlat(journey.remoteGoal)
        markStop("portal_reached_outdoor", nav)
        state.exitJourney = nil
      else
        state.stats.routesArrived = state.stats.routesArrived + 1
        markStop("exited_interior", nav)
        state.exitJourney = nil
      end
    else
      journey.pendingMapId = ev.mapId
      journey.pendingTick = state.tick
      state.exitJourney = journey
      state.stats.exitJourneyTransitions = state.stats.exitJourneyTransitions + 1
      markStop("exit_leg_warped", nav)
    end
  else
    cancelRoute("map_entered")
  end
  local resume = state.battleResume
  if resume and ev and ev.mapId and ev.mapId ~= resume.mapId then
    dropBattleResume("map_changed")
  end
end)

function ControlsFree.safeBattleResumeStart(game, ev, nav)
  local battle = ev and ev.battle
  if not (nav and nav.goalKind == "move" and battle) then return false end
  if WorldBackend.isGold(game) then
    -- The event kind is the shared cross-generation seam. Gold's Battle object
    -- itself uses .wild rather than Gen 1's .kind. Resume only the untyped,
    -- ordinary random-wild shape; special/tutorial/fishing/roamer/contest and
    -- scripted battle variants fail closed.
    if ev.kind ~= "wild" or battle.wild ~= true or battle.trainer ~= nil then
      return false
    end
    if ev.battleType ~= nil or battle.battleType ~= nil or battle.roaming ~= nil then
      return false
    end
    local world = WorldBackend.owner(game)
    local save = game and game.save
    if (world and (world.catchTutorial or world.scriptBattle or world.queuedBattle))
        or (save and save.bugContest and save.bugContest.active) then
      return false
    end
    return true
  end
  return battle.kind == "wild"
end

mod.events:on("battle.started", function(ev)
  ControlsFree.releaseSimpleHold()
  state.simpleInteraction = nil
  local nav = state.nav
  local battle = ev and ev.battle
  if option("battle_resume", false) == true
      and ControlsFree.safeBattleResumeStart(state.game, ev, nav) then
    state.battleResume = {
      mapId = nav.mapId, x = nav.requestedX or nav.targetX,
      y = nav.requestedY or nav.targetY, battle = battle,
      startedTick = state.tick, ready = false,
    }
  else
    state.battleResume = nil
  end
  cancelRoute("battle_started")
  state.pendingInteraction = nil
end)

mod.events:on("battle.ended", function(ev)
  local resume = state.battleResume
  if not resume then return end
  local battle = ev and ev.battle
  local result = ev and ev.result
  if not battle or battle ~= resume.battle
      or (not WorldBackend.isGold(state.game) and battle.kind ~= "wild") then
    dropBattleResume("battle_mismatch")
    return
  end
  if result == "lose" or result == "nuzlocke_game_over" then
    dropBattleResume("loss")
    return
  end
  resume.battle = nil
  resume.ready = true
  resume.endedTick = state.tick
  -- One fixed tick gives the battle's onFinish/afterBattle chain priority to
  -- install any post-battle state before we ask whether the overworld is free.
  resume.readyTick = state.tick + 1
end)


mod.events:on("battle.ended", function()
  -- Never emit a late A/D-pad after the battle disappeared under a held
  -- finger. Keep battleCameraOwnedTouches until each physical contact releases
  -- so a late drag still cannot leak into whatever state the battle revealed.
  for _, t in pairs(state.battleTouches or {}) do t.suppressed = true end
end)

mod.events:on("save.loading", function()
  ControlsFree.releaseSimpleHold()
  state.simpleInteraction = nil
  cancelRoute("save_loading")
  invalidateLedgeTopologyCache()
  invalidateLoadedMapOverviewCache()
  invalidateVoxelCandidateCache()
  state.pointers = {}
  state.gestureTouches = {}
  state.rawZoomTouches = {}
  state.dialogTouches = {}
  state.battleTouches = {}
  state.battleCameraOwnedTouches = {}
  state.playerHoldTouches = {}
  state.systemEdgeTouches = {}
  state.pinchGraceTouches = {}
  state.rawDispatchedTouches = {}
  state.nativeControlOwnedTouches = {}
  state.nativeControlsToggleTouches = {}
  state.twoFingerGesture = nil
  state.tapOwner = nil
  state.pendingInteraction = nil
  state.battleResume = nil
  state.exitJourney = nil
  state.pendingRemoteGoal = nil
  state.mapTransition = nil
  ControlsFree.flushMapSensitiveRuntimeCaches()
end)

-- Small Game Boy-friendly screen-space feedback.  Accepted destinations get a
-- ring; invalid targets get an X.  No persistent route is painted over the map.
local function drawFeedback()
  local p = state.pulse
  if not p or state.tick > p.untilTick or not (love and love.graphics) then
    if p and state.tick > p.untilTick then state.pulse = nil end
    return
  end

  local life = math.max(0, p.untilTick - state.tick)
  local alpha = math.min(1, life / 10)
  local radius = 5 + (15 - life) * 0.45
  love.graphics.push("all")
  love.graphics.origin()
  love.graphics.setColor(1, 1, 1, alpha)
  love.graphics.setLineWidth(2)
  if p.kind == "invalid" then
    local r = radius * 0.7
    love.graphics.line(p.x - r, p.y - r, p.x + r, p.y + r)
    love.graphics.line(p.x + r, p.y - r, p.x - r, p.y + r)
  else
    love.graphics.circle("line", p.x, p.y, radius)
    if p.kind == "interaction" then
      love.graphics.circle("fill", p.x, p.y, math.max(1.5, radius * 0.16))
    end
  end
  love.graphics.pop()
end

local function flatPreviewContext(game)
  local cur = mod.world and mod.world:current()
  if not cur then return nil end

  if WorldBackend.isGold(game) then
    local world = WorldBackend.owner(game)
    if not (world and world.camera and type(world.zoomScale) == "function") then
      return nil
    end
    local g = ControlsFree.goldFrameGeometry(game, cur.mapId)
    if not g then return nil end
    local ww, wh = tonumber(g.windowW), tonumber(g.windowH)
    local scale = tonumber(g.scale)
    if not (ww and wh and scale and scale > 0) then return nil end
    state.stats.flatPreviewContextBuilds =
      (state.stats.flatPreviewContextBuilds or 0) + 1
    return {
      view = { ox = tonumber(g.originX) or 0, oy = tonumber(g.originY) or 0,
               scale = scale, dpiX = 1, dpiY = 1 },
      -- Gold's view.ox/oy are the ACTUAL map render origin, not a canvas
      -- letterbox.  Keep camera at zero here so flatPathCellToScreen applies
      -- that origin exactly once.
      cameraX = 0, cameraY = 0,
      right = ww, bottom = wh, generation = 2,
      goldFrame = g,
    }
  end

  local view = state.view
  if not view then return nil end
  local ppx, ppy = playerPixel(game, cur)
  state.stats.flatPreviewContextBuilds =
    (state.stats.flatPreviewContextBuilds or 0) + 1
  return {
    view = view,
    cameraX = ppx - (view.worldW / 2 - 16),
    cameraY = ppy - (view.worldH / 2 - 8),
    right = view.ox + view.worldW * view.scale,
    bottom = view.oy + view.worldH * view.scale,
  }
end

local function flatPathCellToScreen(ctx, x, y)
  if not ctx then return nil end
  local view = ctx.view
  local canvasX = x * TILE_SIZE + TILE_SIZE / 2 - ctx.cameraX
  local canvasY = y * TILE_SIZE + TILE_SIZE / 2 - ctx.cameraY
  local px = view.ox + canvasX * view.scale
  local py = view.oy + canvasY * view.scale
  if ctx.generation == 2 and ctx.goldFrame and ctx.goldFrame.tiltActive then
    px, py = ControlsFree.goldFrameFlatToScreen(
      state.game, px, py, ctx.goldFrame.mapId)
    if not px then return nil end
  end
  if px < view.ox or py < view.oy or px >= ctx.right or py >= ctx.bottom then
    return nil
  end
  state.stats.flatPreviewPointTransforms =
    (state.stats.flatPreviewPointTransforms or 0) + 1
  return px / view.dpiX, py / view.dpiY
end

-- Forward projection for HUD overlays while a render pipeline owns the world.
-- Voxel3D.project returns coordinates in the Voxel framebuffer canvas; the HUD
-- is drawn in LOVE window units, so invert the same canvas/window mapping used
-- by framebufferPoint().  This deliberately reads the live Voxel canvas instead
-- of guessing from dpi alone.
local PREVIEW_MAX_FULL_DOTS = 48

-- Build the Voxel preview transform once per rendered frame/path pass. test7
-- rebuilt candidate-map, canvas-size, DPI and TileShape state for EVERY dot;
-- FULL preview under a continuously retargeting hold could therefore turn a
-- 50-cell route into thousands of redundant table walks/projections per second.
local function voxelPreviewContext(game, scene, mapId)
  local voxel3d = scene and scene.voxel3d
  if not voxel3d or type(voxel3d.project) ~= "function" then return nil end

  local overview = WorldBackend.overview(game)
  local entry
  for _, cand in ipairs(voxelCandidateMaps(game, overview)) do
    if cand.mapId == mapId then entry = cand break end
  end
  if not entry then return nil end

  local cw, ch = VoxelAdapter.canvasSize(scene)
  local ww, wh = VoxelAdapter.windowSize()
  if not (cw and ch and ww and wh) then return nil end

  return {
    scene = scene, voxel3d = voxel3d, entry = entry,
    cw = cw, ch = ch, ww = ww, wh = wh,
  }
end

local function voxelPreviewGroundHeight(ctx, x, y)
  return VoxelAdapter.groundHeight(ctx.scene, ctx.entry and ctx.entry.map, x, y)
end

local function voxelPathCellToScreen(ctx, x, y)
  local entry, voxel3d = ctx.entry, ctx.voxel3d
  local wx = entry.ox + (x + 0.5) * TILE_SIZE
  local wz = entry.oy + (y + 0.5) * TILE_SIZE
  local h = voxelPreviewGroundHeight(ctx, x, y) + 0.5
  local p = projectedPoint(voxel3d, wx, wz, h)
  if not p then return nil end
  if p[1] < 0 or p[2] < 0 or p[1] >= ctx.cw or p[2] >= ctx.ch then
    return nil
  end
  local sx, sy = VoxelAdapter.canvasToWindow(ctx.scene, p[1], p[2])
  if not sx then return nil end
  return sx, sy, p[3]
end

local function drawPathPreview(game)
  if state.mapTransition then
    state.previewCache = nil
    return
  end
  local mode = option("path_preview", "off")
  local nav = state.nav
  if mode == "off" or not nav or not nav.previewUntil
      or state.tick > nav.previewUntil or not (love and love.graphics) then
    state.previewCache = nil
    return
  end

  local path = nav.path or {}
  local first = nav.index or 1
  local last = #path
  if mode ~= "full" then last = math.min(last, first + 5) end
  if last < first then
    state.previewCache = nil
    return
  end

  -- FULL still shows the WHOLE route, but a very long route does not need one
  -- circle for every single cell to communicate its shape. Cap the marker
  -- count and sample evenly; always draw the final node below. This bounds
  -- projection work independently of the selected performance preset.
  local stride = 1
  if mode == "full" then
    local count = last - first + 1
    if count > PREVIEW_MAX_FULL_DOTS then
      stride = math.max(1, math.ceil((count - 1) / (PREVIEW_MAX_FULL_DOTS - 1)))
    end
  end

  local life = math.max(0, nav.previewUntil - state.tick)
  local alpha = math.min(0.75, life / 12)
  local scene = voxelContext()
  local points

  if scene then
    -- The expensive part of a Voxel preview is not drawing a few cached
    -- circles; it is rebuilding map/shape context and projecting every node
    -- through the live 3D camera. VOXEL PATH RATE throttles that work while
    -- cached screen points are still drawn every HUD frame, so very low rates
    -- can be tested without making the preview blink on/off.
    local cache = state.previewCache
    local frame = state.frame or {}
    local refreshEvery = previewRefreshTicks()
    -- Path identity is intentionally NOT part of the immediate-refresh key.
    -- A held pointer can replace nav.path every input sample; if that forced a
    -- projection each time, a 1/s setting would secretly still reproject at
    -- the hold rate. Between scheduled refreshes the last projected route is
    -- deliberately allowed to lag -- exactly what this tuning option exists
    -- to let the player evaluate on real hardware.
    local sameScene = cache
      and cache.scene == scene
      and cache.mapId == nav.mapId
      and cache.mode == mode
      and cache.pw == frame.pw and cache.ph == frame.ph
      and cache.ww == frame.ww and cache.wh == frame.wh
      and cache.dpiX == frame.dpiX and cache.dpiY == frame.dpiY
    local due = not sameScene
      or (state.tick - (cache.projectTick or -1000000) >= refreshEvery)

    if due then
      local vctx = voxelPreviewContext(game, scene, nav.mapId)
      local projected = {}
      if vctx then
        local function addNode(node)
          local sx, sy, scale = voxelPathCellToScreen(vctx, node.x, node.y)
          if sx then
            local r = 1.8 * math.max(0.70, math.min(1.35, scale or 1))
            projected[#projected + 1] = { x = sx, y = sy, r = r }
          end
        end
        local lastDrawn
        for i = first, last, stride do
          addNode(path[i])
          lastDrawn = i
        end
        if lastDrawn ~= last then addNode(path[last]) end
      end
      cache = {
        scene = scene, path = path, mapId = nav.mapId, mode = mode,
        first = first, last = last, stride = stride,
        pw = frame.pw, ph = frame.ph, ww = frame.ww, wh = frame.wh,
        dpiX = frame.dpiX, dpiY = frame.dpiY,
        projectTick = state.tick, points = projected,
      }
      state.previewCache = cache
      state.stats.previewProjectionRefreshes =
        (state.stats.previewProjectionRefreshes or 0) + 1
    else
      state.stats.previewProjectionCacheHits =
        (state.stats.previewProjectionCacheHits or 0) + 1
    end
    points = cache and cache.points or nil
  else
    state.previewCache = nil
  end

  love.graphics.push("all")
  love.graphics.origin()
  love.graphics.setColor(1, 1, 1, alpha)

  if points then
    for _, p in ipairs(points) do
      love.graphics.circle("fill", p.x, p.y, p.r)
    end
  elseif not scene then
    -- Build the flat camera transform ONCE for the whole preview. Previous
    -- builds called mod.world:current() + playerPixel() once per marker,
    -- multiplying identical work by up to PREVIEW_MAX_FULL_DOTS every frame.
    local flatCtx = flatPreviewContext(game)
    local lastDrawn
    for i = first, last, stride do
      local node = path[i]
      local sx, sy = flatPathCellToScreen(flatCtx, node.x, node.y)
      if sx then love.graphics.circle("fill", sx, sy, 1.8) end
      lastDrawn = i
    end
    if lastDrawn ~= last then
      local node = path[last]
      local sx, sy = flatPathCellToScreen(flatCtx, node.x, node.y)
      if sx then love.graphics.circle("fill", sx, sy, 1.8) end
    end
  end
  love.graphics.pop()
end

local function drawDebug()
  if option("debug", false) ~= true or not (love and love.graphics) then return end
  local nav = state.nav
  local lines = {
    "TAP TO MOVE " .. VERSION,
    ("HOLD BASE %dMS X%s = %dMS  RETARGET %s"):format(
      ControlsFree.holdSteerBaseDelayMs(), tostring(ControlsFree.overworldSpeedMultiplier(state.game)),
      ControlsFree.holdSteerDelayMs(state.game), (select(1, performanceInputProfile()).label)),
    ("RETARGET %dMS  PREVIEW /%d"):format(
      select(1, performanceInputProfile()).holdMs, previewRefreshTicks()),
    (function()
      local p, name = ControlsFree.pathBudgetProfile()
      return ("PERF BUDGET %s N%s S%s"):format(
        tostring(p.label or name),
        p.nodes and tostring(p.nodes) or "FULL",
        p.seams and tostring(p.seams) or "ALL")
    end)(),
    ("A* SEARCH/NODES/MAX/HIT %d/%d/%d/%d"):format(
      state.stats.pathSearches or 0,
      state.stats.pathExpanded or 0,
      state.stats.pathMaxExpanded or 0,
      state.stats.pathBudgetHits or 0),
    ("SEAM USED/SKIP %d/%d"):format(
      state.stats.seamCandidatesConsidered or 0,
      state.stats.seamCandidatesSkipped or 0),
    ("CACHE NPC H/M %d/%d  WARP H/M %d/%d"):format(
      state.stats.occupancyCacheHits or 0,
      state.stats.occupancyCacheMisses or 0,
      state.stats.warpCacheHits or 0,
      state.stats.warpCacheMisses or 0),
    ("A* OCC COPY SKIP/REQ %d/%d  NB H/M %d/%d"):format(
      state.stats.occupancyCopiesAvoided or 0,
      state.stats.occupancyCopiesRequired or 0,
      state.stats.neighborLookupHits or 0,
      state.stats.neighborLookupMisses or 0),
    ("MAP FLUSH/WAIT/READY %d/%d/%d %s"):format(
      state.stats.mapTransitionFlushes or 0,
      state.stats.mapTransitionWaitTicks or 0,
      state.stats.mapTransitionReady or 0,
      state.mapTransition and "WAIT" or "OK"),
    ("CROSS FB CELLS/STOP/HIT-SKIP %d/%d/%d"):format(
      state.stats.crossFallbackCellsTested or 0,
      state.stats.crossFallbackBudgetStops or 0,
      state.stats.crossFallbackBudgetExhaustedSkips or 0),
    ("CROSS LOCAL TRY/OK/NO %d/%d/%d D/N %d/%d"):format(
      state.stats.crossLocalFallbackAttempts or 0,
      state.stats.crossLocalFallbackAccepted or 0,
      state.stats.crossLocalFallbackRejected or 0,
      state.stats.crossLocalDirectPath or 0,
      state.stats.crossLocalNearestPath or 0),
    ("EXIT CHEAP/A*/DEFER %d/%d/%d"):format(
      state.stats.exitCandidatesCheap or 0,
      state.stats.exitCandidatesPathScored or 0,
      state.stats.exitCandidatesDeferred or 0),
    ("PREVIEW CTX/PTS %d/%d  HOLD-SKIP %d"):format(
      state.stats.flatPreviewContextBuilds or 0,
      state.stats.flatPreviewPointTransforms or 0,
      state.stats.holdRetargetSkips or 0),
    "TICK " .. tostring(state.tick),
    ("VOXEL %d  RAY %d  COLUMN %d"):format(
      state.stats.voxelTargets or 0, state.stats.voxelRayTargets or 0,
      state.stats.voxelColumnTargets or 0),
    (function()
      local p = VoxelAdapter.discover()
      if not p then return "VOXEL PROVIDER NONE" end
      local cw, ch = VoxelAdapter.canvasSize(p)
      local pw, ph = VoxelAdapter.pixelSize()
      local ready = p.voxelState and p.voxelState.ready ~= false
      if cw and ch and pw and ph then
        return ("VOXEL %s %dx%d>%dx%d %s"):format(
          p.short or p.id, cw, ch, pw, ph, ready and "READY" or "WAIT")
      end
      return ("VOXEL %s %s"):format(p.short or p.id, ready and "READY" or "WAIT")
    end)(),
    ("V-OUT %d  SEM-HIT %d  EDGE-WARP %d"):format(
      state.stats.voxelRayOutside or 0,
      state.stats.voxelSemanticRecoveries or 0,
      state.stats.edgeWarpIntents or 0),
    ("DIR-WARP %d  HOLE %d  EXIT-GOAL %d"):format(
      state.stats.directionalWarpIntents or 0,
      state.stats.holeStepIntents or 0,
      state.stats.exitGoalCollisionOverrides or 0),
    ("CARPET-DOWN %d  CLICK-EXIT %d"):format(
      state.stats.carpetDownIntents or 0,
      state.stats.exitClickBiasedSelections or 0),
    ("AVATAR-HIT %d  HID-PATH %d"):format(
      state.stats.playerAvatarHitDetections or 0,
      state.stats.voxelNativeHiddenPathTargets or 0),
    ("HIDDEN-TREASURE T/A %d/%d"):format(
      state.stats.hiddenTreasureTargets or 0,
      state.stats.hiddenTreasureTriggers or 0),
    ("SURF PLAN/MOUNT/TURN/DENY %d/%d/%d/%d"):format(
      state.stats.seamlessSurfPlans or 0,
      state.stats.seamlessSurfMounts or 0,
      state.stats.seamlessSurfFaceTurns or 0,
      state.stats.seamlessSurfDenied or 0),
    ("CUT TARGET/DIRECT/DENY %d/%d/%d"):format(
      state.stats.cutTargets or 0,
      state.stats.cutDirectTriggers or 0,
      state.stats.cutDenied or 0),
    ("IFACE N/T/V %d/%d/%d"):format(
      state.stats.interactionFaceNeutralTicks or 0,
      state.stats.interactionFaceTurns or 0,
      state.stats.interactionFaceVerified or 0),
    ("NATIVE CTRL %s T%d"):format(
      ControlsFree.nativeControlsVisible(state.game) and "ON" or "OFF",
      state.stats.nativeControlsTogglePresses or 0),
    ("EXIT-DIR A/R/H %d/%d/%d"):format(
      state.stats.exitDirectionalAccepts or 0,
      state.stats.exitDirectionalRejects or 0,
      state.stats.exitContinuousSuppressions or 0),
    ("PRELAND %d  WARP-COMMIT %d"):format(
      state.stats.exitPrelandingCarries or 0,
      state.stats.exitWarpForcedCommits or 0),
    ("V-TILE %s  %s  @%s,%s"):format(
      tostring(state.lastVoxelPick and state.lastVoxelPick.tile or "-"),
      tostring(state.lastVoxelPick and state.lastVoxelPick.class or "-"),
      tostring(state.lastVoxelPick and state.lastVoxelPick.tx or "-"),
      tostring(state.lastVoxelPick and state.lastVoxelPick.ty or "-")),
    ("TOPO %d/%d  OVR %d/%d  ENTRY %d"):format(
      state.stats.topologyCacheHits or 0, state.stats.topologyCacheMisses or 0,
      state.stats.overviewCacheHits or 0, state.stats.overviewCacheMisses or 0,
      state.stats.entryGestureSuppressions or 0),
  }
  local gd = state.lastGoldTapDiagnostic
  if gd then
    local function n1(v)
      return type(v) == "number" and string.format("%.1f", v) or "-"
    end
    table.insert(lines, 2, ("G-TAP S %s,%s  CELL %s,%s -> %s,%s %s"):format(
      n1(gd.screenX), n1(gd.screenY), tostring(gd.rawCellX or "-"),
      tostring(gd.rawCellY or "-"), tostring(gd.finalCellX or "-"),
      tostring(gd.finalCellY or "-"),
      gd.semanticAssist and ("SEM-" .. tostring(gd.semanticAssistKind or "TARGET"))
        or (gd.barrierDoor and "DOOR-BARRIER" or (gd.doorSnap and "DOOR" or ""))))
    table.insert(lines, 3, ("G-CENTER %s,%s  DELTA %s,%s  INTENT %s,%s"):format(
      n1(gd.cellScreenX), n1(gd.cellScreenY), n1(gd.deltaX), n1(gd.deltaY),
      n1(gd.intentX), n1(gd.intentY)))
    table.insert(lines, 4, ("G-FRAME S%s O%s,%s C%s,%s T%s"):format(
      n1(gd.scale), n1(gd.originX), n1(gd.originY), n1(gd.cameraX),
      n1(gd.cameraY), gd.tiltActive and n1(gd.tiltAngle) or "OFF"))
    table.insert(lines, 5, ("G-CAP %s,%s CROP %s,%s ERR %s"):format(
      n1(gd.captureW), n1(gd.captureH), n1(gd.cropX), n1(gd.cropY),
      tostring(gd.targetErr or "OK")))

    -- Snapshot values above are frozen at press time.  Reproject the SAME
    -- world target through the CURRENT camera as a separate diagnostic so a
    -- screenshot taken after walking cannot confuse camera motion with a bad
    -- original pick.
    if gd.mapId and gd.finalCellX ~= nil and gd.finalCellY ~= nil then
      local lx, ly = ControlsFree.goldCellCenterToScreen(
        state.game, gd.mapId, gd.finalCellX, gd.finalCellY)
      gd.liveCellScreenX, gd.liveCellScreenY = lx, ly
      table.insert(lines, 6, ("G-LIVE TARGET %s,%s  STEP-PULSE %d"):format(
        n1(lx), n1(ly), state.stats.goldStepPulses or 0))
    end
  end
  if ControlsFree.simpleTouchEnabled() then
    local p = state.tapOwner and state.pointers[state.tapOwner] or nil
    lines[#lines + 1] = ("SIMPLE %s X%+d%% Y%+d%% F%d D%d BT%d"):format(
      state.simpleHold and tostring(state.simpleHold.dir):upper() or "IDLE",
      math.floor(((p and p.simpleNX) or 0) * 100 + 0.5),
      math.floor(((p and p.simpleNY) or 0) * 100 + 0.5),
      state.stats.simpleTouchFallbacks or 0,
      state.stats.simpleTouchDominantCardinals or 0,
      state.stats.simpleTouchBlockedTurns or 0)
    local dom = ControlsFree.simpleDominanceRatio()
    lines[#lines + 1] = ("SIMPLE CFG C%d%% A%d%% R%s"):format(
      math.floor(ControlsFree.simpleCenterDeadzone() * 100 + 0.5),
      math.floor(ControlsFree.simpleAxisDeadzone() * 100 + 0.5),
      dom == math.huge and "OFF" or (tostring(dom) .. "X"))
  end
  if nav then
    lines[#lines + 1] = "STATE " .. tostring(nav.phase)
    lines[#lines + 1] = ("TARGET %s %d,%d"):format(
      tostring(nav.mapId), nav.targetX or -1, nav.targetY or -1)
    lines[#lines + 1] = ("PATH %d/%d HOLD %s"):format(
      nav.index or 0, #(nav.path or {}), tostring(nav.holdDir or "-"))
    if nav.phaseReason then lines[#lines + 1] = "WHY " .. tostring(nav.phaseReason) end
  else
    lines[#lines + 1] = "STATE IDLE"
    if state.lastStop then lines[#lines + 1] = "LAST " .. tostring(state.lastStop.reason) end
  end

  love.graphics.push("all")
  love.graphics.origin()
  local gd = state.lastGoldTapDiagnostic
  if gd then
    -- Raw pointer: cross. Interpreted cell centre: ring. Player cell centre:
    -- square. Their relative placement is enough to diagnose origin/scale skew
    -- from a single screenshot without the user estimating offsets by eye.
    if gd.screenX and gd.screenY then
      love.graphics.setColor(1, 0.25, 0.25, 1)
      love.graphics.setLineWidth(2)
      love.graphics.line(gd.screenX - 8, gd.screenY, gd.screenX + 8, gd.screenY)
      love.graphics.line(gd.screenX, gd.screenY - 8, gd.screenX, gd.screenY + 8)
    end
    if gd.cellScreenX and gd.cellScreenY then
      love.graphics.setColor(0.2, 1, 1, 1)
      love.graphics.setLineWidth(2)
      love.graphics.circle("line", gd.cellScreenX, gd.cellScreenY, 8)
    end
    if gd.liveCellScreenX and gd.liveCellScreenY then
      -- Current-camera projection of the frozen world target: a larger ring.
      -- This one should travel with the map while the press-time ring stays put.
      love.graphics.setColor(0.3, 1, 0.3, 1)
      love.graphics.setLineWidth(2)
      love.graphics.circle("line", gd.liveCellScreenX, gd.liveCellScreenY, 13)
    end
    if gd.playerScreenX and gd.playerScreenY then
      love.graphics.setColor(1, 0.9, 0.2, 1)
      love.graphics.setLineWidth(2)
      love.graphics.rectangle("line", gd.playerScreenX - 7, gd.playerScreenY - 7, 14, 14)
    end
  end
  local y = 6
  for _, text in ipairs(lines) do
    love.graphics.setColor(0, 0, 0, 0.8)
    love.graphics.print(text, 7, y + 1)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print(text, 6, y)
    y = y + 14
  end
  love.graphics.pop()
end

mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
  local result = nextFn(game, viewport)
  drawPathPreview(game)
  drawFeedback()
  drawDebug()
  return result
end)

local function diagnostics()
  local nav = state.nav
  local perf, perfName = performanceInputProfile()
  local backend = state.game and WorldBackend.forGame(state.game) or nil
  local liveMap = state.game and WorldBackend.map(state.game) or nil
  local controllable, gateReason = state.game and overworldGate(state.game) or false, nil
  if state.game then controllable, gateReason = overworldGate(state.game) end
  local out = {
    version = VERSION,
    generation = state.game and (WorldBackend.isGold(state.game) and 2 or 1) or nil,
    backend = backend == WorldBackend.gold and "gold"
      or (backend == WorldBackend.gen1 and "gen1" or nil),
    mapId = liveMap and liveMap.id or nil,
    controllable = controllable and true or false,
    gateReason = gateReason,
    traversalMode = state.game and ControlsFree.playerIsSurfing(state.game)
      and "SURF" or "LAND",
    tick = state.tick,
    active = nav ~= nil,
    holdRetarget = { mode = perfName, label = perf.label, holdMs = perf.holdMs },
    pathfindingBudget = (function()
      local p, name = ControlsFree.pathBudgetProfile()
      return {
        mode = name, label = p.label, nodes = p.nodes,
        seams = p.seams, exits = p.exits, crossTargets = p.crossTargets,
      }
    end)(),
    voxelPathRate = {
      value = "0.25",
      ticks = previewRefreshTicks(),
      fixed = true,
    },
    simpleTouchMovement = ControlsFree.simpleTouchEnabled(),
    nativeControlsVisible = ControlsFree.nativeControlsVisible(state.game),
    controlsFree = {
      dialogTouchControl = option("dialog_touch_control", false) == true,
      battleTouchControl = option("battle_touch_control", false) == true,
      startSelectTouchControl = startSelectTouchMode(),
      dialogue = option("dialog_touch_control", false) == true,
      dialogueSwipe = option("dialog_touch_control", false) == true,
      battle = option("battle_touch_control", false) == true,
      battleSwipe = option("battle_touch_control", false) == true,
      battleCameraTouchSuppression = option("battle_touch_control", false) == true,
      holdPlayerStart = startSelectTouchMode() == "hold_player_sprite",
      pinchSpreadStartSelect = startSelectTouchMode() == "pinch_or_spread",
      pinchFirstTouchGraceTicks = ControlsFree.PINCH_FIRST_TOUCH_GRACE_TICKS,
      mouseWalk = option("mouse", false) == true,
      desktopMouseAB = option("desktop_mouse_ab", false) == true,
      mouseWheelControl = tostring(option("mouse_wheel_control", "off") or "off"),
      mouseWheelTilt = tostring(option("mouse_wheel_tilt", "off") or "off"),
      mouseSideButtons = tostring(option("mouse_side_buttons", "off") or "off"),
    },
    stats = copyFlat(state.stats),
    lastStop = state.lastStop and copyFlat(state.lastStop) or nil,
    lastGoldTap = state.lastGoldTapDiagnostic and copyFlat(state.lastGoldTapDiagnostic) or nil,
  }
  if nav then
    out.navigation = {
      phase = nav.phase,
      phaseReason = nav.phaseReason,
      goalKind = nav.goalKind,
      mapId = nav.mapId,
      targetX = nav.targetX,
      targetY = nav.targetY,
      requestedMapId = nav.requestedMapId,
      requestedX = nav.requestedX,
      requestedY = nav.requestedY,
      pathIndex = nav.index,
      pathLength = #(nav.path or {}),
      holdDir = nav.holdDir,
    }
    if nav.cross then
      out.navigation.cross = {
        sourceMapId = nav.cross.sourceMapId, destMapId = nav.cross.destMapId,
        dir = nav.cross.dir, sourceX = nav.cross.sourceX, sourceY = nav.cross.sourceY,
        entryX = nav.cross.entryX, entryY = nav.cross.entryY,
        crossed = nav.cross.crossed and true or false,
        ledgeSeam = nav.cross.ledgeSeam and true or false,
      }
    end
    if nav.remoteGoal then
      out.navigation.remoteGoal = {
        mapId = nav.remoteGoal.mapId,
        x = nav.remoteGoal.x, y = nav.remoteGoal.y,
        routeIndex = nav.remoteGoal.routeIndex,
        routeLength = #(nav.remoteGoal.route or {}),
      }
    end
    if nav.interaction then
      out.navigation.interaction = {
        kind = nav.interaction.kind,
        entityId = nav.interaction.entityId,
        targetX = nav.interaction.targetX,
        targetY = nav.interaction.targetY,
        faceDir = nav.interaction.faceDir,
        counter = nav.interaction.counter and true or false,
      }
    end
  end
  if state.pendingInteraction then
    out.pendingInteraction = copyFlat(state.pendingInteraction)
  end
  if state.battleResume then
    out.battleResume = {
      mapId = state.battleResume.mapId, x = state.battleResume.x,
      y = state.battleResume.y, ready = state.battleResume.ready and true or false,
    }
  end
  return out
end

mod.exports.cancel = function() return cancelRoute("external_cancel") end
mod.exports.findPath = findPath
mod.exports.diagnostics = diagnostics
mod.exports.version = VERSION
